namespace PlatformSupport.Collections.Specialized;

public class NotifyCollectionChangedEventArgs : EventArgs
{
	private NotifyCollectionChangedAction _action; //Field offset: 0x10
	private IList _newItems; //Field offset: 0x18
	private IList _oldItems; //Field offset: 0x20
	private int _newStartingIndex; //Field offset: 0x28
	private int _oldStartingIndex; //Field offset: 0x2C

	public NotifyCollectionChangedAction Action
	{
		 get { } //Length: 4
	}

	public IList NewItems
	{
		 get { } //Length: 5
	}

	public int NewStartingIndex
	{
		 get { } //Length: 4
	}

	public IList OldItems
	{
		 get { } //Length: 5
	}

	public int OldStartingIndex
	{
		 get { } //Length: 4
	}

	public NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction action) { }

	internal NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction action, IList newItems, IList oldItems, int newIndex, int oldIndex) { }

	public NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction action, object changedItem, int index, int oldIndex) { }

	public NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction action, IList newItems, IList oldItems, int startingIndex) { }

	public NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction action, IList newItems, IList oldItems) { }

	public NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction action, object newItem, object oldItem, int index) { }

	public NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction action, IList changedItems, int index, int oldIndex) { }

	public NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction action, IList changedItems, int startingIndex) { }

	public NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction action, IList changedItems) { }

	public NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction action, object changedItem, int index) { }

	public NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction action, object changedItem) { }

	public NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction action, object newItem, object oldItem) { }

	public NotifyCollectionChangedAction get_Action() { }

	public IList get_NewItems() { }

	public int get_NewStartingIndex() { }

	public IList get_OldItems() { }

	public int get_OldStartingIndex() { }

	private void InitializeAdd(NotifyCollectionChangedAction action, IList newItems, int newStartingIndex) { }

	private void InitializeAddOrRemove(NotifyCollectionChangedAction action, IList changedItems, int startingIndex) { }

	private void InitializeMoveOrReplace(NotifyCollectionChangedAction action, IList newItems, IList oldItems, int startingIndex, int oldStartingIndex) { }

	private void InitializeRemove(NotifyCollectionChangedAction action, IList oldItems, int oldStartingIndex) { }

}

