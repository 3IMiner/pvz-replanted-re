namespace PlatformSupport.Collections.ObjectModel;

[DefaultMember("Item")]
public class ObservableDictionary : IDictionary<TKey, TValue>, ICollection<KeyValuePair`2<TKey, TValue>>, IEnumerable<KeyValuePair`2<TKey, TValue>>, IEnumerable, INotifyCollectionChanged, INotifyPropertyChanged
{
	private const string CountString = "Count"; //Field offset: 0x0
	private const string IndexerName = "Item[]"; //Field offset: 0x0
	private const string KeysName = "Keys"; //Field offset: 0x0
	private const string ValuesName = "Values"; //Field offset: 0x0
	private IDictionary<TKey, TValue> _Dictionary; //Field offset: 0x0
	[CompilerGenerated]
	private NotifyCollectionChangedEventHandler CollectionChanged; //Field offset: 0x0
	[CompilerGenerated]
	private PropertyChangedEventHandler PropertyChanged; //Field offset: 0x0

	public override event NotifyCollectionChangedEventHandler CollectionChanged
	{
		[CompilerGenerated]
		 add { } //Length: 158
		[CompilerGenerated]
		 remove { } //Length: 158
	}

	public override event PropertyChangedEventHandler PropertyChanged
	{
		[CompilerGenerated]
		 add { } //Length: 158
		[CompilerGenerated]
		 remove { } //Length: 158
	}

	public override int Count
	{
		 get { } //Length: 108
	}

	protected IDictionary<TKey, TValue> Dictionary
	{
		 get { } //Length: 5
	}

	public override bool IsReadOnly
	{
		 get { } //Length: 111
	}

	public override TValue Item
	{
		 get { } //Length: 458
		 set { } //Length: 384
	}

	public override ICollection<TKey> Keys
	{
		 get { } //Length: 108
	}

	public override ICollection<TValue> Values
	{
		 get { } //Length: 108
	}

	public ObservableDictionary`2() { }

	public ObservableDictionary`2(IDictionary<TKey, TValue> dictionary) { }

	public ObservableDictionary`2(IEqualityComparer<TKey> comparer) { }

	public ObservableDictionary`2(int capacity) { }

	public ObservableDictionary`2(IDictionary<TKey, TValue> dictionary, IEqualityComparer<TKey> comparer) { }

	public ObservableDictionary`2(int capacity, IEqualityComparer<TKey> comparer) { }

	[CompilerGenerated]
	private bool <AddRange>b__41_0(TKey k) { }

	public override void Add(TKey key, TValue value) { }

	public override void Add(KeyValuePair<TKey, TValue> item) { }

	[CompilerGenerated]
	public override void add_CollectionChanged(NotifyCollectionChangedEventHandler value) { }

	[CompilerGenerated]
	public override void add_PropertyChanged(PropertyChangedEventHandler value) { }

	public void AddRange(IDictionary<TKey, TValue> items) { }

	public override void Clear() { }

	public override bool Contains(KeyValuePair<TKey, TValue> item) { }

	public override bool ContainsKey(TKey key) { }

	public override void CopyTo(KeyValuePair<TKey, TValue>[] array, int arrayIndex) { }

	public override int get_Count() { }

	protected IDictionary<TKey, TValue> get_Dictionary() { }

	public override bool get_IsReadOnly() { }

	public override TValue get_Item(TKey key) { }

	public override ICollection<TKey> get_Keys() { }

	public override ICollection<TValue> get_Values() { }

	public override IEnumerator<KeyValuePair`2<TKey, TValue>> GetEnumerator() { }

	private void Insert(TKey key, TValue value, bool add) { }

	private void OnCollectionChanged(NotifyCollectionChangedAction action, IList newItems) { }

	private void OnCollectionChanged() { }

	private void OnCollectionChanged(NotifyCollectionChangedAction action, KeyValuePair<TKey, TValue> changedItem) { }

	private void OnCollectionChanged(NotifyCollectionChangedAction action, KeyValuePair<TKey, TValue> newItem, KeyValuePair<TKey, TValue> oldItem) { }

	private void OnPropertyChanged() { }

	protected override void OnPropertyChanged(string propertyName) { }

	public override bool Remove(KeyValuePair<TKey, TValue> item) { }

	public override bool Remove(TKey key) { }

	[CompilerGenerated]
	public override void remove_CollectionChanged(NotifyCollectionChangedEventHandler value) { }

	[CompilerGenerated]
	public override void remove_PropertyChanged(PropertyChangedEventHandler value) { }

	public override void set_Item(TKey key, TValue value) { }

	private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

	public override bool TryGetValue(TKey key, out TValue value) { }

}

