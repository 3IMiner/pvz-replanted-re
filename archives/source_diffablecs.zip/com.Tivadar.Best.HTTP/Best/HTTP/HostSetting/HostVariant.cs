namespace Best.HTTP.HostSetting;

public class HostVariant
{
	[CompilerGenerated]
	private sealed class <>c
	{
		public static readonly <>c <>9; //Field offset: 0x0
		public static Comparison<KeyValuePair`2<Int32, ConnectionBase>> <>9__23_0; //Field offset: 0x8
		public static Comparison<KeyValuePair`2<Int32, ConnectionBase>> <>9__23_1; //Field offset: 0x10

		private static <>c() { }

		public <>c() { }

		internal int <TryToSendQueuedRequests>b__23_0(KeyValuePair<Int32, ConnectionBase> a, KeyValuePair<Int32, ConnectionBase> b) { }

		internal int <TryToSendQueuedRequests>b__23_1(KeyValuePair<Int32, ConnectionBase> a, KeyValuePair<Int32, ConnectionBase> b) { }

	}

	[CompilerGenerated]
	private HostKey <Host>k__BackingField; //Field offset: 0x10
	[CompilerGenerated]
	private HostProtocolSupport <ProtocolSupport>k__BackingField; //Field offset: 0x30
	[CompilerGenerated]
	private DateTime <LastProtocolSupportUpdate>k__BackingField; //Field offset: 0x38
	[CompilerGenerated]
	private LoggingContext <Context>k__BackingField; //Field offset: 0x40
	protected List<ConnectionBase> Connections; //Field offset: 0x48
	protected Queue<HTTPRequest> Queue; //Field offset: 0x50
	protected HostVariantSettings _settings; //Field offset: 0x58
	protected List<KeyValuePair`2<Int32, ConnectionBase>> availableConnections; //Field offset: 0x60

	public private LoggingContext Context
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 13
	}

	public private HostKey Host
	{
		[CompilerGenerated]
		 get { } //Length: 19
		[CompilerGenerated]
		private set { } //Length: 26
	}

	public private DateTime LastProtocolSupportUpdate
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 5
	}

	public private HostProtocolSupport ProtocolSupport
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 4
	}

	public HostVariant(HostKey host) { }

	public override void AddProtocol(HostProtocolSupport protocolSupport) { }

	protected override bool CloseConnectionAfterInactivity(DateTime now, object context) { }

	public override ConnectionBase CreateNew() { }

	public ConnectionBase Find(Predicate<ConnectionBase> match) { }

	[CompilerGenerated]
	public LoggingContext get_Context() { }

	[CompilerGenerated]
	public HostKey get_Host() { }

	[CompilerGenerated]
	public DateTime get_LastProtocolSupportUpdate() { }

	[CompilerGenerated]
	public HostProtocolSupport get_ProtocolSupport() { }

	public bool HasConnection(ConnectionBase connection) { }

	public override void LoadFrom(int version, BinaryReader br) { }

	protected override void OnConnectionStartedProcessingRequest(ConnectionBase connection, HTTPRequest request) { }

	public override ValueTuple<Int32, Int32, Int32> QueryAnyAvailableOrNew(ref List<KeyValuePair`2<Int32, ConnectionBase>>& connectionCollector) { }

	public override HostVariant RecycleConnection(ConnectionBase conn) { }

	public override void RemoveAllIdleConnections() { }

	public override HostVariant RemoveConnection(ConnectionBase conn, HTTPConnectionStates setState) { }

	protected override bool RemoveConnectionImpl(ConnectionBase conn, HTTPConnectionStates setState) { }

	public override void SaveTo(BinaryWriter bw) { }

	public override HostVariant Send(HTTPRequest request) { }

	[CompilerGenerated]
	private void set_Context(LoggingContext value) { }

	[CompilerGenerated]
	private void set_Host(HostKey value) { }

	[CompilerGenerated]
	private void set_LastProtocolSupportUpdate(DateTime value) { }

	[CompilerGenerated]
	private void set_ProtocolSupport(HostProtocolSupport value) { }

	public override void Shutdown() { }

	public virtual string ToString() { }

	public override HostVariant TryToSendQueuedRequests() { }

}

