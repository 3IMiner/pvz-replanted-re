namespace Best.HTTP.HostSetting;

public enum HostProtocolSupport
{
	Unknown = 0,
	HTTP1 = 1,
	HTTP2 = 2,
	File = 3,
}

