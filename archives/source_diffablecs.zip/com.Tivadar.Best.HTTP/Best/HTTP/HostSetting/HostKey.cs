namespace Best.HTTP.HostSetting;

[IsReadOnly]
public struct HostKey
{
	public readonly Uri Uri; //Field offset: 0x0
	public readonly ProxySettings Proxy; //Field offset: 0x8
	public readonly Hash128 Key; //Field offset: 0x10

	public string Host
	{
		 get { } //Length: 94
	}

	public HostKey(Uri uri, ProxySettings proxy) { }

	internal static void Append(Uri uri, ref Hash128 hash) { }

	private static Hash128 CalculateHash(Uri uri, ProxySettings proxy) { }

	public virtual bool Equals(object obj) { }

	public bool Equals(HostKey hostKey) { }

	public static HostKey From(HTTPRequest request) { }

	public static HostKey From(Uri uri, ProxySettings proxy) { }

	public string get_Host() { }

	public virtual int GetHashCode() { }

	public virtual string ToString() { }

}

