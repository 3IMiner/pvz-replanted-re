namespace Best.HTTP.HostSetting;

public static class HostManager
{
	private static Dictionary<HostKey, HostVariant> hosts; //Field offset: 0x0

	private static HostManager() { }

	public static void Clear() { }

	public static HostVariant GetHostVariant(HTTPRequest request) { }

	public static HostVariant GetHostVariant(ConnectionBase connection) { }

	public static HostVariant GetHostVariant(HostKey key) { }

	public static void RemoveAllIdleConnections() { }

	public static void Shutdown() { }

	public static void TryToSendQueuedRequests() { }

}

