namespace Best.HTTP.HostSetting;

internal sealed class HostKeyEqualityComparer : IEqualityComparer<HostKey>
{

	public HostKeyEqualityComparer() { }

	public override bool Equals(HostKey x, HostKey y) { }

	public override int GetHashCode(HostKey obj) { }

}

