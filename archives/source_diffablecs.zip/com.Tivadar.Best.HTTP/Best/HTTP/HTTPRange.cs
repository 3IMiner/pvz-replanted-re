namespace Best.HTTP;

public sealed class HTTPRange
{
	[CompilerGenerated]
	private long <FirstBytePos>k__BackingField; //Field offset: 0x10
	[CompilerGenerated]
	private long <LastBytePos>k__BackingField; //Field offset: 0x18
	[CompilerGenerated]
	private long <ContentLength>k__BackingField; //Field offset: 0x20
	[CompilerGenerated]
	private bool <IsValid>k__BackingField; //Field offset: 0x28

	public private long ContentLength
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 5
	}

	public private long FirstBytePos
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 5
	}

	public private bool IsValid
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 4
	}

	public private long LastBytePos
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 5
	}

	internal HTTPRange() { }

	internal HTTPRange(int contentLength) { }

	internal HTTPRange(long firstBytePosition, long lastBytePosition, long contentLength) { }

	[CompilerGenerated]
	public long get_ContentLength() { }

	[CompilerGenerated]
	public long get_FirstBytePos() { }

	[CompilerGenerated]
	public bool get_IsValid() { }

	[CompilerGenerated]
	public long get_LastBytePos() { }

	[CompilerGenerated]
	private void set_ContentLength(long value) { }

	[CompilerGenerated]
	private void set_FirstBytePos(long value) { }

	[CompilerGenerated]
	private void set_IsValid(bool value) { }

	[CompilerGenerated]
	private void set_LastBytePos(long value) { }

	public virtual string ToString() { }

}

