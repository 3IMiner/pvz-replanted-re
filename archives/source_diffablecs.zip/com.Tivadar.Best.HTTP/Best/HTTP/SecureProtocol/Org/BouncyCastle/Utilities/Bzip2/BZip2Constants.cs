namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities.Bzip2;

public class BZip2Constants
{
	public const int baseBlockSize = 100000; //Field offset: 0x0
	public const int MAX_ALPHA_SIZE = 258; //Field offset: 0x0
	public const int MAX_CODE_LEN = 20; //Field offset: 0x0
	public const int MAX_CODE_LEN_GEN = 17; //Field offset: 0x0
	public const int RUNA = 0; //Field offset: 0x0
	public const int RUNB = 1; //Field offset: 0x0
	public const int N_GROUPS = 6; //Field offset: 0x0
	public const int G_SIZE = 50; //Field offset: 0x0
	public const int N_ITERS = 4; //Field offset: 0x0
	public const int MAX_SELECTORS = 18002; //Field offset: 0x0
	public const int NUM_OVERSHOOT_BYTES = 20; //Field offset: 0x0

	public BZip2Constants() { }

}

