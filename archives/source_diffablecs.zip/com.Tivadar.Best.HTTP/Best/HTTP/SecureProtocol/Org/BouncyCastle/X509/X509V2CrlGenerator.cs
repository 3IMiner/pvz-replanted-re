namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.X509;

public class X509V2CrlGenerator
{
	private readonly X509ExtensionsGenerator extGenerator; //Field offset: 0x10
	private V2TbsCertListGenerator tbsGen; //Field offset: 0x18

	public IEnumerable<String> SignatureAlgNames
	{
		 get { } //Length: 64
	}

	public X509V2CrlGenerator() { }

	public void AddCrl(X509Crl other) { }

	public void AddCrlEntry(BigInteger userCertificate, DateTime revocationDate, int reason) { }

	public void AddCrlEntry(BigInteger userCertificate, DateTime revocationDate, int reason, DateTime invalidityDate) { }

	public void AddCrlEntry(BigInteger userCertificate, DateTime revocationDate, X509Extensions extensions) { }

	public void AddExtension(string oid, bool critical, Asn1Encodable extensionValue) { }

	public void AddExtension(DerObjectIdentifier oid, bool critical, Asn1Encodable extensionValue) { }

	public void AddExtension(string oid, bool critical, Byte[] extensionValue) { }

	public void AddExtension(DerObjectIdentifier oid, bool critical, Byte[] extensionValue) { }

	public X509Crl Generate(ISignatureFactory signatureFactory) { }

	public IEnumerable<String> get_SignatureAlgNames() { }

	public void Reset() { }

	public void SetIssuerDN(X509Name issuer) { }

	public void SetNextUpdate(DateTime date) { }

	public void SetThisUpdate(DateTime date) { }

}

