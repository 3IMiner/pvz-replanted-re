namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities.Collections;

internal sealed class EnumerableProxy : IEnumerable<T>, IEnumerable
{
	private readonly IEnumerable<T> m_target; //Field offset: 0x0

	internal EnumerableProxy`1(IEnumerable<T> target) { }

	public override IEnumerator<T> GetEnumerator() { }

	private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

}

