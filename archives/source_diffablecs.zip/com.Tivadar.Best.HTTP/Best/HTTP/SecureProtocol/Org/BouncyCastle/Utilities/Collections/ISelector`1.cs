namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities.Collections;

public interface ISelector : ICloneable
{

	public bool Match(T candidate) { }

}

