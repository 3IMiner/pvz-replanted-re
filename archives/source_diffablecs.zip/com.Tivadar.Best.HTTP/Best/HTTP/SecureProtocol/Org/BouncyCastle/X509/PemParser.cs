namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.X509;

internal class PemParser
{
	private readonly string _header1; //Field offset: 0x10
	private readonly string _header2; //Field offset: 0x18
	private readonly string _footer1; //Field offset: 0x20
	private readonly string _footer2; //Field offset: 0x28

	internal PemParser(string type) { }

	private string ReadLine(Stream inStream) { }

	internal Asn1Sequence ReadPemObject(Stream inStream) { }

}

