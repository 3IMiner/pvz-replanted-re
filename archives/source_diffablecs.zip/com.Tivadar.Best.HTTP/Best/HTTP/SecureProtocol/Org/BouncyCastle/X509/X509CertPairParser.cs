namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.X509;

public class X509CertPairParser
{
	private Stream currentStream; //Field offset: 0x10

	public X509CertPairParser() { }

	public X509CertificatePair ReadCertPair(Byte[] input) { }

	public X509CertificatePair ReadCertPair(Stream inStream) { }

	public IList<X509CertificatePair> ReadCertPairs(Byte[] input) { }

	public IList<X509CertificatePair> ReadCertPairs(Stream inStream) { }

	private X509CertificatePair ReadDerCrossCertificatePair(Stream inStream) { }

}

