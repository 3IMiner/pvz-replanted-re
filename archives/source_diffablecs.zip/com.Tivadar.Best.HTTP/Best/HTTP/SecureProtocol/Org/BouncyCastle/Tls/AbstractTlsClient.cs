namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Tls;

public abstract class AbstractTlsClient : AbstractTlsPeer, TlsClient, TlsPeer
{
	protected TlsClientContext m_context; //Field offset: 0x20
	protected ProtocolVersion[] m_protocolVersions; //Field offset: 0x28
	protected Int32[] m_cipherSuites; //Field offset: 0x30
	protected IList<Int32> m_supportedGroups; //Field offset: 0x38
	protected IList<SignatureAndHashAlgorithm> m_supportedSignatureAlgorithms; //Field offset: 0x40
	protected IList<SignatureAndHashAlgorithm> m_supportedSignatureAlgorithmsCert; //Field offset: 0x48

	protected AbstractTlsClient(TlsCrypto crypto) { }

	protected override bool AllowUnexpectedServerExtension(int extensionType, Byte[] extensionData) { }

	protected override void CheckForUnexpectedServerExtension(IDictionary<Int32, Byte[]> serverExtensions, int extensionType) { }

	protected override Int16[] GetAllowedClientCertificateTypes() { }

	protected override Int16[] GetAllowedServerCertificateTypes() { }

	public abstract TlsAuthentication GetAuthentication() { }

	protected override IList<X509Name> GetCertificateAuthorities() { }

	protected override CertificateStatusRequest GetCertificateStatusRequest() { }

	public virtual Int32[] GetCipherSuites() { }

	public override IDictionary<Int32, Byte[]> GetClientExtensions() { }

	public override IList<SupplementalDataEntry> GetClientSupplementalData() { }

	public override TlsDHGroupVerifier GetDHGroupVerifier() { }

	public override IList<Int32> GetEarlyKeyShareGroups() { }

	public override IList<TlsPskExternal> GetExternalPsks() { }

	protected override IList<CertificateStatusRequestItemV2> GetMultiCertStatusRequest() { }

	protected override IList<Int32> GetNamedGroupRoles() { }

	protected override IList<ProtocolName> GetProtocolNames() { }

	public virtual ProtocolVersion[] GetProtocolVersions() { }

	public override TlsPskIdentity GetPskIdentity() { }

	public override TlsSession GetSessionToResume() { }

	protected override IList<ServerName> GetSniServerNames() { }

	public override TlsSrpConfigVerifier GetSrpConfigVerifier() { }

	public override TlsSrpIdentity GetSrpIdentity() { }

	protected override IList<Int32> GetSupportedGroups(IList<Int32> namedGroupRoles) { }

	protected override IList<SignatureAndHashAlgorithm> GetSupportedSignatureAlgorithms() { }

	protected override IList<SignatureAndHashAlgorithm> GetSupportedSignatureAlgorithmsCert() { }

	protected override IList<TrustedAuthority> GetTrustedCAIndication() { }

	public override void Init(TlsClientContext context) { }

	public override bool IsFallback() { }

	public virtual void NotifyHandshakeBeginning() { }

	public override void NotifyNewSessionTicket(NewSessionTicket newSessionTicket) { }

	public override void NotifySelectedCipherSuite(int selectedCipherSuite) { }

	public override void NotifySelectedPsk(TlsPsk selectedPsk) { }

	public override void NotifyServerVersion(ProtocolVersion serverVersion) { }

	public override void NotifySessionID(Byte[] sessionID) { }

	public override void NotifySessionToResume(TlsSession session) { }

	public override void ProcessServerExtensions(IDictionary<Int32, Byte[]> serverExtensions) { }

	public override void ProcessServerSupplementalData(IList<SupplementalDataEntry> serverSupplementalData) { }

}

