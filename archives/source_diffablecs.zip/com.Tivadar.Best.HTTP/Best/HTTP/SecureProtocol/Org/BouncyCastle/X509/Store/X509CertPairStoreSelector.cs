namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.X509.Store;

public class X509CertPairStoreSelector : ISelector<X509CertificatePair>, ICloneable
{
	private X509CertificatePair certPair; //Field offset: 0x10
	private X509CertStoreSelector forwardSelector; //Field offset: 0x18
	private X509CertStoreSelector reverseSelector; //Field offset: 0x20

	public X509CertificatePair CertPair
	{
		 get { } //Length: 5
		 set { } //Length: 13
	}

	public X509CertStoreSelector ForwardSelector
	{
		 get { } //Length: 133
		 set { } //Length: 161
	}

	public X509CertStoreSelector ReverseSelector
	{
		 get { } //Length: 133
		 set { } //Length: 161
	}

	public X509CertPairStoreSelector() { }

	private X509CertPairStoreSelector(X509CertPairStoreSelector o) { }

	public override object Clone() { }

	private static X509CertStoreSelector CloneSelector(X509CertStoreSelector s) { }

	public X509CertificatePair get_CertPair() { }

	public X509CertStoreSelector get_ForwardSelector() { }

	public X509CertStoreSelector get_ReverseSelector() { }

	public override bool Match(X509CertificatePair pair) { }

	public void set_CertPair(X509CertificatePair value) { }

	public void set_ForwardSelector(X509CertStoreSelector value) { }

	public void set_ReverseSelector(X509CertStoreSelector value) { }

}

