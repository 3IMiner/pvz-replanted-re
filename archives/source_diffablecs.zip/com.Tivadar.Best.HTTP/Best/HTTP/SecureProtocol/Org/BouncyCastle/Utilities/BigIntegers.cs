namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities;

public static class BigIntegers
{
	public static readonly BigInteger Zero; //Field offset: 0x0
	private const int MaxIterations = 1000; //Field offset: 0x0
	public static readonly BigInteger One; //Field offset: 0x8

	private static BigIntegers() { }

	public static Byte[] AsUnsignedByteArray(BigInteger n) { }

	public static Byte[] AsUnsignedByteArray(int length, BigInteger n) { }

	public static void AsUnsignedByteArray(BigInteger n, Byte[] buf, int off, int len) { }

	public static void AsUnsignedByteArray(BigInteger n, Span<Byte> buf) { }

	public static BigInteger CreateRandomBigInteger(int bitLength, SecureRandom secureRandom) { }

	public static BigInteger CreateRandomInRange(BigInteger min, BigInteger max, SecureRandom random) { }

	public static int GetByteLength(BigInteger n) { }

	public static int GetUnsignedByteLength(BigInteger n) { }

	public static BigInteger ModOddInverse(BigInteger M, BigInteger X) { }

	public static BigInteger ModOddInverseVar(BigInteger M, BigInteger X) { }

}

