namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities.IO;

public class StreamOverflowException : IOException
{

	public StreamOverflowException() { }

	public StreamOverflowException(string message) { }

	public StreamOverflowException(string message, Exception innerException) { }

	protected StreamOverflowException(SerializationInfo info, StreamingContext context) { }

}

