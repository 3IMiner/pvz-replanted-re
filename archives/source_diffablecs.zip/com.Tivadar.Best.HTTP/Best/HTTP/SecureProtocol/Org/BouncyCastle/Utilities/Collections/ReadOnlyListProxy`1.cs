namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities.Collections;

internal class ReadOnlyListProxy : ReadOnlyList<T>
{
	private readonly IList<T> m_target; //Field offset: 0x0

	public virtual int Count
	{
		 get { } //Length: 70
	}

	internal ReadOnlyListProxy`1(IList<T> target) { }

	public virtual bool Contains(T item) { }

	public virtual void CopyTo(T[] array, int arrayIndex) { }

	public virtual int get_Count() { }

	public virtual IEnumerator<T> GetEnumerator() { }

	public virtual int IndexOf(T item) { }

	protected virtual T Lookup(int index) { }

}

