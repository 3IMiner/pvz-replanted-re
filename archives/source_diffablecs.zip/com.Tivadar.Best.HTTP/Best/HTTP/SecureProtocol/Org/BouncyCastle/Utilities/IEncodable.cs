namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities;

public interface IEncodable
{

	public Byte[] GetEncoded() { }

}

