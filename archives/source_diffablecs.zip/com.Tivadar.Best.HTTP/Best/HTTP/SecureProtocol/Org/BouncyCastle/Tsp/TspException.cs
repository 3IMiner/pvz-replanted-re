namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Tsp;

public class TspException : Exception
{

	public TspException() { }

	public TspException(string message) { }

	public TspException(string message, Exception innerException) { }

	protected TspException(SerializationInfo info, StreamingContext context) { }

}

