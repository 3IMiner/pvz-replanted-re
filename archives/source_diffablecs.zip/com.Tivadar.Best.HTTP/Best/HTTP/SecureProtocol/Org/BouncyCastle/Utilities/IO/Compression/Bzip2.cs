namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities.IO.Compression;

internal static class Bzip2
{

	internal static Stream CompressOutput(Stream stream, bool leaveOpen = false) { }

	internal static Stream DecompressInput(Stream stream) { }

}

