namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities.Encoders;

public class HexEncoder : IEncoder
{
	protected readonly Byte[] encodingTable; //Field offset: 0x10
	protected readonly Byte[] decodingTable; //Field offset: 0x18

	public HexEncoder() { }

	public override int Decode(Byte[] data, int off, int length, Stream outStream) { }

	public override int Decode(ReadOnlySpan<Byte> data, Stream outStream) { }

	internal Byte[] DecodeStrict(string str, int off, int len) { }

	public override int DecodeString(string data, Stream outStream) { }

	public int Encode(Byte[] inBuf, int inOff, int inLen, Byte[] outBuf, int outOff) { }

	public int Encode(ReadOnlySpan<Byte> input, Span<Byte> output) { }

	public override int Encode(Byte[] buf, int off, int len, Stream outStream) { }

	public override int Encode(ReadOnlySpan<Byte> data, Stream outStream) { }

	private static bool Ignore(char c) { }

	protected void InitialiseDecodingTable() { }

}

