namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities.Encoders;

public interface IEncoder
{

	public int Decode(Byte[] data, int off, int length, Stream outStream) { }

	public int Decode(ReadOnlySpan<Byte> data, Stream outStream) { }

	public int DecodeString(string data, Stream outStream) { }

	public int Encode(Byte[] data, int off, int length, Stream outStream) { }

	public int Encode(ReadOnlySpan<Byte> data, Stream outStream) { }

}

