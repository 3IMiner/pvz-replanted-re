namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.X509;

public class X509V2AttributeCertificate : X509ExtensionBase
{
	private readonly AttributeCertificate cert; //Field offset: 0x10
	private readonly DateTime notBefore; //Field offset: 0x18
	private readonly DateTime notAfter; //Field offset: 0x20

	public override AttributeCertificate AttributeCertificate
	{
		 get { } //Length: 5
	}

	public override AttributeCertificateHolder Holder
	{
		 get { } //Length: 212
	}

	public override AttributeCertificateIssuer Issuer
	{
		 get { } //Length: 112
	}

	public override bool IsValidNow
	{
		 get { } //Length: 96
	}

	public override DateTime NotAfter
	{
		 get { } //Length: 5
	}

	public override DateTime NotBefore
	{
		 get { } //Length: 5
	}

	public override BigInteger SerialNumber
	{
		 get { } //Length: 47
	}

	public override AlgorithmIdentifier SignatureAlgorithm
	{
		 get { } //Length: 27
	}

	public override int Version
	{
		 get { } //Length: 50
	}

	public X509V2AttributeCertificate(Stream encIn) { }

	public X509V2AttributeCertificate(Byte[] encoded) { }

	public X509V2AttributeCertificate(AttributeCertificate cert) { }

	protected override void CheckSignature(IVerifierFactory verifier) { }

	public override void CheckValidity(DateTime date) { }

	public override void CheckValidity() { }

	public virtual bool Equals(object obj) { }

	public override AttributeCertificate get_AttributeCertificate() { }

	public override AttributeCertificateHolder get_Holder() { }

	public override AttributeCertificateIssuer get_Issuer() { }

	public override bool get_IsValidNow() { }

	public override DateTime get_NotAfter() { }

	public override DateTime get_NotBefore() { }

	public override BigInteger get_SerialNumber() { }

	public override AlgorithmIdentifier get_SignatureAlgorithm() { }

	public override int get_Version() { }

	public override X509Attribute[] GetAttributes(string oid) { }

	public override X509Attribute[] GetAttributes() { }

	public override Byte[] GetEncoded() { }

	public virtual int GetHashCode() { }

	public override Boolean[] GetIssuerUniqueID() { }

	private static AttributeCertificate GetObject(Stream input) { }

	public override Byte[] GetSignature() { }

	protected virtual X509Extensions GetX509Extensions() { }

	public override bool IsValid(DateTime date) { }

	public override void Verify(AsymmetricKeyParameter key) { }

	public override void Verify(IVerifierFactoryProvider verifierProvider) { }

}

