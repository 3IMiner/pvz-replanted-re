namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities.Zlib;

public class ZInputStream : BaseInputStream
{
	private const int BufferSize = 4096; //Field offset: 0x0
	protected ZStream z; //Field offset: 0x28
	protected int flushLevel; //Field offset: 0x30
	protected Byte[] buf; //Field offset: 0x38
	protected Byte[] buf1; //Field offset: 0x40
	protected bool compress; //Field offset: 0x48
	protected Stream input; //Field offset: 0x50
	protected bool closed; //Field offset: 0x58
	private bool nomoreinput; //Field offset: 0x59

	public override int FlushMode
	{
		 get { } //Length: 4
		 set { } //Length: 4
	}

	public override long TotalIn
	{
		 get { } //Length: 27
	}

	public override long TotalOut
	{
		 get { } //Length: 27
	}

	public ZInputStream(Stream input) { }

	public ZInputStream(Stream input, bool nowrap) { }

	public ZInputStream(Stream input, ZStream z) { }

	public ZInputStream(Stream input, int level) { }

	public ZInputStream(Stream input, int level, bool nowrap) { }

	protected virtual void Dispose(bool disposing) { }

	public override int get_FlushMode() { }

	public override long get_TotalIn() { }

	public override long get_TotalOut() { }

	private static ZStream GetDefaultZStream(bool nowrap) { }

	public virtual int Read(Byte[] buffer, int offset, int count) { }

	public virtual int ReadByte() { }

	public override void set_FlushMode(int value) { }

}

