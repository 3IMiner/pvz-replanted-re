namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Tsp;

public class TspUtil
{
	private static readonly Dictionary<String, Int32> DigestLengths; //Field offset: 0x0
	private static readonly Dictionary<String, String> DigestNames; //Field offset: 0x8

	private static TspUtil() { }

	public TspUtil() { }

	internal static IDigest CreateDigestInstance(string digestAlgOID) { }

	internal static ISet<DerObjectIdentifier> GetCriticalExtensionOids(X509Extensions extensions) { }

	internal static string GetDigestAlgName(string digestAlgOid) { }

	internal static int GetDigestLength(string digestAlgOid) { }

	internal static IList<DerObjectIdentifier> GetExtensionOids(X509Extensions extensions) { }

	internal static ISet<DerObjectIdentifier> GetNonCriticalExtensionOids(X509Extensions extensions) { }

	public static IList<TimeStampToken> GetSignatureTimestamps(SignerInformation signerInfo) { }

	public static void ValidateCertificate(X509Certificate cert) { }

}

