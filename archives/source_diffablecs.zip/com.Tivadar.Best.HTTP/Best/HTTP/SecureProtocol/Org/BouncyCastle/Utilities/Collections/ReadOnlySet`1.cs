namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities.Collections;

internal abstract class ReadOnlySet : ISet<T>, ICollection<T>, IEnumerable<T>, IEnumerable
{

	public abstract int Count
	{
		 get { } //Length: 0
	}

	public override bool IsReadOnly
	{
		 get { } //Length: 3
	}

	protected ReadOnlySet`1() { }

	public override bool Add(T item) { }

	public override void Clear() { }

	public abstract bool Contains(T item) { }

	public abstract void CopyTo(T[] array, int arrayIndex) { }

	public override void ExceptWith(IEnumerable<T> other) { }

	public abstract int get_Count() { }

	public override bool get_IsReadOnly() { }

	public abstract IEnumerator<T> GetEnumerator() { }

	public override void IntersectWith(IEnumerable<T> other) { }

	public abstract bool IsProperSubsetOf(IEnumerable<T> other) { }

	public abstract bool IsProperSupersetOf(IEnumerable<T> other) { }

	public abstract bool IsSubsetOf(IEnumerable<T> other) { }

	public abstract bool IsSupersetOf(IEnumerable<T> other) { }

	public abstract bool Overlaps(IEnumerable<T> other) { }

	public override bool Remove(T item) { }

	public override bool SetEquals(IEnumerable<T> other) { }

	public override void SymmetricExceptWith(IEnumerable<T> other) { }

	private override void System.Collections.Generic.ICollection<T>.Add(T item) { }

	private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

	public override void UnionWith(IEnumerable<T> other) { }

}

