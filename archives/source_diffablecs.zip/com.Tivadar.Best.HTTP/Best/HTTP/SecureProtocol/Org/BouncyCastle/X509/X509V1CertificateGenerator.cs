namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.X509;

public class X509V1CertificateGenerator
{
	private V1TbsCertificateGenerator tbsGen; //Field offset: 0x10

	public IEnumerable<String> SignatureAlgNames
	{
		 get { } //Length: 64
	}

	public X509V1CertificateGenerator() { }

	public X509Certificate Generate(ISignatureFactory signatureFactory) { }

	public IEnumerable<String> get_SignatureAlgNames() { }

	public void Reset() { }

	public void SetIssuerDN(X509Name issuer) { }

	public void SetNotAfter(DateTime date) { }

	public void SetNotBefore(DateTime date) { }

	public void SetPublicKey(AsymmetricKeyParameter publicKey) { }

	public void SetSerialNumber(BigInteger serialNumber) { }

	public void SetSubjectDN(X509Name subject) { }

}

