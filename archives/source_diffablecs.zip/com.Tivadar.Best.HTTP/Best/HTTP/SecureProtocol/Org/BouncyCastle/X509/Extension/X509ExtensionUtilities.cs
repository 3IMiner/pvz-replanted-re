namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.X509.Extension;

public class X509ExtensionUtilities
{

	public X509ExtensionUtilities() { }

	public static Asn1Object FromExtensionValue(IX509Extension extensions, DerObjectIdentifier oid) { }

	public static Asn1Object FromExtensionValue(Asn1OctetString extensionValue) { }

}

