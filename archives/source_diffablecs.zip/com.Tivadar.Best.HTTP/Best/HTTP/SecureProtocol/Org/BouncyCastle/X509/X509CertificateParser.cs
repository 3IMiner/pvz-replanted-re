namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.X509;

public class X509CertificateParser
{
	[CompilerGenerated]
	private sealed class <ParseCertificates>d__11 : IEnumerable<X509Certificate>, IEnumerable, IEnumerator<X509Certificate>, IEnumerator, IDisposable
	{
		private int <>1__state; //Field offset: 0x10
		private X509Certificate <>2__current; //Field offset: 0x18
		private int <>l__initialThreadId; //Field offset: 0x20
		public X509CertificateParser <>4__this; //Field offset: 0x28
		private Stream inStream; //Field offset: 0x30
		public Stream <>3__inStream; //Field offset: 0x38

		private override X509Certificate System.Collections.Generic.IEnumerator<Best.HTTP.SecureProtocol.Org.BouncyCastle.X509.X509Certificate>.Current
		{
			[DebuggerHidden]
			private get { } //Length: 5
		}

		private override object System.Collections.IEnumerator.Current
		{
			[DebuggerHidden]
			private get { } //Length: 5
		}

		[DebuggerHidden]
		public <ParseCertificates>d__11(int <>1__state) { }

		private override bool MoveNext() { }

		[DebuggerHidden]
		private override IEnumerator<X509Certificate> System.Collections.Generic.IEnumerable<Best.HTTP.SecureProtocol.Org.BouncyCastle.X509.X509Certificate>.GetEnumerator() { }

		[DebuggerHidden]
		private override X509Certificate System.Collections.Generic.IEnumerator<Best.HTTP.SecureProtocol.Org.BouncyCastle.X509.X509Certificate>.get_Current() { }

		[DebuggerHidden]
		private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

		[DebuggerHidden]
		private override object System.Collections.IEnumerator.get_Current() { }

		[DebuggerHidden]
		private override void System.Collections.IEnumerator.Reset() { }

		[DebuggerHidden]
		private override void System.IDisposable.Dispose() { }

	}

	private static readonly PemParser PemCertParser; //Field offset: 0x0
	private Asn1Set sData; //Field offset: 0x10
	private int sDataObjectCount; //Field offset: 0x18
	private Stream currentStream; //Field offset: 0x20

	private static X509CertificateParser() { }

	public X509CertificateParser() { }

	private X509Certificate GetCertificate() { }

	[IteratorStateMachine(typeof(<ParseCertificates>d__11))]
	public IEnumerable<X509Certificate> ParseCertificates(Stream inStream) { }

	public X509Certificate ReadCertificate(Byte[] input) { }

	public X509Certificate ReadCertificate(Stream inStream) { }

	public IList<X509Certificate> ReadCertificates(Byte[] input) { }

	public IList<X509Certificate> ReadCertificates(Stream inStream) { }

	private X509Certificate ReadDerCertificate(Asn1InputStream dIn) { }

	private X509Certificate ReadPemCertificate(Stream inStream) { }

}

