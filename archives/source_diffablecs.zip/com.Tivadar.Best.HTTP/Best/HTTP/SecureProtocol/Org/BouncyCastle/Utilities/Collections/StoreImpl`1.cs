namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities.Collections;

internal sealed class StoreImpl : IStore<T>
{
	[CompilerGenerated]
	private sealed class <Best-HTTP-SecureProtocol-Org-BouncyCastle-Utilities-Collections-IStore<T>-EnumerateMatches>d__2 : IEnumerable<T>, IEnumerable, IEnumerator<T>, IEnumerator, IDisposable
	{
		private int <>1__state; //Field offset: 0x0
		private T <>2__current; //Field offset: 0x0
		private int <>l__initialThreadId; //Field offset: 0x0
		public StoreImpl<T> <>4__this; //Field offset: 0x0
		private ISelector<T> selector; //Field offset: 0x0
		public ISelector<T> <>3__selector; //Field offset: 0x0
		private Enumerator<T> <>7__wrap1; //Field offset: 0x0

		private override T System.Collections.Generic.IEnumerator<T>.Current
		{
			[DebuggerHidden]
			private get { } //Length: 5
		}

		private override object System.Collections.IEnumerator.Current
		{
			[DebuggerHidden]
			private get { } //Length: 5
		}

		[DebuggerHidden]
		public <Best-HTTP-SecureProtocol-Org-BouncyCastle-Utilities-Collections-IStore<T>-EnumerateMatches>d__2(int <>1__state) { }

		private void <>m__Finally1() { }

		private override bool MoveNext() { }

		[DebuggerHidden]
		private override IEnumerator<T> System.Collections.Generic.IEnumerable<T>.GetEnumerator() { }

		[DebuggerHidden]
		private override T System.Collections.Generic.IEnumerator<T>.get_Current() { }

		[DebuggerHidden]
		private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

		[DebuggerHidden]
		private override object System.Collections.IEnumerator.get_Current() { }

		[DebuggerHidden]
		private override void System.Collections.IEnumerator.Reset() { }

		[DebuggerHidden]
		private override void System.IDisposable.Dispose() { }

	}

	private readonly List<T> m_contents; //Field offset: 0x0

	internal StoreImpl`1(IEnumerable<T> e) { }

	[IteratorStateMachine(typeof(<Best-HTTP-SecureProtocol-Org-BouncyCastle-Utilities-Collections-IStore<T>-EnumerateMatches>d__2))]
	private override IEnumerable<T> Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities.Collections.IStore<T>.EnumerateMatches(ISelector<T> selector) { }

}

