namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.X509;

public class X509CrlParser
{
	[CompilerGenerated]
	private sealed class <ParseCrls>d__13 : IEnumerable<X509Crl>, IEnumerable, IEnumerator<X509Crl>, IEnumerator, IDisposable
	{
		private int <>1__state; //Field offset: 0x10
		private X509Crl <>2__current; //Field offset: 0x18
		private int <>l__initialThreadId; //Field offset: 0x20
		public X509CrlParser <>4__this; //Field offset: 0x28
		private Stream inStream; //Field offset: 0x30
		public Stream <>3__inStream; //Field offset: 0x38

		private override X509Crl System.Collections.Generic.IEnumerator<Best.HTTP.SecureProtocol.Org.BouncyCastle.X509.X509Crl>.Current
		{
			[DebuggerHidden]
			private get { } //Length: 5
		}

		private override object System.Collections.IEnumerator.Current
		{
			[DebuggerHidden]
			private get { } //Length: 5
		}

		[DebuggerHidden]
		public <ParseCrls>d__13(int <>1__state) { }

		private override bool MoveNext() { }

		[DebuggerHidden]
		private override IEnumerator<X509Crl> System.Collections.Generic.IEnumerable<Best.HTTP.SecureProtocol.Org.BouncyCastle.X509.X509Crl>.GetEnumerator() { }

		[DebuggerHidden]
		private override X509Crl System.Collections.Generic.IEnumerator<Best.HTTP.SecureProtocol.Org.BouncyCastle.X509.X509Crl>.get_Current() { }

		[DebuggerHidden]
		private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

		[DebuggerHidden]
		private override object System.Collections.IEnumerator.get_Current() { }

		[DebuggerHidden]
		private override void System.Collections.IEnumerator.Reset() { }

		[DebuggerHidden]
		private override void System.IDisposable.Dispose() { }

	}

	private static readonly PemParser PemCrlParser; //Field offset: 0x0
	private readonly bool lazyAsn1; //Field offset: 0x10
	private Asn1Set sCrlData; //Field offset: 0x18
	private int sCrlDataObjectCount; //Field offset: 0x20
	private Stream currentCrlStream; //Field offset: 0x28

	private static X509CrlParser() { }

	public X509CrlParser(bool lazyAsn1 = false) { }

	private X509Crl GetCrl() { }

	[IteratorStateMachine(typeof(<ParseCrls>d__13))]
	public IEnumerable<X509Crl> ParseCrls(Stream inStream) { }

	public X509Crl ReadCrl(Byte[] input) { }

	public X509Crl ReadCrl(Stream inStream) { }

	public IList<X509Crl> ReadCrls(Byte[] input) { }

	public IList<X509Crl> ReadCrls(Stream inStream) { }

	private X509Crl ReadDerCrl(Asn1InputStream dIn) { }

	private X509Crl ReadPemCrl(Stream inStream) { }

}

