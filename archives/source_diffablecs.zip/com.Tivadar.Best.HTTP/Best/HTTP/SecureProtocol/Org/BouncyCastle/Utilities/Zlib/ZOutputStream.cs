namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities.Zlib;

public class ZOutputStream : BaseOutputStream
{
	private const int BufferSize = 4096; //Field offset: 0x0
	protected ZStream z; //Field offset: 0x28
	protected int flushLevel; //Field offset: 0x30
	protected Byte[] buf; //Field offset: 0x38
	protected Byte[] buf1; //Field offset: 0x40
	protected bool compress; //Field offset: 0x48
	protected Stream output; //Field offset: 0x50
	protected bool closed; //Field offset: 0x58

	public override int FlushMode
	{
		 get { } //Length: 4
		 set { } //Length: 4
	}

	public override long TotalIn
	{
		 get { } //Length: 27
	}

	public override long TotalOut
	{
		 get { } //Length: 27
	}

	public ZOutputStream(Stream output) { }

	public ZOutputStream(Stream output, bool nowrap) { }

	public ZOutputStream(Stream output, ZStream z) { }

	public ZOutputStream(Stream output, int level) { }

	public ZOutputStream(Stream output, int level, bool nowrap) { }

	protected void Detach(bool disposing) { }

	protected virtual void Dispose(bool disposing) { }

	public override void End() { }

	public override void Finish() { }

	public virtual void Flush() { }

	public override int get_FlushMode() { }

	public override long get_TotalIn() { }

	public override long get_TotalOut() { }

	private static ZStream GetDefaultZStream(bool nowrap) { }

	public override void set_FlushMode(int value) { }

	public virtual void Write(Byte[] buffer, int offset, int count) { }

	public virtual void WriteByte(byte value) { }

}

