namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities.IO;

internal class LimitedInputStream : BaseInputStream
{
	private readonly Stream m_stream; //Field offset: 0x28
	private long m_limit; //Field offset: 0x30

	internal long CurrentLimit
	{
		internal get { } //Length: 5
	}

	internal LimitedInputStream(Stream stream, long limit) { }

	internal long get_CurrentLimit() { }

	public virtual int Read(Byte[] buffer, int offset, int count) { }

	public virtual int Read(Span<Byte> buffer) { }

	public virtual int ReadByte() { }

}

