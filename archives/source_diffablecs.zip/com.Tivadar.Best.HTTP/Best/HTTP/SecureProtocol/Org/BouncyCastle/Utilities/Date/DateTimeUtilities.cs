namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities.Date;

public static class DateTimeUtilities
{
	public static readonly DateTime UnixEpoch; //Field offset: 0x0
	public static readonly long MaxUnixMs; //Field offset: 0x8
	public static readonly long MinUnixMs; //Field offset: 0x10

	private static DateTimeUtilities() { }

	public static long CurrentUnixMs() { }

	public static long DateTimeToUnixMs(DateTime dateTime) { }

	public static DateTime UnixMsToDateTime(long unixMs) { }

	public static DateTime WithPrecisionCentisecond(DateTime dateTime) { }

	public static DateTime WithPrecisionDecisecond(DateTime dateTime) { }

	public static DateTime WithPrecisionMillisecond(DateTime dateTime) { }

	public static DateTime WithPrecisionSecond(DateTime dateTime) { }

}

