namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities.Collections;

internal class ReadOnlyDictionaryProxy : ReadOnlyDictionary<K, V>
{
	private readonly IDictionary<K, V> m_target; //Field offset: 0x0

	public virtual int Count
	{
		 get { } //Length: 70
	}

	public virtual ICollection<K> Keys
	{
		 get { } //Length: 181
	}

	public virtual ICollection<V> Values
	{
		 get { } //Length: 181
	}

	internal ReadOnlyDictionaryProxy`2(IDictionary<K, V> target) { }

	public virtual bool Contains(KeyValuePair<K, V> item) { }

	public virtual bool ContainsKey(K key) { }

	public virtual void CopyTo(KeyValuePair<K, V>[] array, int arrayIndex) { }

	public virtual int get_Count() { }

	public virtual ICollection<K> get_Keys() { }

	public virtual ICollection<V> get_Values() { }

	public virtual IEnumerator<KeyValuePair`2<K, V>> GetEnumerator() { }

	protected virtual V Lookup(K key) { }

	public virtual bool TryGetValue(K key, out V value) { }

}

