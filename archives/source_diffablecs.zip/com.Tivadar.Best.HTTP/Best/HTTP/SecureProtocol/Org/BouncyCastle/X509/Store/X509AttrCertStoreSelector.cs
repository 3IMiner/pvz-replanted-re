namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.X509.Store;

public class X509AttrCertStoreSelector : ISelector<X509V2AttributeCertificate>, ICloneable
{
	private X509V2AttributeCertificate attributeCert; //Field offset: 0x10
	private Nullable<DateTime> attributeCertificateValid; //Field offset: 0x18
	private AttributeCertificateHolder holder; //Field offset: 0x28
	private AttributeCertificateIssuer issuer; //Field offset: 0x30
	private BigInteger serialNumber; //Field offset: 0x38
	private ISet<GeneralName> targetNames; //Field offset: 0x40
	private ISet<GeneralName> targetGroups; //Field offset: 0x48

	public X509V2AttributeCertificate AttributeCert
	{
		 get { } //Length: 5
		 set { } //Length: 13
	}

	public Nullable<DateTime> AttributeCertificateValid
	{
		 get { } //Length: 11
		 set { } //Length: 8
	}

	public AttributeCertificateHolder Holder
	{
		 get { } //Length: 5
		 set { } //Length: 13
	}

	public AttributeCertificateIssuer Issuer
	{
		 get { } //Length: 5
		 set { } //Length: 13
	}

	public BigInteger SerialNumber
	{
		 get { } //Length: 5
		 set { } //Length: 13
	}

	public X509AttrCertStoreSelector() { }

	private X509AttrCertStoreSelector(X509AttrCertStoreSelector o) { }

	public void AddTargetGroup(Byte[] name) { }

	public void AddTargetGroup(GeneralName group) { }

	public void AddTargetName(Byte[] name) { }

	public void AddTargetName(GeneralName name) { }

	public override object Clone() { }

	private ISet<GeneralName> ExtractGeneralNames(IEnumerable<Object> names) { }

	public X509V2AttributeCertificate get_AttributeCert() { }

	public Nullable<DateTime> get_AttributeCertificateValid() { }

	public AttributeCertificateHolder get_Holder() { }

	public AttributeCertificateIssuer get_Issuer() { }

	public BigInteger get_SerialNumber() { }

	public IEnumerable<GeneralName> GetTargetGroups() { }

	public IEnumerable<GeneralName> GetTargetNames() { }

	public override bool Match(X509V2AttributeCertificate attrCert) { }

	public void set_AttributeCert(X509V2AttributeCertificate value) { }

	public void set_AttributeCertificateValid(Nullable<DateTime> value) { }

	public void set_Holder(AttributeCertificateHolder value) { }

	public void set_Issuer(AttributeCertificateIssuer value) { }

	public void set_SerialNumber(BigInteger value) { }

	public void SetTargetGroups(IEnumerable<Object> names) { }

	public void SetTargetNames(IEnumerable<Object> names) { }

}

