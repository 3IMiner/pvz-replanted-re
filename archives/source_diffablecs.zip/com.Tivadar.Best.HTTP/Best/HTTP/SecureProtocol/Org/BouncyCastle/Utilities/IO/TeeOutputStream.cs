namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities.IO;

public class TeeOutputStream : BaseOutputStream
{
	private readonly Stream output; //Field offset: 0x28
	private readonly Stream tee; //Field offset: 0x30

	public TeeOutputStream(Stream output, Stream tee) { }

	protected virtual void Dispose(bool disposing) { }

	public virtual void Write(Byte[] buffer, int offset, int count) { }

	public virtual void Write(ReadOnlySpan<Byte> buffer) { }

	public virtual void WriteByte(byte value) { }

}

