namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities.Encoders;

public class UrlBase64
{
	private static readonly IEncoder encoder; //Field offset: 0x0

	private static UrlBase64() { }

	public UrlBase64() { }

	public static Byte[] Decode(Byte[] data) { }

	public static int Decode(Byte[] data, Stream outStr) { }

	public static Byte[] Decode(string data) { }

	public static int Decode(string data, Stream outStr) { }

	public static Byte[] Encode(Byte[] data) { }

	public static int Encode(Byte[] data, Stream outStr) { }

}

