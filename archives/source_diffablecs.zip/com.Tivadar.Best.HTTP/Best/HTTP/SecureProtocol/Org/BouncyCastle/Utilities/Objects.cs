namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities;

public static class Objects
{

	public static int GetHashCode(object obj) { }

}

