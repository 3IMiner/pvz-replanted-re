namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities.IO.Pem;

public class PemHeader
{
	private string name; //Field offset: 0x10
	private string val; //Field offset: 0x18

	public override string Name
	{
		 get { } //Length: 5
	}

	public override string Value
	{
		 get { } //Length: 5
	}

	public PemHeader(string name, string val) { }

	public virtual bool Equals(object obj) { }

	public override string get_Name() { }

	public override string get_Value() { }

	public virtual int GetHashCode() { }

	private int GetHashCode(string s) { }

	public virtual string ToString() { }

}

