namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities.Collections;

public abstract class CollectionUtilities
{

	protected CollectionUtilities() { }

	public static void CollectMatches(ICollection<T> matches, ISelector<T> selector, IEnumerable<IStore`1<T>> stores) { }

	public static IStore<T> CreateStore(IEnumerable<T> contents) { }

	public static T GetValueOrKey(IDictionary<T, T> d, T k) { }

	public static V GetValueOrNull(IDictionary<K, V> d, K k) { }

	public static IEnumerable<T> Proxy(IEnumerable<T> e) { }

	public static ICollection<T> ReadOnly(ICollection<T> c) { }

	public static IDictionary<K, V> ReadOnly(IDictionary<K, V> d) { }

	public static IList<T> ReadOnly(IList<T> l) { }

	public static ISet<T> ReadOnly(ISet<T> s) { }

	public static bool Remove(IDictionary<K, V> d, K k, out V v) { }

	public static T RequireNext(IEnumerator<T> e) { }

	public static string ToString(IEnumerable<T> c) { }

}

