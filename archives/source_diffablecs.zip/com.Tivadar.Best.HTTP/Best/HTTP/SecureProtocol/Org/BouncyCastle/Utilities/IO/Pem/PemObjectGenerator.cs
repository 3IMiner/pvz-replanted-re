namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities.IO.Pem;

public interface PemObjectGenerator
{

	public PemObject Generate() { }

}

