namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.X509.Extension;

public class SubjectKeyIdentifierStructure : SubjectKeyIdentifier
{

	public SubjectKeyIdentifierStructure(Asn1OctetString encodedValue) { }

	public SubjectKeyIdentifierStructure(AsymmetricKeyParameter pubKey) { }

	private static Asn1OctetString FromPublicKey(AsymmetricKeyParameter pubKey) { }

}

