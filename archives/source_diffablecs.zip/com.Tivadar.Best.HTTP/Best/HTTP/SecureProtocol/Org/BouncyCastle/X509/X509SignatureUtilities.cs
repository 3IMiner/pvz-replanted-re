namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.X509;

internal class X509SignatureUtilities
{
	private static readonly Asn1Null derNull; //Field offset: 0x0

	private static X509SignatureUtilities() { }

	public X509SignatureUtilities() { }

	private static string GetDigestAlgName(DerObjectIdentifier digestAlgOID) { }

	internal static string GetSignatureName(AlgorithmIdentifier sigAlgId) { }

	internal static void SetSignatureParameters(ISigner signature, Asn1Encodable parameters) { }

}

