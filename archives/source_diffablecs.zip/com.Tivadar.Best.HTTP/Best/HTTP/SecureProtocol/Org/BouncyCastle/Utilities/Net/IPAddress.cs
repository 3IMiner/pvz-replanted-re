namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities.Net;

public class IPAddress
{

	public IPAddress() { }

	private static bool IsMaskValue(string component, int size) { }

	public static bool IsValid(string address) { }

	public static bool IsValidIPv4(string address) { }

	public static bool IsValidIPv4WithNetmask(string address) { }

	public static bool IsValidIPv6(string address) { }

	public static bool IsValidIPv6WithNetmask(string address) { }

	public static bool IsValidWithNetMask(string address) { }

	private static bool unsafeIsValidIPv4(string address) { }

	private static bool unsafeIsValidIPv6(string address) { }

}

