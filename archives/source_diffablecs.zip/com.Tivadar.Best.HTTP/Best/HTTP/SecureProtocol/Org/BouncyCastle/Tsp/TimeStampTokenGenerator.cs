namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Tsp;

public class TimeStampTokenGenerator
{
	private class TableGen : CmsAttributeTableGenerator
	{
		private readonly SignerInfoGenerator infoGen; //Field offset: 0x10
		private readonly EssCertID essCertID; //Field offset: 0x18

		public TableGen(SignerInfoGenerator infoGen, EssCertID essCertID) { }

		public override AttributeTable GetAttributes(IDictionary<CmsAttributeTableParameter, Object> parameters) { }

	}

	private class TableGen2 : CmsAttributeTableGenerator
	{
		private readonly SignerInfoGenerator infoGen; //Field offset: 0x10
		private readonly EssCertIDv2 essCertID; //Field offset: 0x18

		public TableGen2(SignerInfoGenerator infoGen, EssCertIDv2 essCertID) { }

		public override AttributeTable GetAttributes(IDictionary<CmsAttributeTableParameter, Object> parameters) { }

	}

	private int accuracySeconds; //Field offset: 0x10
	private int accuracyMillis; //Field offset: 0x14
	private int accuracyMicros; //Field offset: 0x18
	private bool ordering; //Field offset: 0x1C
	private GeneralName tsa; //Field offset: 0x20
	private DerObjectIdentifier tsaPolicyOID; //Field offset: 0x28
	private IStore<X509Certificate> x509Certs; //Field offset: 0x30
	private IStore<X509Crl> x509Crls; //Field offset: 0x38
	private IStore<X509V2AttributeCertificate> x509AttrCerts; //Field offset: 0x40
	private SignerInfoGenerator signerInfoGenerator; //Field offset: 0x48
	private IDigestFactory digestCalculator; //Field offset: 0x50
	private Resolution resolution; //Field offset: 0x58

	public Resolution Resolution
	{
		 get { } //Length: 4
		 set { } //Length: 4
	}

	public TimeStampTokenGenerator(AsymmetricKeyParameter key, X509Certificate cert, string digestOID, string tsaPolicyOID) { }

	public TimeStampTokenGenerator(SignerInfoGenerator signerInfoGen, IDigestFactory digestCalculator, DerObjectIdentifier tsaPolicy, bool isIssuerSerialIncluded) { }

	public TimeStampTokenGenerator(AsymmetricKeyParameter key, X509Certificate cert, string digestOID, string tsaPolicyOID, AttributeTable signedAttr, AttributeTable unsignedAttr) { }

	public TimeStampToken Generate(TimeStampRequest request, BigInteger serialNumber, DateTime genTime, X509Extensions additionalExtensions) { }

	public TimeStampToken Generate(TimeStampRequest request, BigInteger serialNumber, DateTime genTime) { }

	public Resolution get_Resolution() { }

	internal static SignerInfoGenerator makeInfoGenerator(AsymmetricKeyParameter key, X509Certificate cert, string digestOID, AttributeTable signedAttr, AttributeTable unsignedAttr) { }

	public void set_Resolution(Resolution value) { }

	public void SetAccuracyMicros(int accuracyMicros) { }

	public void SetAccuracyMillis(int accuracyMillis) { }

	public void SetAccuracySeconds(int accuracySeconds) { }

	public void SetAttributeCertificates(IStore<X509V2AttributeCertificate> attributeCertificates) { }

	public void SetCertificates(IStore<X509Certificate> certificates) { }

	public void SetCrls(IStore<X509Crl> crls) { }

	public void SetOrdering(bool ordering) { }

	public void SetTsa(GeneralName tsa) { }

	private static DateTime WithResolution(DateTime dateTime, Resolution resolution) { }

}

