namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.X509;

public abstract class X509ExtensionBase : IX509Extension
{

	protected X509ExtensionBase() { }

	public override ISet<String> GetCriticalExtensionOids() { }

	protected override ISet<String> GetExtensionOids(bool critical) { }

	public override Asn1OctetString GetExtensionValue(DerObjectIdentifier oid) { }

	public override ISet<String> GetNonCriticalExtensionOids() { }

	protected abstract X509Extensions GetX509Extensions() { }

}

