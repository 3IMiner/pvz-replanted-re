namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.X509;

public class X509Attribute : Asn1Encodable
{
	private readonly AttributeX509 attr; //Field offset: 0x10

	public string Oid
	{
		 get { } //Length: 36
	}

	internal X509Attribute(Asn1Encodable at) { }

	public X509Attribute(string oid, Asn1Encodable value) { }

	public X509Attribute(string oid, Asn1EncodableVector value) { }

	public string get_Oid() { }

	public Asn1Encodable[] GetValues() { }

	public virtual Asn1Object ToAsn1Object() { }

}

