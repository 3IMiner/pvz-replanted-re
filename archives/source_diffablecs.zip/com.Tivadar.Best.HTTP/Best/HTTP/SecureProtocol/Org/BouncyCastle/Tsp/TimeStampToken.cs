namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Tsp;

public class TimeStampToken
{
	private class CertID
	{
		private EssCertID certID; //Field offset: 0x10
		private EssCertIDv2 certIDv2; //Field offset: 0x18

		public IssuerSerial IssuerSerial
		{
			 get { } //Length: 47
		}

		internal CertID(EssCertID certID) { }

		internal CertID(EssCertIDv2 certID) { }

		public IssuerSerial get_IssuerSerial() { }

		public Byte[] GetCertHash() { }

		public AlgorithmIdentifier GetHashAlgorithm() { }

		public string GetHashAlgorithmName() { }

	}

	private readonly CmsSignedData tsToken; //Field offset: 0x10
	private readonly SignerInformation tsaSignerInfo; //Field offset: 0x18
	private readonly TimeStampTokenInfo tstInfo; //Field offset: 0x20
	private readonly CertID certID; //Field offset: 0x28

	public AttributeTable SignedAttributes
	{
		 get { } //Length: 29
	}

	public SignerID SignerID
	{
		 get { } //Length: 27
	}

	public TimeStampTokenInfo TimeStampInfo
	{
		 get { } //Length: 5
	}

	public AttributeTable UnsignedAttributes
	{
		 get { } //Length: 29
	}

	public TimeStampToken(ContentInfo contentInfo) { }

	public TimeStampToken(CmsSignedData signedData) { }

	public AttributeTable get_SignedAttributes() { }

	public SignerID get_SignerID() { }

	public TimeStampTokenInfo get_TimeStampInfo() { }

	public AttributeTable get_UnsignedAttributes() { }

	public IStore<X509V2AttributeCertificate> GetAttributeCertificates() { }

	public IStore<X509Certificate> GetCertificates() { }

	public IStore<X509Crl> GetCrls() { }

	public Byte[] GetEncoded() { }

	public Byte[] GetEncoded(string encoding) { }

	public CmsSignedData ToCmsSignedData() { }

	public void Validate(X509Certificate cert) { }

}

