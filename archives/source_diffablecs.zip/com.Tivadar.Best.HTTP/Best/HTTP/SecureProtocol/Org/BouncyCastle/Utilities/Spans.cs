namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities;

[Extension]
internal static class Spans
{

	[Extension]
	internal static void CopyFrom(Span<T> output, ReadOnlySpan<T> input) { }

	internal static Span<T> FromNullable(T[] array) { }

	internal static Span<T> FromNullable(T[] array, int start) { }

	internal static ReadOnlySpan<T> FromNullableReadOnly(T[] array) { }

	internal static ReadOnlySpan<T> FromNullableReadOnly(T[] array, int start) { }

}

