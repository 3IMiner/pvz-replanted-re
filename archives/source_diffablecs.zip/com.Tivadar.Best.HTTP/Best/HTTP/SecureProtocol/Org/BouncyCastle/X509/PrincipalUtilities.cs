namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.X509;

public class PrincipalUtilities
{

	public PrincipalUtilities() { }

	public static X509Name GetIssuerX509Principal(X509Certificate cert) { }

	public static X509Name GetIssuerX509Principal(X509Crl crl) { }

	public static X509Name GetSubjectX509Principal(X509Certificate cert) { }

}

