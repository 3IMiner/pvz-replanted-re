namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities.Collections;

public interface IStore
{

	public IEnumerable<T> EnumerateMatches(ISelector<T> selector) { }

}

