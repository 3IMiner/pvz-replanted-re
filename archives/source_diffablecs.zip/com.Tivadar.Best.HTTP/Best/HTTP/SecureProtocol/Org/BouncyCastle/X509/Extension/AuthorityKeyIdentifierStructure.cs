namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.X509.Extension;

public class AuthorityKeyIdentifierStructure : AuthorityKeyIdentifier
{

	public AuthorityKeyIdentifierStructure(Asn1OctetString encodedValue) { }

	public AuthorityKeyIdentifierStructure(X509Certificate certificate) { }

	public AuthorityKeyIdentifierStructure(AsymmetricKeyParameter pubKey) { }

	private static Asn1Sequence FromCertificate(X509Certificate certificate) { }

	private static Asn1Sequence FromKey(AsymmetricKeyParameter pubKey) { }

}

