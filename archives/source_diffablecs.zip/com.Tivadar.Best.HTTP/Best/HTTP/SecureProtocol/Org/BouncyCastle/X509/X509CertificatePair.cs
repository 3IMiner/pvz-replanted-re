namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.X509;

public class X509CertificatePair
{
	private readonly X509Certificate forward; //Field offset: 0x10
	private readonly X509Certificate reverse; //Field offset: 0x18

	public X509Certificate Forward
	{
		 get { } //Length: 5
	}

	public X509Certificate Reverse
	{
		 get { } //Length: 5
	}

	public X509CertificatePair(X509Certificate forward, X509Certificate reverse) { }

	public X509CertificatePair(CertificatePair pair) { }

	public virtual bool Equals(object obj) { }

	public X509Certificate get_Forward() { }

	public X509Certificate get_Reverse() { }

	public Byte[] GetEncoded() { }

	public virtual int GetHashCode() { }

}

