namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities;

public class MemoableResetException : InvalidCastException
{

	public MemoableResetException() { }

	public MemoableResetException(string message) { }

	public MemoableResetException(string message, Exception innerException) { }

	protected MemoableResetException(SerializationInfo info, StreamingContext context) { }

}

