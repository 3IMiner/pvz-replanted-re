namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Tsp;

public static class TspAlgorithms
{
	public static readonly string MD5; //Field offset: 0x0
	public static readonly string Sha1; //Field offset: 0x8
	public static readonly string Sha224; //Field offset: 0x10
	public static readonly string Sha256; //Field offset: 0x18
	public static readonly string Sha384; //Field offset: 0x20
	public static readonly string Sha512; //Field offset: 0x28
	public static readonly string RipeMD128; //Field offset: 0x30
	public static readonly string RipeMD160; //Field offset: 0x38
	public static readonly string RipeMD256; //Field offset: 0x40
	public static readonly string Gost3411; //Field offset: 0x48
	public static readonly string Gost3411_2012_256; //Field offset: 0x50
	public static readonly string Gost3411_2012_512; //Field offset: 0x58
	public static readonly string SM3; //Field offset: 0x60
	public static readonly IList<String> Allowed; //Field offset: 0x68

	private static TspAlgorithms() { }

}

