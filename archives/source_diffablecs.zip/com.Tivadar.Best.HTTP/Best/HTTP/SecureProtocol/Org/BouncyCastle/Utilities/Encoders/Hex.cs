namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities.Encoders;

public sealed class Hex
{
	private static readonly HexEncoder encoder; //Field offset: 0x0

	private static Hex() { }

	private Hex() { }

	public static Byte[] Decode(Byte[] data) { }

	public static Byte[] Decode(string data) { }

	public static int Decode(string data, Stream outStream) { }

	public static Byte[] DecodeStrict(string str) { }

	public static Byte[] DecodeStrict(string str, int off, int len) { }

	public static Byte[] Encode(Byte[] data) { }

	public static Byte[] Encode(Byte[] data, int off, int length) { }

	public static int Encode(Byte[] data, Stream outStream) { }

	public static int Encode(Byte[] data, int off, int length, Stream outStream) { }

	public static string ToHexString(Byte[] data) { }

	public static string ToHexString(Byte[] data, int off, int length) { }

}

