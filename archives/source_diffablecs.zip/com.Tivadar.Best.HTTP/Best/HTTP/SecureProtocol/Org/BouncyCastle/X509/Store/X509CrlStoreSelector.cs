namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.X509.Store;

public class X509CrlStoreSelector : ISelector<X509Crl>, ICloneable
{
	private X509Certificate certificateChecking; //Field offset: 0x10
	private Nullable<DateTime> dateAndTime; //Field offset: 0x18
	private IList<X509Name> issuers; //Field offset: 0x28
	private BigInteger maxCrlNumber; //Field offset: 0x30
	private BigInteger minCrlNumber; //Field offset: 0x38
	private X509V2AttributeCertificate attrCertChecking; //Field offset: 0x40
	private bool completeCrlEnabled; //Field offset: 0x48
	private bool deltaCrlIndicatorEnabled; //Field offset: 0x49
	private Byte[] issuingDistributionPoint; //Field offset: 0x50
	private bool issuingDistributionPointEnabled; //Field offset: 0x58
	private BigInteger maxBaseCrlNumber; //Field offset: 0x60

	public X509V2AttributeCertificate AttrCertChecking
	{
		 get { } //Length: 5
		 set { } //Length: 13
	}

	public X509Certificate CertificateChecking
	{
		 get { } //Length: 5
		 set { } //Length: 13
	}

	public bool CompleteCrlEnabled
	{
		 get { } //Length: 5
		 set { } //Length: 4
	}

	public Nullable<DateTime> DateAndTime
	{
		 get { } //Length: 11
		 set { } //Length: 8
	}

	public bool DeltaCrlIndicatorEnabled
	{
		 get { } //Length: 5
		 set { } //Length: 4
	}

	public IList<X509Name> Issuers
	{
		 get { } //Length: 104
		 set { } //Length: 125
	}

	public Byte[] IssuingDistributionPoint
	{
		 get { } //Length: 165
		 set { } //Length: 190
	}

	public bool IssuingDistributionPointEnabled
	{
		 get { } //Length: 5
		 set { } //Length: 4
	}

	public BigInteger MaxBaseCrlNumber
	{
		 get { } //Length: 5
		 set { } //Length: 13
	}

	public BigInteger MaxCrlNumber
	{
		 get { } //Length: 5
		 set { } //Length: 13
	}

	public BigInteger MinCrlNumber
	{
		 get { } //Length: 5
		 set { } //Length: 13
	}

	public X509CrlStoreSelector() { }

	public X509CrlStoreSelector(X509CrlStoreSelector o) { }

	public override object Clone() { }

	public X509V2AttributeCertificate get_AttrCertChecking() { }

	public X509Certificate get_CertificateChecking() { }

	public bool get_CompleteCrlEnabled() { }

	public Nullable<DateTime> get_DateAndTime() { }

	public bool get_DeltaCrlIndicatorEnabled() { }

	public IList<X509Name> get_Issuers() { }

	public Byte[] get_IssuingDistributionPoint() { }

	public bool get_IssuingDistributionPointEnabled() { }

	public BigInteger get_MaxBaseCrlNumber() { }

	public BigInteger get_MaxCrlNumber() { }

	public BigInteger get_MinCrlNumber() { }

	public override bool Match(X509Crl c) { }

	public void set_AttrCertChecking(X509V2AttributeCertificate value) { }

	public void set_CertificateChecking(X509Certificate value) { }

	public void set_CompleteCrlEnabled(bool value) { }

	public void set_DateAndTime(Nullable<DateTime> value) { }

	public void set_DeltaCrlIndicatorEnabled(bool value) { }

	public void set_Issuers(IList<X509Name> value) { }

	public void set_IssuingDistributionPoint(Byte[] value) { }

	public void set_IssuingDistributionPointEnabled(bool value) { }

	public void set_MaxBaseCrlNumber(BigInteger value) { }

	public void set_MaxCrlNumber(BigInteger value) { }

	public void set_MinCrlNumber(BigInteger value) { }

}

