namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities.Bzip2;

internal class CRC
{
	private static readonly UInt32[] Crc32Table; //Field offset: 0x0
	private uint m_value; //Field offset: 0x10

	private static CRC() { }

	public CRC() { }

	internal int GetFinal() { }

	internal void Initialise() { }

	internal void Update(byte inCh) { }

	internal void UpdateRun(byte inCh, int runLength) { }

}

