namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities.IO;

public static class Streams
{
	private const int BufferSize = 4096; //Field offset: 0x0

	public static void Drain(Stream inStr) { }

	public static void PipeAll(Stream inStr, Stream outStr) { }

	public static void PipeAll(Stream inStr, Stream outStr, int bufferSize) { }

	public static long PipeAllLimited(Stream inStr, long limit, Stream outStr) { }

	public static Byte[] ReadAll(Stream inStr) { }

	public static Byte[] ReadAll(MemoryStream inStr) { }

	public static Byte[] ReadAllLimited(Stream inStr, int limit) { }

	public static int ReadFully(Stream inStr, Byte[] buf) { }

	public static int ReadFully(Stream inStr, Byte[] buf, int off, int len) { }

	public static int ReadFully(Stream inStr, Span<Byte> buffer) { }

	public static void ValidateBufferArguments(Byte[] buffer, int offset, int count) { }

	public static int WriteBufTo(MemoryStream buf, Byte[] output, int offset) { }

}

