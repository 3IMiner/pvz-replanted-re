namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Tsp;

public class TimeStampResponse
{
	private TimeStampResp resp; //Field offset: 0x10
	private TimeStampToken timeStampToken; //Field offset: 0x18

	public int Status
	{
		 get { } //Length: 53
	}

	public TimeStampToken TimeStampToken
	{
		 get { } //Length: 5
	}

	public TimeStampResponse(TimeStampResp resp) { }

	public TimeStampResponse(Byte[] resp) { }

	public TimeStampResponse(Stream input) { }

	public int get_Status() { }

	public TimeStampToken get_TimeStampToken() { }

	public Byte[] GetEncoded() { }

	public PkiFailureInfo GetFailInfo() { }

	public string GetStatusString() { }

	private static TimeStampResp readTimeStampResp(Asn1InputStream input) { }

	public void Validate(TimeStampRequest request) { }

}

