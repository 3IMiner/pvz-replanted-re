namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities.IO.Pem;

public class PemGenerationException : Exception
{

	public PemGenerationException() { }

	public PemGenerationException(string message) { }

	public PemGenerationException(string message, Exception innerException) { }

	protected PemGenerationException(SerializationInfo info, StreamingContext context) { }

}

