namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Tsp;

public class TspValidationException : TspException
{
	protected readonly int m_failureCode; //Field offset: 0x90

	public int FailureCode
	{
		 get { } //Length: 7
	}

	public TspValidationException(string message) { }

	public TspValidationException(string message, int failureCode) { }

	protected TspValidationException(SerializationInfo info, StreamingContext context) { }

	public int get_FailureCode() { }

	public virtual void GetObjectData(SerializationInfo info, StreamingContext context) { }

}

