namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities.IO.Pem;

public interface PemObjectParser
{

	public object ParseObject(PemObject obj) { }

}

