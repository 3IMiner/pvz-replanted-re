namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities.Encoders;

public class UrlBase64Encoder : Base64Encoder
{

	public UrlBase64Encoder() { }

}

