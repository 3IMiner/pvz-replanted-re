namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.X509;

public class AttributeCertificateHolder : ISelector<X509Certificate>, ICloneable
{
	internal readonly Holder holder; //Field offset: 0x10

	public string DigestAlgorithm
	{
		 get { } //Length: 74
	}

	public int DigestedObjectType
	{
		 get { } //Length: 57
	}

	public string OtherObjectTypeID
	{
		 get { } //Length: 50
	}

	public BigInteger SerialNumber
	{
		 get { } //Length: 56
	}

	internal AttributeCertificateHolder(Asn1Sequence seq) { }

	public AttributeCertificateHolder(X509Name issuerName, BigInteger serialNumber) { }

	public AttributeCertificateHolder(X509Certificate cert) { }

	public AttributeCertificateHolder(X509Name principal) { }

	public AttributeCertificateHolder(int digestedObjectType, string digestAlgorithm, string otherObjectTypeID, Byte[] objectDigest) { }

	public override object Clone() { }

	public virtual bool Equals(object obj) { }

	private GeneralNames GenerateGeneralNames(X509Name principal) { }

	public string get_DigestAlgorithm() { }

	public int get_DigestedObjectType() { }

	public string get_OtherObjectTypeID() { }

	public BigInteger get_SerialNumber() { }

	public X509Name[] GetEntityNames() { }

	public virtual int GetHashCode() { }

	public X509Name[] GetIssuer() { }

	private Object[] GetNames(GeneralName[] names) { }

	public Byte[] GetObjectDigest() { }

	private X509Name[] GetPrincipals(GeneralNames names) { }

	public override bool Match(X509Certificate x509Cert) { }

	private bool MatchesDN(X509Name subject, GeneralNames targets) { }

}

