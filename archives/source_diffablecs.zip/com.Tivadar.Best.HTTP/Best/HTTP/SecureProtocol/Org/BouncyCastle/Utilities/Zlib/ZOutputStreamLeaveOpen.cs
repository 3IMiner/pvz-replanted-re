namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities.Zlib;

public class ZOutputStreamLeaveOpen : ZOutputStream
{

	public ZOutputStreamLeaveOpen(Stream output) { }

	public ZOutputStreamLeaveOpen(Stream output, bool nowrap) { }

	public ZOutputStreamLeaveOpen(Stream output, ZStream z) { }

	public ZOutputStreamLeaveOpen(Stream output, int level) { }

	public ZOutputStreamLeaveOpen(Stream output, int level, bool nowrap) { }

	protected virtual void Dispose(bool disposing) { }

}

