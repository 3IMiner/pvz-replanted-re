namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.X509;

public static class SubjectPublicKeyInfoFactory
{

	public static SubjectPublicKeyInfo CreateSubjectPublicKeyInfo(AsymmetricKeyParameter publicKey) { }

	private static void ExtractBytes(Byte[] encKey, int offset, BigInteger bI) { }

	private static void ExtractBytes(Byte[] encKey, int size, int offSet, BigInteger bI) { }

}

