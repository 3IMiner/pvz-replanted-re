namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities.Encoders;

public sealed class Base64
{

	private Base64() { }

	public static Byte[] Decode(Byte[] data) { }

	public static Byte[] Decode(string data) { }

	public static int Decode(string data, Stream outStream) { }

	public static Byte[] Encode(Byte[] data) { }

	public static Byte[] Encode(Byte[] data, int off, int length) { }

	public static int Encode(Byte[] data, Stream outStream) { }

	public static int Encode(Byte[] data, int off, int length, Stream outStream) { }

	public static string ToBase64String(Byte[] data) { }

	public static string ToBase64String(Byte[] data, int off, int length) { }

}

