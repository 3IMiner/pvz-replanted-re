namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities;

public interface IMemoable
{

	public IMemoable Copy() { }

	public void Reset(IMemoable other) { }

}

