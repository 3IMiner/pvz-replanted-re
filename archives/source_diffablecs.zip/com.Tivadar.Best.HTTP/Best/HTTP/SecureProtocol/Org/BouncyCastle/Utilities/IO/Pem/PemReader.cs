namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities.IO.Pem;

public class PemReader : IDisposable
{
	private readonly TextReader reader; //Field offset: 0x10
	private readonly MemoryStream buffer; //Field offset: 0x18
	private readonly StreamWriter textBuffer; //Field offset: 0x20
	private readonly List<Int32> pushback; //Field offset: 0x28
	private int c; //Field offset: 0x30

	public TextReader Reader
	{
		 get { } //Length: 5
	}

	public PemReader(TextReader reader) { }

	private string bufferedString() { }

	private bool bufferUntilStopChar(char stopChar, bool skipWhiteSpace) { }

	private bool consumeDash() { }

	public override void Dispose() { }

	protected override void Dispose(bool disposing) { }

	private bool expect(string value) { }

	public TextReader get_Reader() { }

	private void PushBack(int value) { }

	private int Read() { }

	public PemObject ReadPemObject() { }

	private bool seekColon(int upTo) { }

	private bool seekDash() { }

	private void skipWhiteSpace() { }

}

