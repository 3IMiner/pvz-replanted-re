namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities.Collections;

[DefaultMember("Item")]
internal abstract class ReadOnlyList : IList<T>, ICollection<T>, IEnumerable<T>, IEnumerable
{

	public abstract int Count
	{
		 get { } //Length: 0
	}

	public override bool IsReadOnly
	{
		 get { } //Length: 3
	}

	public override T Item
	{
		 get { } //Length: 20
		 set { } //Length: 57
	}

	protected ReadOnlyList`1() { }

	public override void Add(T item) { }

	public override void Clear() { }

	public abstract bool Contains(T item) { }

	public abstract void CopyTo(T[] array, int arrayIndex) { }

	public abstract int get_Count() { }

	public override bool get_IsReadOnly() { }

	public override T get_Item(int index) { }

	public abstract IEnumerator<T> GetEnumerator() { }

	public abstract int IndexOf(T item) { }

	public override void Insert(int index, T item) { }

	protected abstract T Lookup(int index) { }

	public override bool Remove(T item) { }

	public override void RemoveAt(int index) { }

	public override void set_Item(int index, T value) { }

	private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

}

