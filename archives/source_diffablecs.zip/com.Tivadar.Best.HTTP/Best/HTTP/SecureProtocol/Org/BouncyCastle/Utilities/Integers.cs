namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities;

public static class Integers
{
	public const int NumBits = 32; //Field offset: 0x0
	public const int NumBytes = 4; //Field offset: 0x0
	private static readonly Byte[] DeBruijnTZ; //Field offset: 0x0

	private static Integers() { }

	public static int HighestOneBit(int i) { }

	[CLSCompliant(False)]
	public static uint HighestOneBit(uint i) { }

	public static int LowestOneBit(int i) { }

	[CLSCompliant(False)]
	public static uint LowestOneBit(uint i) { }

	public static int NumberOfLeadingZeros(int i) { }

	public static int NumberOfTrailingZeros(int i) { }

	public static int Reverse(int i) { }

	[CLSCompliant(False)]
	public static uint Reverse(uint i) { }

	public static int ReverseBytes(int i) { }

	[CLSCompliant(False)]
	public static uint ReverseBytes(uint i) { }

	public static int RotateLeft(int i, int distance) { }

	[CLSCompliant(False)]
	public static uint RotateLeft(uint i, int distance) { }

	public static int RotateRight(int i, int distance) { }

	[CLSCompliant(False)]
	public static uint RotateRight(uint i, int distance) { }

}

