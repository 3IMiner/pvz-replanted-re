namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities;

public static class Arrays
{
	public static readonly Byte[] EmptyBytes; //Field offset: 0x0
	public static readonly Int32[] EmptyInts; //Field offset: 0x8

	private static Arrays() { }

	public static Int32[] Append(Int32[] a, int b) { }

	public static Int16[] Append(Int16[] a, short b) { }

	public static Byte[] Append(Byte[] a, byte b) { }

	public static bool AreAllZeroes(Byte[] buf, int off, int len) { }

	public static bool AreAllZeroes(ReadOnlySpan<Byte> buf) { }

	public static bool AreEqual(Byte[] a, int aFromIndex, int aToIndex, Byte[] b, int bFromIndex, int bToIndex) { }

	public static bool AreEqual(Char[] a, Char[] b) { }

	public static bool AreEqual(Byte[] a, Byte[] b) { }

	[CLSCompliant(False)]
	public static bool AreEqual(UInt64[] a, UInt64[] b) { }

	public static bool AreEqual(Int64[] a, Int64[] b) { }

	public static bool AreEqual(Boolean[] a, Boolean[] b) { }

	public static bool AreEqual(Int32[] a, Int32[] b) { }

	[CLSCompliant(False)]
	public static bool AreEqual(UInt32[] a, UInt32[] b) { }

	public static void Clear(Int32[] data) { }

	public static void Clear(Byte[] data) { }

	[CLSCompliant(False)]
	public static UInt16[] Clone(UInt16[] data) { }

	public static Int32[] Clone(Int32[] data) { }

	public static Byte[] Clone(Byte[] data) { }

	public static Boolean[] Clone(Boolean[] data) { }

	[CLSCompliant(False)]
	public static UInt64[] Clone(UInt64[] data, UInt64[] existing) { }

	[CLSCompliant(False)]
	public static UInt32[] Clone(UInt32[] data) { }

	public static Int64[] Clone(Int64[] data) { }

	public static Int16[] Clone(Int16[] data) { }

	public static Byte[] Clone(Byte[] data, Byte[] existing) { }

	[CLSCompliant(False)]
	public static UInt64[] Clone(UInt64[] data) { }

	[CLSCompliant(False)]
	public static UInt16[] Concatenate(UInt16[] a, UInt16[] b) { }

	public static Byte[] Concatenate(ReadOnlySpan<Byte> a, ReadOnlySpan<Byte> b, ReadOnlySpan<Byte> c, ReadOnlySpan<Byte> d) { }

	public static Int32[] Concatenate(Int32[] a, Int32[] b) { }

	[CLSCompliant(False)]
	public static UInt32[] Concatenate(UInt32[] a, UInt32[] b) { }

	public static Byte[] Concatenate(ReadOnlySpan<Byte> a, ReadOnlySpan<Byte> b) { }

	public static Byte[] Concatenate(ReadOnlySpan<Byte> a, ReadOnlySpan<Byte> b, ReadOnlySpan<Byte> c) { }

	public static Byte[] Concatenate(Byte[] a, Byte[] b) { }

	public static Byte[] ConcatenateAll(Byte[][] vs) { }

	public static bool ConstantTimeAreEqual(Span<Byte> a, Span<Byte> b) { }

	public static bool ConstantTimeAreEqual(int len, Byte[] a, int aOff, Byte[] b, int bOff) { }

	public static bool ConstantTimeAreEqual(Byte[] a, Byte[] b) { }

	public static bool Contains(Int32[] a, int n) { }

	public static bool Contains(Byte[] a, byte n) { }

	public static bool Contains(Int16[] a, short n) { }

	public static Char[] CopyOf(Char[] data, int newLength) { }

	public static BigInteger[] CopyOf(BigInteger[] data, int newLength) { }

	public static Int64[] CopyOf(Int64[] data, int newLength) { }

	[CLSCompliant(False)]
	public static UInt32[] CopyOf(UInt32[] data, int newLength) { }

	public static Int32[] CopyOf(Int32[] data, int newLength) { }

	public static Byte[] CopyOf(Byte[] data, int newLength) { }

	public static Int64[] CopyOfRange(Int64[] data, int from, int to) { }

	public static Int32[] CopyOfRange(Int32[] data, int from, int to) { }

	public static Byte[] CopyOfRange(Byte[] data, int from, int to) { }

	public static BigInteger[] CopyOfRange(BigInteger[] data, int from, int to) { }

	public static void Fill(Byte[] buf, byte b) { }

	public static void Fill(T[] ts, T t) { }

	public static void Fill(Byte[] buf, int from, int to, byte b) { }

	[CLSCompliant(False)]
	public static void Fill(UInt64[] buf, ulong b) { }

	public static void Fill(Span<T> ts, T t) { }

	public static int GetHashCode(Int32[] data) { }

	[CLSCompliant(False)]
	public static int GetHashCode(UInt64[] data, int off, int len) { }

	public static int GetHashCode(Byte[] data) { }

	[CLSCompliant(False)]
	public static int GetHashCode(UInt16[] data) { }

	public static int GetHashCode(Byte[] data, int off, int len) { }

	public static int GetHashCode(Int32[] data, int off, int len) { }

	[CLSCompliant(False)]
	public static int GetHashCode(UInt32[] data, int off, int len) { }

	[CLSCompliant(False)]
	public static int GetHashCode(UInt64[] data) { }

	[CLSCompliant(False)]
	public static int GetHashCode(UInt32[] data) { }

	private static int GetLength(int from, int to) { }

	private static bool HaveSameContents(Byte[] a, Byte[] b) { }

	private static bool HaveSameContents(Int32[] a, Int32[] b) { }

	private static bool HaveSameContents(Boolean[] a, Boolean[] b) { }

	private static bool HaveSameContents(Char[] a, Char[] b) { }

	private static bool HaveSameContents(UInt32[] a, UInt32[] b) { }

	private static bool HaveSameContents(Int64[] a, Int64[] b) { }

	private static bool HaveSameContents(UInt64[] a, UInt64[] b) { }

	public static bool IsNullOrContainsNull(Object[] array) { }

	public static bool IsNullOrEmpty(Object[] array) { }

	public static bool IsNullOrEmpty(Byte[] array) { }

	public static Int32[] Prepend(Int32[] a, int b) { }

	public static T[] Prepend(T[] a, T b) { }

	public static Byte[] Prepend(Byte[] a, byte b) { }

	public static Int16[] Prepend(Int16[] a, short b) { }

	public static Int32[] Reverse(Int32[] a) { }

	public static Byte[] Reverse(Byte[] a) { }

	public static T[] ReverseInPlace(T[] array) { }

	public static string ToString(Object[] a) { }

}

