namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities.Bzip2;

public class CBZip2OutputStreamLeaveOpen : CBZip2OutputStream
{

	public CBZip2OutputStreamLeaveOpen(Stream outStream) { }

	public CBZip2OutputStreamLeaveOpen(Stream outStream, int blockSize) { }

	protected virtual void Dispose(bool disposing) { }

}

