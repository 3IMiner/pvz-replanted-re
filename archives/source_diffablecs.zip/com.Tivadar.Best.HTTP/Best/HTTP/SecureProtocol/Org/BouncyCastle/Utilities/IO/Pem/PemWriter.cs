namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities.IO.Pem;

public class PemWriter : IDisposable
{
	private const int LineLength = 64; //Field offset: 0x0
	private readonly TextWriter writer; //Field offset: 0x10
	private readonly int nlLength; //Field offset: 0x18
	private Char[] buf; //Field offset: 0x20

	public TextWriter Writer
	{
		 get { } //Length: 5
	}

	public PemWriter(TextWriter writer) { }

	public override void Dispose() { }

	protected override void Dispose(bool disposing) { }

	public TextWriter get_Writer() { }

	public int GetOutputSize(PemObject obj) { }

	private void WriteEncoded(Byte[] bytes) { }

	public void WriteObject(PemObjectGenerator objGen) { }

	private void WritePostEncapsulationBoundary(string type) { }

	private void WritePreEncapsulationBoundary(string type) { }

}

