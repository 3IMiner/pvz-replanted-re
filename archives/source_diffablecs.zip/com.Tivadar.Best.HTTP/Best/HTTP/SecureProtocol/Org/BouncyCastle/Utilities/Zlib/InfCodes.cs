namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities.Zlib;

internal sealed class InfCodes
{
	private static readonly Int32[] inflate_mask; //Field offset: 0x0
	private const int BADCODE = 9; //Field offset: 0x0
	private const int END = 8; //Field offset: 0x0
	private const int WASH = 7; //Field offset: 0x0
	private const int COPY = 5; //Field offset: 0x0
	private const int DISTEXT = 4; //Field offset: 0x0
	private const int DIST = 3; //Field offset: 0x0
	private const int LENEXT = 2; //Field offset: 0x0
	private const int LEN = 1; //Field offset: 0x0
	private const int START = 0; //Field offset: 0x0
	private const int LIT = 6; //Field offset: 0x0
	private const int Z_BUF_ERROR = -5; //Field offset: 0x0
	private const int Z_MEM_ERROR = -4; //Field offset: 0x0
	private const int Z_DATA_ERROR = -3; //Field offset: 0x0
	private const int Z_STREAM_ERROR = -2; //Field offset: 0x0
	private const int Z_ERRNO = -1; //Field offset: 0x0
	private const int Z_VERSION_ERROR = -6; //Field offset: 0x0
	private const int Z_NEED_DICT = 2; //Field offset: 0x0
	private const int Z_STREAM_END = 1; //Field offset: 0x0
	private const int Z_OK = 0; //Field offset: 0x0
	private int mode; //Field offset: 0x10
	private int len; //Field offset: 0x14
	private Int32[] tree; //Field offset: 0x18
	private int tree_index; //Field offset: 0x20
	private int need; //Field offset: 0x24
	private int lit; //Field offset: 0x28
	private int get; //Field offset: 0x2C
	private int dist; //Field offset: 0x30
	private byte lbits; //Field offset: 0x34
	private byte dbits; //Field offset: 0x35
	private Int32[] ltree; //Field offset: 0x38
	private int ltree_index; //Field offset: 0x40
	private Int32[] dtree; //Field offset: 0x48
	private int dtree_index; //Field offset: 0x50

	private static InfCodes() { }

	internal InfCodes() { }

	internal void free(ZStream z) { }

	internal int inflate_fast(int bl, int bd, Int32[] tl, int tl_index, Int32[] td, int td_index, InfBlocks s, ZStream z) { }

	internal void init(int bl, int bd, Int32[] tl, int tl_index, Int32[] td, int td_index, ZStream z) { }

	internal int proc(InfBlocks s, ZStream z, int r) { }

}

