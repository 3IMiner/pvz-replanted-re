namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities.Zlib;

internal sealed class Adler32
{
	private const int BASE = 65521; //Field offset: 0x0
	private const int NMAX = 5552; //Field offset: 0x0

	public Adler32() { }

	internal long adler32(long adler, Byte[] buf, int index, int len) { }

}

