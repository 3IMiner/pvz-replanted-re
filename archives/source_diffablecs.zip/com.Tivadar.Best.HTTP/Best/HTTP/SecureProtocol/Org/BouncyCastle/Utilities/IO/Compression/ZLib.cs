namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities.IO.Compression;

internal static class ZLib
{

	internal static Stream CompressOutput(Stream stream, int zlibCompressionLevel, bool leaveOpen = false) { }

	internal static Stream DecompressInput(Stream stream) { }

}

