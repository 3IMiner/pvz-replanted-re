namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.X509;

public class X509AttrCertParser
{
	private static readonly PemParser PemAttrCertParser; //Field offset: 0x0
	private Asn1Set sData; //Field offset: 0x10
	private int sDataObjectCount; //Field offset: 0x18
	private Stream currentStream; //Field offset: 0x20

	private static X509AttrCertParser() { }

	public X509AttrCertParser() { }

	private X509V2AttributeCertificate GetCertificate() { }

	public X509V2AttributeCertificate ReadAttrCert(Byte[] input) { }

	public X509V2AttributeCertificate ReadAttrCert(Stream inStream) { }

	public IList<X509V2AttributeCertificate> ReadAttrCerts(Byte[] input) { }

	public IList<X509V2AttributeCertificate> ReadAttrCerts(Stream inStream) { }

	private X509V2AttributeCertificate ReadDerCertificate(Asn1InputStream dIn) { }

	private X509V2AttributeCertificate ReadPemCertificate(Stream inStream) { }

}

