namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.X509;

public class X509Crl : X509ExtensionBase
{
	private class CachedEncoding
	{
		private readonly Byte[] encoding; //Field offset: 0x10
		private readonly CrlException exception; //Field offset: 0x18

		internal Byte[] Encoding
		{
			internal get { } //Length: 5
		}

		internal CachedEncoding(Byte[] encoding, CrlException exception) { }

		internal Byte[] get_Encoding() { }

		internal Byte[] GetEncoded() { }

	}

	private readonly CertificateList c; //Field offset: 0x10
	private readonly string sigAlgName; //Field offset: 0x18
	private readonly Byte[] sigAlgParams; //Field offset: 0x20
	private readonly bool isIndirect; //Field offset: 0x28
	private readonly object cacheLock; //Field offset: 0x30
	private CachedEncoding cachedEncoding; //Field offset: 0x38
	private bool hashValueSet; //Field offset: 0x40
	private int hashValue; //Field offset: 0x44

	public override CertificateList CertificateList
	{
		 get { } //Length: 5
	}

	protected override bool IsIndirectCrl
	{
		 get { } //Length: 314
	}

	public override X509Name IssuerDN
	{
		 get { } //Length: 29
	}

	public override Nullable<DateTime> NextUpdate
	{
		 get { } //Length: 150
	}

	public override string SigAlgName
	{
		 get { } //Length: 5
	}

	public override string SigAlgOid
	{
		 get { } //Length: 60
	}

	public override DateTime ThisUpdate
	{
		 get { } //Length: 44
	}

	public override int Version
	{
		 get { } //Length: 29
	}

	public X509Crl(Byte[] encoding) { }

	public X509Crl(CertificateList c) { }

	protected override void CheckSignature(IVerifierFactory verifier) { }

	public virtual bool Equals(object other) { }

	public override CertificateList get_CertificateList() { }

	protected override bool get_IsIndirectCrl() { }

	public override X509Name get_IssuerDN() { }

	public override Nullable<DateTime> get_NextUpdate() { }

	public override string get_SigAlgName() { }

	public override string get_SigAlgOid() { }

	public override DateTime get_ThisUpdate() { }

	public override int get_Version() { }

	private CachedEncoding GetCachedEncoding() { }

	public override Byte[] GetEncoded() { }

	public virtual int GetHashCode() { }

	public override X509CrlEntry GetRevokedCertificate(BigInteger serialNumber) { }

	public override ISet<X509CrlEntry> GetRevokedCertificates() { }

	public override Byte[] GetSigAlgParams() { }

	public override Byte[] GetSignature() { }

	public override Byte[] GetTbsCertList() { }

	protected virtual X509Extensions GetX509Extensions() { }

	public override bool IsRevoked(X509Certificate cert) { }

	private ISet<X509CrlEntry> LoadCrlEntries() { }

	public virtual string ToString() { }

	public override void Verify(IVerifierFactoryProvider verifierProvider) { }

	public override void Verify(AsymmetricKeyParameter publicKey) { }

}

