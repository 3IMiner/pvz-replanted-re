namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities.IO;

public class TeeInputStream : BaseInputStream
{
	private readonly Stream input; //Field offset: 0x28
	private readonly Stream tee; //Field offset: 0x30

	public TeeInputStream(Stream input, Stream tee) { }

	protected virtual void Dispose(bool disposing) { }

	public virtual int Read(Byte[] buffer, int offset, int count) { }

	public virtual int Read(Span<Byte> buffer) { }

	public virtual int ReadByte() { }

}

