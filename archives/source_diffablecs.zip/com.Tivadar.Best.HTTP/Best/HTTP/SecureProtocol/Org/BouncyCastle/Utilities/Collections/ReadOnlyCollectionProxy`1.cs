namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities.Collections;

internal class ReadOnlyCollectionProxy : ReadOnlyCollection<T>
{
	private readonly ICollection<T> m_target; //Field offset: 0x0

	public virtual int Count
	{
		 get { } //Length: 70
	}

	internal ReadOnlyCollectionProxy`1(ICollection<T> target) { }

	public virtual bool Contains(T item) { }

	public virtual void CopyTo(T[] array, int arrayIndex) { }

	public virtual int get_Count() { }

	public virtual IEnumerator<T> GetEnumerator() { }

}

