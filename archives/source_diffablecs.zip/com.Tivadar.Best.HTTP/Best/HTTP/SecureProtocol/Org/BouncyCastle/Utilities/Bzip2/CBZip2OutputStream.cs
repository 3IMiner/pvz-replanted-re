namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities.Bzip2;

public class CBZip2OutputStream : BaseOutputStream
{
	public class StackElem
	{
		internal int ll; //Field offset: 0x10
		internal int hh; //Field offset: 0x14
		internal int dd; //Field offset: 0x18

		public StackElem() { }

	}

	protected const int SETMASK = 2097152; //Field offset: 0x0
	protected const int CLEARMASK = -2097153; //Field offset: 0x0
	protected const int GREATER_ICOST = 15; //Field offset: 0x0
	protected const int LESSER_ICOST = 0; //Field offset: 0x0
	protected const int SMALL_THRESH = 20; //Field offset: 0x0
	protected const int DEPTH_THRESH = 10; //Field offset: 0x0
	internal static readonly UInt16[] RNums; //Field offset: 0x0
	private static readonly Int32[] Incs; //Field offset: 0x8
	private bool finished; //Field offset: 0x28
	private int count; //Field offset: 0x2C
	private int origPtr; //Field offset: 0x30
	private readonly int blockSize100k; //Field offset: 0x34
	private readonly int allowableBlockSize; //Field offset: 0x38
	private bool blockRandomised; //Field offset: 0x3C
	private readonly IList<StackElem> blocksortStack; //Field offset: 0x40
	private int bsBuff; //Field offset: 0x48
	private int bsLivePos; //Field offset: 0x4C
	private readonly CRC m_blockCrc; //Field offset: 0x50
	private Boolean[] inUse; //Field offset: 0x58
	private int nInUse; //Field offset: 0x60
	private Byte[] m_selectors; //Field offset: 0x68
	private Byte[] blockBytes; //Field offset: 0x70
	private UInt16[] quadrantShorts; //Field offset: 0x78
	private Int32[] zptr; //Field offset: 0x80
	private Int32[] szptr; //Field offset: 0x88
	private Int32[] ftab; //Field offset: 0x90
	private int nMTF; //Field offset: 0x98
	private Int32[] mtfFreq; //Field offset: 0xA0
	private int workFactor; //Field offset: 0xA8
	private int workDone; //Field offset: 0xAC
	private int workLimit; //Field offset: 0xB0
	private bool firstAttempt; //Field offset: 0xB4
	private int currentByte; //Field offset: 0xB8
	private int runLength; //Field offset: 0xBC
	private int m_streamCrc; //Field offset: 0xC0
	private bool closed; //Field offset: 0xC4
	private Stream bsStream; //Field offset: 0xC8

	private static CBZip2OutputStream() { }

	public CBZip2OutputStream(Stream outStream) { }

	public CBZip2OutputStream(Stream outStream, int blockSize) { }

	private void BsFinishedWithStream() { }

	private void BsPutBit(int v) { }

	private void BsPutBits(int n, int v) { }

	private void BsPutBitsSmall(int n, int v) { }

	private void BsPutInt32(int u) { }

	private void BsPutLong48(long u) { }

	internal static Byte[][] CreateByteArray(int n1, int n2) { }

	protected void Detach(bool disposing) { }

	protected virtual void Dispose(bool disposing) { }

	private void DoReversibleTransformation() { }

	private void EndBlock() { }

	private void EndCompression() { }

	public void Finish() { }

	public virtual void Flush() { }

	private bool FullGtU(int i1, int i2) { }

	private void GenerateMtfValues() { }

	private void HbAssignCodes(Int32[] code, Byte[] length, int minLen, int maxLen, int alphaSize) { }

	protected static void HbMakeCodeLengths(Byte[] len, Int32[] freq, int alphaSize, int maxLen) { }

	private void InitBlock() { }

	private void MainSort() { }

	private int Med3(int a, int b, int c) { }

	private void MoveToFrontCodeAndSend() { }

	private static void PushStackElem(IList<StackElem> stack, int stackCount, int ll, int hh, int dd) { }

	private void QSort3(int loSt, int hiSt, int dSt) { }

	private void RandomiseBlock() { }

	private void SendMtfValues() { }

	private void SimpleSort(int lo, int hi, int d) { }

	private void Vswap(int p1, int p2, int n) { }

	public virtual void WriteByte(byte value) { }

	private void WriteRun() { }

}

