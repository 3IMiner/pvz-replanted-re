namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities.Encoders;

public interface ITranslator
{

	public int Decode(Byte[] input, int inOff, int length, Byte[] outBytes, int outOff) { }

	public int Encode(Byte[] input, int inOff, int length, Byte[] outBytes, int outOff) { }

	public int GetDecodedBlockSize() { }

	public int GetEncodedBlockSize() { }

}

