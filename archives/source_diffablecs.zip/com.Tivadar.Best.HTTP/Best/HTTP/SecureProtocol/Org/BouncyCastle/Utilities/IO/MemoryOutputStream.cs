namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities.IO;

public class MemoryOutputStream : MemoryStream
{

	public virtual bool CanRead
	{
		 get { } //Length: 3
	}

	public MemoryOutputStream() { }

	public virtual bool get_CanRead() { }

}

