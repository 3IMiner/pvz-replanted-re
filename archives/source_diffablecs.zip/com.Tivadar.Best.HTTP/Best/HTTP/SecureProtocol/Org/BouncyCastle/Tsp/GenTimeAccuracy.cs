namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Tsp;

public class GenTimeAccuracy
{
	private Accuracy accuracy; //Field offset: 0x10

	public int Micros
	{
		 get { } //Length: 45
	}

	public int Millis
	{
		 get { } //Length: 45
	}

	public int Seconds
	{
		 get { } //Length: 45
	}

	public GenTimeAccuracy(Accuracy accuracy) { }

	public int get_Micros() { }

	public int get_Millis() { }

	public int get_Seconds() { }

	private int GetTimeComponent(DerInteger time) { }

	public virtual string ToString() { }

}

