namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.X509;

public class X509V3CertificateGenerator
{
	private readonly X509ExtensionsGenerator extGenerator; //Field offset: 0x10
	private V3TbsCertificateGenerator tbsGen; //Field offset: 0x18

	public IEnumerable<String> SignatureAlgNames
	{
		 get { } //Length: 350
	}

	public X509V3CertificateGenerator() { }

	public void AddExtension(DerObjectIdentifier oid, bool critical, Byte[] extensionValue) { }

	public void AddExtension(string oid, bool critical, Byte[] extensionValue) { }

	public void AddExtension(DerObjectIdentifier oid, bool critical, Asn1Encodable extensionValue) { }

	public void AddExtension(string oid, bool critical, Asn1Encodable extensionValue) { }

	private DerBitString booleanToBitString(Boolean[] id) { }

	public void CopyAndAddExtension(DerObjectIdentifier oid, bool critical, X509Certificate cert) { }

	public void CopyAndAddExtension(string oid, bool critical, X509Certificate cert) { }

	public X509Certificate Generate(ISignatureFactory signatureFactory) { }

	public IEnumerable<String> get_SignatureAlgNames() { }

	public void Reset() { }

	public void SetIssuerDN(X509Name issuer) { }

	public void SetIssuerUniqueID(Boolean[] uniqueID) { }

	public void SetNotAfter(DateTime date) { }

	public void SetNotBefore(DateTime date) { }

	public void SetPublicKey(AsymmetricKeyParameter publicKey) { }

	public void SetSerialNumber(BigInteger serialNumber) { }

	public void SetSubjectDN(X509Name subject) { }

	public void SetSubjectUniqueID(Boolean[] uniqueID) { }

}

