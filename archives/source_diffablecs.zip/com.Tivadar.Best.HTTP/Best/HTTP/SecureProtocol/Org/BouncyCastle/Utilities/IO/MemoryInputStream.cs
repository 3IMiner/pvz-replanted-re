namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities.IO;

public class MemoryInputStream : MemoryStream
{

	public virtual bool CanWrite
	{
		 get { } //Length: 3
	}

	public MemoryInputStream(Byte[] buffer) { }

	public virtual bool get_CanWrite() { }

}

