namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.X509.Store;

public class X509CertStoreSelector : ISelector<X509Certificate>, ICloneable
{
	private Byte[] authorityKeyIdentifier; //Field offset: 0x10
	private int basicConstraints; //Field offset: 0x18
	private X509Certificate certificate; //Field offset: 0x20
	private Nullable<DateTime> certificateValid; //Field offset: 0x28
	private ISet<DerObjectIdentifier> extendedKeyUsage; //Field offset: 0x38
	private bool ignoreX509NameOrdering; //Field offset: 0x40
	private X509Name issuer; //Field offset: 0x48
	private Boolean[] keyUsage; //Field offset: 0x50
	private ISet<DerObjectIdentifier> policy; //Field offset: 0x58
	private Nullable<DateTime> privateKeyValid; //Field offset: 0x60
	private BigInteger serialNumber; //Field offset: 0x70
	private X509Name subject; //Field offset: 0x78
	private Byte[] subjectKeyIdentifier; //Field offset: 0x80
	private SubjectPublicKeyInfo subjectPublicKey; //Field offset: 0x88
	private DerObjectIdentifier subjectPublicKeyAlgID; //Field offset: 0x90

	public Byte[] AuthorityKeyIdentifier
	{
		 get { } //Length: 165
		 set { } //Length: 190
	}

	public int BasicConstraints
	{
		 get { } //Length: 4
		 set { } //Length: 127
	}

	public X509Certificate Certificate
	{
		 get { } //Length: 5
		 set { } //Length: 13
	}

	public Nullable<DateTime> CertificateValid
	{
		 get { } //Length: 11
		 set { } //Length: 8
	}

	public ISet<DerObjectIdentifier> ExtendedKeyUsage
	{
		 get { } //Length: 58
		 set { } //Length: 85
	}

	public bool IgnoreX509NameOrdering
	{
		 get { } //Length: 5
		 set { } //Length: 4
	}

	public X509Name Issuer
	{
		 get { } //Length: 5
		 set { } //Length: 13
	}

	public Boolean[] KeyUsage
	{
		 get { } //Length: 113
		 set { } //Length: 141
	}

	public ISet<DerObjectIdentifier> Policy
	{
		 get { } //Length: 58
		 set { } //Length: 85
	}

	public Nullable<DateTime> PrivateKeyValid
	{
		 get { } //Length: 11
		 set { } //Length: 8
	}

	public BigInteger SerialNumber
	{
		 get { } //Length: 5
		 set { } //Length: 13
	}

	public X509Name Subject
	{
		 get { } //Length: 5
		 set { } //Length: 13
	}

	public Byte[] SubjectKeyIdentifier
	{
		 get { } //Length: 168
		 set { } //Length: 196
	}

	public SubjectPublicKeyInfo SubjectPublicKey
	{
		 get { } //Length: 8
		 set { } //Length: 19
	}

	public DerObjectIdentifier SubjectPublicKeyAlgID
	{
		 get { } //Length: 8
		 set { } //Length: 19
	}

	public X509CertStoreSelector() { }

	public X509CertStoreSelector(X509CertStoreSelector o) { }

	public override object Clone() { }

	private static Boolean[] CopyBoolArray(Boolean[] b) { }

	private static ISet<T> CopySet(ISet<T> s) { }

	public Byte[] get_AuthorityKeyIdentifier() { }

	public int get_BasicConstraints() { }

	public X509Certificate get_Certificate() { }

	public Nullable<DateTime> get_CertificateValid() { }

	public ISet<DerObjectIdentifier> get_ExtendedKeyUsage() { }

	public bool get_IgnoreX509NameOrdering() { }

	public X509Name get_Issuer() { }

	public Boolean[] get_KeyUsage() { }

	public ISet<DerObjectIdentifier> get_Policy() { }

	public Nullable<DateTime> get_PrivateKeyValid() { }

	public BigInteger get_SerialNumber() { }

	public X509Name get_Subject() { }

	public Byte[] get_SubjectKeyIdentifier() { }

	public SubjectPublicKeyInfo get_SubjectPublicKey() { }

	public DerObjectIdentifier get_SubjectPublicKeyAlgID() { }

	private static SubjectPublicKeyInfo GetSubjectPublicKey(X509Certificate c) { }

	internal static bool IssuersMatch(X509Name a, X509Name b) { }

	public override bool Match(X509Certificate c) { }

	private static bool MatchExtension(Byte[] b, X509Certificate c, DerObjectIdentifier oid) { }

	public void set_AuthorityKeyIdentifier(Byte[] value) { }

	public void set_BasicConstraints(int value) { }

	public void set_Certificate(X509Certificate value) { }

	public void set_CertificateValid(Nullable<DateTime> value) { }

	public void set_ExtendedKeyUsage(ISet<DerObjectIdentifier> value) { }

	public void set_IgnoreX509NameOrdering(bool value) { }

	public void set_Issuer(X509Name value) { }

	public void set_KeyUsage(Boolean[] value) { }

	public void set_Policy(ISet<DerObjectIdentifier> value) { }

	public void set_PrivateKeyValid(Nullable<DateTime> value) { }

	public void set_SerialNumber(BigInteger value) { }

	public void set_Subject(X509Name value) { }

	public void set_SubjectKeyIdentifier(Byte[] value) { }

	public void set_SubjectPublicKey(SubjectPublicKeyInfo value) { }

	public void set_SubjectPublicKeyAlgID(DerObjectIdentifier value) { }

}

