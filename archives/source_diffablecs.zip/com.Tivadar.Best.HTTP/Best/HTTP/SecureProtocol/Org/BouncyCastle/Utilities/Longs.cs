namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities;

public static class Longs
{
	public const int NumBits = 64; //Field offset: 0x0
	public const int NumBytes = 8; //Field offset: 0x0
	private static readonly Byte[] DeBruijnTZ; //Field offset: 0x0

	private static Longs() { }

	public static long HighestOneBit(long i) { }

	[CLSCompliant(False)]
	public static ulong HighestOneBit(ulong i) { }

	public static long LowestOneBit(long i) { }

	[CLSCompliant(False)]
	public static ulong LowestOneBit(ulong i) { }

	public static int NumberOfLeadingZeros(long i) { }

	public static int NumberOfTrailingZeros(long i) { }

	public static long Reverse(long i) { }

	[CLSCompliant(False)]
	public static ulong Reverse(ulong i) { }

	public static long ReverseBytes(long i) { }

	[CLSCompliant(False)]
	public static ulong ReverseBytes(ulong i) { }

	public static long RotateLeft(long i, int distance) { }

	[CLSCompliant(False)]
	public static ulong RotateLeft(ulong i, int distance) { }

	public static long RotateRight(long i, int distance) { }

	[CLSCompliant(False)]
	public static ulong RotateRight(ulong i, int distance) { }

}

