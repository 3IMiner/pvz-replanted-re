namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Tsp;

public class TimeStampResponseGenerator
{
	private class FailInfo : DerBitString
	{

		internal FailInfo(int failInfoValue) { }

	}

	private PkiStatus status; //Field offset: 0x10
	private Asn1EncodableVector statusStrings; //Field offset: 0x18
	private int failInfo; //Field offset: 0x20
	private TimeStampTokenGenerator tokenGenerator; //Field offset: 0x28
	private IList<String> acceptedAlgorithms; //Field offset: 0x30
	private IList<String> acceptedPolicies; //Field offset: 0x38
	private IList<String> acceptedExtensions; //Field offset: 0x40

	public TimeStampResponseGenerator(TimeStampTokenGenerator tokenGenerator, IList<String> acceptedAlgorithms) { }

	public TimeStampResponseGenerator(TimeStampTokenGenerator tokenGenerator, IList<String> acceptedAlgorithms, IList<String> acceptedPolicy) { }

	public TimeStampResponseGenerator(TimeStampTokenGenerator tokenGenerator, IList<String> acceptedAlgorithms, IList<String> acceptedPolicies, IList<String> acceptedExtensions) { }

	private void AddStatusString(string statusString) { }

	public TimeStampResponse Generate(TimeStampRequest request, BigInteger serialNumber, Nullable<DateTime> genTime) { }

	public TimeStampResponse GenerateFailResponse(PkiStatus status, int failInfoField, string statusString) { }

	public TimeStampResponse GenerateGrantedResponse(TimeStampRequest request, BigInteger serialNumber, Nullable<DateTime> genTime, string statusString, X509Extensions additionalExtensions) { }

	private PkiStatusInfo GetPkiStatusInfo() { }

	private void SetFailInfoField(int field) { }

}

