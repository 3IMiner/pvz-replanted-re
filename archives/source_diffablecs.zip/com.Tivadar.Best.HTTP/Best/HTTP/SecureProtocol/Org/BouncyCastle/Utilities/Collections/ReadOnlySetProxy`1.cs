namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities.Collections;

internal class ReadOnlySetProxy : ReadOnlySet<T>
{
	private readonly ISet<T> m_target; //Field offset: 0x0

	public virtual int Count
	{
		 get { } //Length: 177
	}

	internal ReadOnlySetProxy`1(ISet<T> target) { }

	public virtual bool Contains(T item) { }

	public virtual void CopyTo(T[] array, int arrayIndex) { }

	public virtual int get_Count() { }

	public virtual IEnumerator<T> GetEnumerator() { }

	public virtual bool IsProperSubsetOf(IEnumerable<T> other) { }

	public virtual bool IsProperSupersetOf(IEnumerable<T> other) { }

	public virtual bool IsSubsetOf(IEnumerable<T> other) { }

	public virtual bool IsSupersetOf(IEnumerable<T> other) { }

	public virtual bool Overlaps(IEnumerable<T> other) { }

}

