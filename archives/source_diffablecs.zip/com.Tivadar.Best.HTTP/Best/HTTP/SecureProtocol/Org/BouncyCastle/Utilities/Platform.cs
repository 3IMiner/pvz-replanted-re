namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities;

internal static class Platform
{
	private static readonly CompareInfo InvariantCompareInfo; //Field offset: 0x0

	private static Platform() { }

	internal static bool EndsWith(string source, string suffix) { }

	internal static bool EqualsIgnoreCase(string a, string b) { }

	internal static string GetEnvironmentVariable(string variable) { }

	internal static string GetTypeName(object obj) { }

	internal static int IndexOf(string source, char value) { }

	internal static int IndexOf(string source, string value) { }

	internal static int IndexOf(string source, char value, int startIndex) { }

	internal static int IndexOf(string source, string value, int startIndex) { }

	internal static int LastIndexOf(string source, string value) { }

	internal static bool StartsWith(string source, string prefix) { }

}

