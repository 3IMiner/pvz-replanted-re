namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities.Encoders;

public class BufferedDecoder
{
	internal Byte[] buffer; //Field offset: 0x10
	internal int bufOff; //Field offset: 0x18
	internal ITranslator translator; //Field offset: 0x20

	public BufferedDecoder(ITranslator translator, int bufferSize) { }

	public int ProcessByte(byte input, Byte[] output, int outOff) { }

	public int ProcessBytes(Byte[] input, int inOff, int len, Byte[] outBytes, int outOff) { }

}

