namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities.Encoders;

public class Base64Encoder : IEncoder
{
	protected readonly Byte[] encodingTable; //Field offset: 0x10
	protected byte padding; //Field offset: 0x18
	protected readonly Byte[] decodingTable; //Field offset: 0x20

	public Base64Encoder() { }

	public override int Decode(Byte[] data, int off, int length, Stream outStream) { }

	public override int Decode(ReadOnlySpan<Byte> data, Stream outStream) { }

	private int DecodeLastBlock(Stream outStream, char c1, char c2, char c3, char c4) { }

	public override int DecodeString(string data, Stream outStream) { }

	public int Encode(Byte[] inBuf, int inOff, int inLen, Byte[] outBuf, int outOff) { }

	public int Encode(ReadOnlySpan<Byte> input, Span<Byte> output) { }

	public override int Encode(Byte[] buf, int off, int len, Stream outStream) { }

	public override int Encode(ReadOnlySpan<Byte> data, Stream outStream) { }

	private bool Ignore(char c) { }

	protected void InitialiseDecodingTable() { }

	private int NextI(ReadOnlySpan<Byte> data, int i, int finish) { }

	private int NextI(string data, int i, int finish) { }

}

