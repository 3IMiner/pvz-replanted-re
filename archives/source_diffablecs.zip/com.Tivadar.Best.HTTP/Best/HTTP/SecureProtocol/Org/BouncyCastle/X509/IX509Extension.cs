namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.X509;

public interface IX509Extension
{

	public ISet<String> GetCriticalExtensionOids() { }

	public Asn1OctetString GetExtensionValue(DerObjectIdentifier oid) { }

	public ISet<String> GetNonCriticalExtensionOids() { }

}

