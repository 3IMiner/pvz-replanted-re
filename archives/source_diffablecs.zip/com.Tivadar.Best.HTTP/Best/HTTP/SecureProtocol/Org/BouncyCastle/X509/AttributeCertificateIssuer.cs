namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.X509;

public class AttributeCertificateIssuer : ISelector<X509Certificate>, ICloneable
{
	internal readonly Asn1Encodable form; //Field offset: 0x10

	public AttributeCertificateIssuer(AttCertIssuer issuer) { }

	public AttributeCertificateIssuer(X509Name principal) { }

	public override object Clone() { }

	public virtual bool Equals(object obj) { }

	public virtual int GetHashCode() { }

	private Object[] GetNames() { }

	public X509Name[] GetPrincipals() { }

	public override bool Match(X509Certificate x509Cert) { }

	private bool MatchesDN(X509Name subject, GeneralNames targets) { }

}

