namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.X509;

internal class X509Utilities
{
	private static readonly Dictionary<String, DerObjectIdentifier> m_algorithms; //Field offset: 0x0
	private static readonly Dictionary<String, Asn1Encodable> m_exParams; //Field offset: 0x8
	private static readonly HashSet<DerObjectIdentifier> m_noParams; //Field offset: 0x10

	private static X509Utilities() { }

	public X509Utilities() { }

	private static RsassaPssParameters CreatePssParams(AlgorithmIdentifier hashAlgId, int saltSize) { }

	internal static IEnumerable<String> GetAlgNames() { }

	internal static DerObjectIdentifier GetAlgorithmOid(string algorithmName) { }

	internal static AlgorithmIdentifier GetSigAlgID(DerObjectIdentifier sigOid, string algorithmName) { }

}

