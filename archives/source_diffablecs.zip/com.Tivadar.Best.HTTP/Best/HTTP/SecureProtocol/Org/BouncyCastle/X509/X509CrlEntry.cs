namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.X509;

public class X509CrlEntry : X509ExtensionBase
{
	private CrlEntry c; //Field offset: 0x10
	private bool isIndirect; //Field offset: 0x18
	private X509Name previousCertificateIssuer; //Field offset: 0x20
	private X509Name certificateIssuer; //Field offset: 0x28
	private bool hashValueSet; //Field offset: 0x30
	private int hashValue; //Field offset: 0x34

	public bool HasExtensions
	{
		 get { } //Length: 36
	}

	public DateTime RevocationDate
	{
		 get { } //Length: 38
	}

	public BigInteger SerialNumber
	{
		 get { } //Length: 38
	}

	public X509CrlEntry(CrlEntry c) { }

	public X509CrlEntry(CrlEntry c, bool isIndirect, X509Name previousCertificateIssuer) { }

	public virtual bool Equals(object other) { }

	public bool get_HasExtensions() { }

	public DateTime get_RevocationDate() { }

	public BigInteger get_SerialNumber() { }

	public X509Name GetCertificateIssuer() { }

	public Byte[] GetEncoded() { }

	public virtual int GetHashCode() { }

	protected virtual X509Extensions GetX509Extensions() { }

	private X509Name loadCertificateIssuer() { }

	public virtual string ToString() { }

}

