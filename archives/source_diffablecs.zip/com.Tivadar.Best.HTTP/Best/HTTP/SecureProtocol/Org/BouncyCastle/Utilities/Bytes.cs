namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities;

public static class Bytes
{
	public const int NumBits = 8; //Field offset: 0x0
	public const int NumBytes = 1; //Field offset: 0x0

}

