namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.X509;

public class X509V2AttributeCertificateGenerator
{
	private readonly X509ExtensionsGenerator extGenerator; //Field offset: 0x10
	private V2AttributeCertificateInfoGenerator acInfoGen; //Field offset: 0x18

	public IEnumerable<String> SignatureAlgNames
	{
		 get { } //Length: 64
	}

	public X509V2AttributeCertificateGenerator() { }

	public void AddAttribute(X509Attribute attribute) { }

	public void AddExtension(string oid, bool critical, Asn1Encodable extensionValue) { }

	public void AddExtension(string oid, bool critical, Byte[] extensionValue) { }

	public X509V2AttributeCertificate Generate(ISignatureFactory signatureFactory) { }

	public IEnumerable<String> get_SignatureAlgNames() { }

	public void Reset() { }

	public void SetHolder(AttributeCertificateHolder holder) { }

	public void SetIssuer(AttributeCertificateIssuer issuer) { }

	public void SetIssuerUniqueId(Boolean[] iui) { }

	public void SetNotAfter(DateTime date) { }

	public void SetNotBefore(DateTime date) { }

	public void SetSerialNumber(BigInteger serialNumber) { }

}

