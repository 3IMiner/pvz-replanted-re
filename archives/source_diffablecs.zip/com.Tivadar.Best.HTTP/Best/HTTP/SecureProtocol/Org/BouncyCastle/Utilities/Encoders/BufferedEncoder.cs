namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities.Encoders;

public class BufferedEncoder
{
	internal Byte[] Buffer; //Field offset: 0x10
	internal int bufOff; //Field offset: 0x18
	internal ITranslator translator; //Field offset: 0x20

	public BufferedEncoder(ITranslator translator, int bufferSize) { }

	public int ProcessByte(byte input, Byte[] outBytes, int outOff) { }

	public int ProcessBytes(Byte[] input, int inOff, int len, Byte[] outBytes, int outOff) { }

}

