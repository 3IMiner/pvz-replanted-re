namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities.Collections;

internal abstract class ReadOnlyCollection : ICollection<T>, IEnumerable<T>, IEnumerable
{

	public abstract int Count
	{
		 get { } //Length: 0
	}

	public override bool IsReadOnly
	{
		 get { } //Length: 3
	}

	protected ReadOnlyCollection`1() { }

	public override void Add(T item) { }

	public override void Clear() { }

	public abstract bool Contains(T item) { }

	public abstract void CopyTo(T[] array, int arrayIndex) { }

	public abstract int get_Count() { }

	public override bool get_IsReadOnly() { }

	public abstract IEnumerator<T> GetEnumerator() { }

	public override bool Remove(T item) { }

	private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

}

