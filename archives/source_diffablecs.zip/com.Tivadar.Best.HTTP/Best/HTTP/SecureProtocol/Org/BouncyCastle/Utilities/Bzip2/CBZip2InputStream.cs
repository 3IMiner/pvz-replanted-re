namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities.Bzip2;

public class CBZip2InputStream : BaseInputStream
{
	private const int NO_RAND_PART_B_STATE = 3; //Field offset: 0x0
	private const int RAND_PART_B_STATE = 1; //Field offset: 0x0
	private const int NO_RAND_PART_C_STATE = 4; //Field offset: 0x0
	private const int RAND_PART_C_STATE = 2; //Field offset: 0x0
	private int last; //Field offset: 0x28
	private int origPtr; //Field offset: 0x2C
	private int blockSize100k; //Field offset: 0x30
	private int bsBuff; //Field offset: 0x34
	private int bsLive; //Field offset: 0x38
	private readonly CRC m_blockCrc; //Field offset: 0x40
	private int nInUse; //Field offset: 0x48
	private Byte[] seqToUnseq; //Field offset: 0x50
	private Byte[] m_selectors; //Field offset: 0x58
	private Int32[] tt; //Field offset: 0x60
	private Byte[] ll8; //Field offset: 0x68
	private Int32[] unzftab; //Field offset: 0x70
	private Int32[][] limit; //Field offset: 0x78
	private Int32[][] basev; //Field offset: 0x80
	private Int32[][] perm; //Field offset: 0x88
	private Int32[] minLens; //Field offset: 0x90
	private Stream bsStream; //Field offset: 0x98
	private bool streamEnd; //Field offset: 0xA0
	private int currentByte; //Field offset: 0xA4
	private int currentState; //Field offset: 0xA8
	private int m_expectedBlockCrc; //Field offset: 0xAC
	private int m_expectedStreamCrc; //Field offset: 0xB0
	private int m_streamCrc; //Field offset: 0xB4
	private int i2; //Field offset: 0xB8
	private int count; //Field offset: 0xBC
	private int chPrev; //Field offset: 0xC0
	private int ch2; //Field offset: 0xC4
	private int i; //Field offset: 0xC8
	private int tPos; //Field offset: 0xCC
	private int rNToGo; //Field offset: 0xD0
	private int rTPos; //Field offset: 0xD4
	private int j2; //Field offset: 0xD8
	private int z; //Field offset: 0xDC

	public CBZip2InputStream(Stream zStream) { }

	private void BeginBlock() { }

	private void BsFinishedWithStream() { }

	private int BsGetBit() { }

	private int BsGetBits(int n) { }

	private int BsGetBitsSmall(int n) { }

	private int BsGetInt32() { }

	private long BsGetLong48() { }

	internal static Int32[][] CreateIntArray(int n1, int n2) { }

	private void EndBlock() { }

	private void GetAndMoveToFrontDecode() { }

	private void HbCreateDecodeTables(Int32[] limit, Int32[] basev, Int32[] perm, Byte[] length, int minLen, int maxLen, int alphaSize) { }

	public virtual int Read(Byte[] buffer, int offset, int count) { }

	public virtual int ReadByte() { }

	private int RecvDecodingTables() { }

	private int RequireByte() { }

	private void SetupNoRandPartA() { }

	private void SetupNoRandPartB() { }

	private void SetupNoRandPartC() { }

	private void SetupRandPartA() { }

	private void SetupRandPartB() { }

	private void SetupRandPartC() { }

}

