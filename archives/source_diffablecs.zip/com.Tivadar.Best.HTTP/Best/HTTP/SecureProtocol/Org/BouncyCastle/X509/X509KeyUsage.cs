namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.X509;

public class X509KeyUsage : Asn1Encodable
{
	public const int DigitalSignature = 128; //Field offset: 0x0
	public const int NonRepudiation = 64; //Field offset: 0x0
	public const int KeyEncipherment = 32; //Field offset: 0x0
	public const int DataEncipherment = 16; //Field offset: 0x0
	public const int KeyAgreement = 8; //Field offset: 0x0
	public const int KeyCertSign = 4; //Field offset: 0x0
	public const int CrlSign = 2; //Field offset: 0x0
	public const int EncipherOnly = 1; //Field offset: 0x0
	public const int DecipherOnly = 32768; //Field offset: 0x0
	private readonly int usage; //Field offset: 0x10

	public X509KeyUsage(int usage) { }

	public virtual Asn1Object ToAsn1Object() { }

}

