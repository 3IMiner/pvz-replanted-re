namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities;

internal static class Enums
{

	internal static TEnum GetArbitraryValue() { }

	internal static TEnum GetEnumValue(string s) { }

	internal static TEnum[] GetEnumValues() { }

}

