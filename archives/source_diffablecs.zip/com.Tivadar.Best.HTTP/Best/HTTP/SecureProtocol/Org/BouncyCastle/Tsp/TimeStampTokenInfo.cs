namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Tsp;

public class TimeStampTokenInfo
{
	private TstInfo tstInfo; //Field offset: 0x10
	private DateTime genTime; //Field offset: 0x18

	public Accuracy Accuracy
	{
		 get { } //Length: 27
	}

	public DateTime GenTime
	{
		 get { } //Length: 5
	}

	public GenTimeAccuracy GenTimeAccuracy
	{
		 get { } //Length: 130
	}

	public AlgorithmIdentifier HashAlgorithm
	{
		 get { } //Length: 36
	}

	public bool IsOrdered
	{
		 get { } //Length: 38
	}

	public string MessageImprintAlgOid
	{
		 get { } //Length: 69
	}

	public BigInteger Nonce
	{
		 get { } //Length: 47
	}

	public string Policy
	{
		 get { } //Length: 36
	}

	public BigInteger SerialNumber
	{
		 get { } //Length: 38
	}

	public GeneralName Tsa
	{
		 get { } //Length: 27
	}

	public TstInfo TstInfo
	{
		 get { } //Length: 5
	}

	public TimeStampTokenInfo(Byte[] tstInfoEncoding) { }

	public TimeStampTokenInfo(TstInfo tstInfo) { }

	public Accuracy get_Accuracy() { }

	public DateTime get_GenTime() { }

	public GenTimeAccuracy get_GenTimeAccuracy() { }

	public AlgorithmIdentifier get_HashAlgorithm() { }

	public bool get_IsOrdered() { }

	public string get_MessageImprintAlgOid() { }

	public BigInteger get_Nonce() { }

	public string get_Policy() { }

	public BigInteger get_SerialNumber() { }

	public GeneralName get_Tsa() { }

	public TstInfo get_TstInfo() { }

	public Byte[] GetEncoded() { }

	public Byte[] GetMessageImprintDigest() { }

	private static TstInfo ParseTstInfo(Byte[] tstInfoEncoding) { }

}

