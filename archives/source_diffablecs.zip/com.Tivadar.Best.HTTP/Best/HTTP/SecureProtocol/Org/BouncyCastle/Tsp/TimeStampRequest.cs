namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Tsp;

public class TimeStampRequest : X509ExtensionBase
{
	private TimeStampReq req; //Field offset: 0x10
	private X509Extensions extensions; //Field offset: 0x18

	public bool CertReq
	{
		 get { } //Length: 47
	}

	internal X509Extensions Extensions
	{
		internal get { } //Length: 27
	}

	public override bool HasExtensions
	{
		 get { } //Length: 9
	}

	public string MessageImprintAlgOid
	{
		 get { } //Length: 69
	}

	public BigInteger Nonce
	{
		 get { } //Length: 47
	}

	public string ReqPolicy
	{
		 get { } //Length: 45
	}

	public int Version
	{
		 get { } //Length: 38
	}

	public TimeStampRequest(TimeStampReq req) { }

	public TimeStampRequest(Byte[] req) { }

	public TimeStampRequest(Stream input) { }

	private TimeStampRequest(Asn1InputStream str) { }

	public bool get_CertReq() { }

	internal X509Extensions get_Extensions() { }

	public override bool get_HasExtensions() { }

	public string get_MessageImprintAlgOid() { }

	public BigInteger get_Nonce() { }

	public string get_ReqPolicy() { }

	public int get_Version() { }

	public Byte[] GetEncoded() { }

	public override X509Extension GetExtension(DerObjectIdentifier oid) { }

	public override IList<DerObjectIdentifier> GetExtensionOids() { }

	public Byte[] GetMessageImprintDigest() { }

	protected virtual X509Extensions GetX509Extensions() { }

	public void Validate(IList<String> algorithms, IList<String> policies, IList<String> extensions) { }

}

