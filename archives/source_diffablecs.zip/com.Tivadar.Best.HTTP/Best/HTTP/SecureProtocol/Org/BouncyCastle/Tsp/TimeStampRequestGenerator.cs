namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Tsp;

public class TimeStampRequestGenerator
{
	private DerObjectIdentifier reqPolicy; //Field offset: 0x10
	private DerBoolean certReq; //Field offset: 0x18
	private Dictionary<DerObjectIdentifier, X509Extension> m_extensions; //Field offset: 0x20
	private List<DerObjectIdentifier> m_ordering; //Field offset: 0x28

	public TimeStampRequestGenerator() { }

	public override void AddExtension(DerObjectIdentifier oid, bool critical, Asn1Encodable extValue) { }

	public override void AddExtension(DerObjectIdentifier oid, bool critical, Byte[] extValue) { }

	public TimeStampRequest Generate(string digestAlgorithm, Byte[] digest) { }

	public TimeStampRequest Generate(string digestAlgorithmOid, Byte[] digest, BigInteger nonce) { }

	public override TimeStampRequest Generate(DerObjectIdentifier digestAlgorithm, Byte[] digest) { }

	public override TimeStampRequest Generate(DerObjectIdentifier digestAlgorithm, Byte[] digest, BigInteger nonce) { }

	public void SetCertReq(bool certReq) { }

	public void SetReqPolicy(string reqPolicy) { }

}

