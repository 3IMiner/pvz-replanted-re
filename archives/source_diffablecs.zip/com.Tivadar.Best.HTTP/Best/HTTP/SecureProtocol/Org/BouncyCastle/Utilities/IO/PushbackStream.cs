namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities.IO;

public class PushbackStream : FilterStream
{
	private int m_buf; //Field offset: 0x30

	public PushbackStream(Stream s) { }

	public virtual void CopyTo(Stream destination, int bufferSize) { }

	public virtual int Read(Byte[] buffer, int offset, int count) { }

	public virtual int Read(Span<Byte> buffer) { }

	public virtual int ReadByte() { }

	public override void Unread(int b) { }

}

