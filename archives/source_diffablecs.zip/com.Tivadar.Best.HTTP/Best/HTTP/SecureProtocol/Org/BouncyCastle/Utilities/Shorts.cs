namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities;

public static class Shorts
{
	public const int NumBits = 16; //Field offset: 0x0
	public const int NumBytes = 2; //Field offset: 0x0

	public static short ReverseBytes(short i) { }

	[CLSCompliant(False)]
	public static ushort ReverseBytes(ushort i) { }

	public static short RotateLeft(short i, int distance) { }

	[CLSCompliant(False)]
	public static ushort RotateLeft(ushort i, int distance) { }

	public static short RotateRight(short i, int distance) { }

	[CLSCompliant(False)]
	public static ushort RotateRight(ushort i, int distance) { }

}

