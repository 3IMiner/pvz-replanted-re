namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.X509;

public class X509Certificate : X509ExtensionBase
{
	private class CachedEncoding
	{
		private readonly Byte[] encoding; //Field offset: 0x10
		private readonly CertificateEncodingException exception; //Field offset: 0x18

		internal Byte[] Encoding
		{
			internal get { } //Length: 5
		}

		internal CachedEncoding(Byte[] encoding, CertificateEncodingException exception) { }

		internal Byte[] get_Encoding() { }

		internal Byte[] GetEncoded() { }

	}

	private readonly X509CertificateStructure c; //Field offset: 0x10
	private readonly string sigAlgName; //Field offset: 0x18
	private readonly Byte[] sigAlgParams; //Field offset: 0x20
	private readonly BasicConstraints basicConstraints; //Field offset: 0x28
	private readonly Boolean[] keyUsage; //Field offset: 0x30
	private readonly object cacheLock; //Field offset: 0x38
	private AsymmetricKeyParameter publicKeyValue; //Field offset: 0x40
	private CachedEncoding cachedEncoding; //Field offset: 0x48
	private bool hashValueSet; //Field offset: 0x50
	private int hashValue; //Field offset: 0x54

	public override X509CertificateStructure CertificateStructure
	{
		 get { } //Length: 5
	}

	public override X509Name IssuerDN
	{
		 get { } //Length: 29
	}

	public override DerBitString IssuerUniqueID
	{
		 get { } //Length: 36
	}

	public override bool IsValidNow
	{
		 get { } //Length: 96
	}

	public override DateTime NotAfter
	{
		 get { } //Length: 44
	}

	public override DateTime NotBefore
	{
		 get { } //Length: 44
	}

	public override BigInteger SerialNumber
	{
		 get { } //Length: 44
	}

	public override string SigAlgName
	{
		 get { } //Length: 5
	}

	public override string SigAlgOid
	{
		 get { } //Length: 60
	}

	public override X509Name SubjectDN
	{
		 get { } //Length: 29
	}

	public override DerBitString SubjectUniqueID
	{
		 get { } //Length: 36
	}

	public override int Version
	{
		 get { } //Length: 29
	}

	protected X509Certificate() { }

	public X509Certificate(Byte[] certData) { }

	public X509Certificate(X509CertificateStructure c) { }

	protected override void CheckSignature(IVerifierFactory verifier) { }

	public override void CheckValidity(DateTime time) { }

	public override void CheckValidity() { }

	public virtual bool Equals(object other) { }

	public override X509CertificateStructure get_CertificateStructure() { }

	public override X509Name get_IssuerDN() { }

	public override DerBitString get_IssuerUniqueID() { }

	public override bool get_IsValidNow() { }

	public override DateTime get_NotAfter() { }

	public override DateTime get_NotBefore() { }

	public override BigInteger get_SerialNumber() { }

	public override string get_SigAlgName() { }

	public override string get_SigAlgOid() { }

	public override X509Name get_SubjectDN() { }

	public override DerBitString get_SubjectUniqueID() { }

	public override int get_Version() { }

	protected override GeneralNames GetAlternativeNameExtension(DerObjectIdentifier oid) { }

	protected override IList<IList`1<Object>> GetAlternativeNames(DerObjectIdentifier oid) { }

	public override int GetBasicConstraints() { }

	private CachedEncoding GetCachedEncoding() { }

	public override Byte[] GetEncoded() { }

	public override IList<DerObjectIdentifier> GetExtendedKeyUsage() { }

	public virtual int GetHashCode() { }

	public override GeneralNames GetIssuerAlternativeNameExtension() { }

	public override IList<IList`1<Object>> GetIssuerAlternativeNames() { }

	public override Boolean[] GetKeyUsage() { }

	public override AsymmetricKeyParameter GetPublicKey() { }

	public override Byte[] GetSigAlgParams() { }

	public override Byte[] GetSignature() { }

	public override GeneralNames GetSubjectAlternativeNameExtension() { }

	public override IList<IList`1<Object>> GetSubjectAlternativeNames() { }

	public override Byte[] GetTbsCertificate() { }

	protected virtual X509Extensions GetX509Extensions() { }

	private static bool IsAlgIDEqual(AlgorithmIdentifier id1, AlgorithmIdentifier id2) { }

	public override bool IsValid(DateTime time) { }

	public virtual string ToString() { }

	public override void Verify(AsymmetricKeyParameter key) { }

	public override void Verify(IVerifierFactoryProvider verifierProvider) { }

}

