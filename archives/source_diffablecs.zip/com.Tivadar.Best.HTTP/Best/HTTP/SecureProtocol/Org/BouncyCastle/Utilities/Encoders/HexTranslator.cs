namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities.Encoders;

public class HexTranslator : ITranslator
{
	private static readonly Byte[] hexTable; //Field offset: 0x0

	private static HexTranslator() { }

	public HexTranslator() { }

	public override int Decode(Byte[] input, int inOff, int length, Byte[] outBytes, int outOff) { }

	public override int Encode(Byte[] input, int inOff, int length, Byte[] outBytes, int outOff) { }

	public override int GetDecodedBlockSize() { }

	public override int GetEncodedBlockSize() { }

}

