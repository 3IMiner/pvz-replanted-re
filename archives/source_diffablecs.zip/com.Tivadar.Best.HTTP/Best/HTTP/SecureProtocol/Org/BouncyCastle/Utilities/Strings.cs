namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities;

public static class Strings
{

	public static string FromAsciiByteArray(Byte[] bytes) { }

	public static string FromByteArray(Byte[] bs) { }

	public static string FromUtf8ByteArray(Byte[] bytes) { }

	internal static bool IsOneOf(string s, String[] candidates) { }

	public static Byte[] ToAsciiByteArray(Char[] cs) { }

	public static Byte[] ToAsciiByteArray(string s) { }

	public static Byte[] ToByteArray(Char[] cs) { }

	public static Byte[] ToByteArray(string s) { }

	public static Byte[] ToUtf8ByteArray(Char[] cs) { }

	public static Byte[] ToUtf8ByteArray(string s) { }

}

