namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities.Collections;

[DefaultMember("Item")]
internal abstract class ReadOnlyDictionary : IDictionary<K, V>, ICollection<KeyValuePair`2<K, V>>, IEnumerable<KeyValuePair`2<K, V>>, IEnumerable
{

	public abstract int Count
	{
		 get { } //Length: 0
	}

	public override bool IsReadOnly
	{
		 get { } //Length: 3
	}

	public override V Item
	{
		 get { } //Length: 20
		 set { } //Length: 57
	}

	public abstract ICollection<K> Keys
	{
		 get { } //Length: 0
	}

	public abstract ICollection<V> Values
	{
		 get { } //Length: 0
	}

	protected ReadOnlyDictionary`2() { }

	public override void Add(KeyValuePair<K, V> item) { }

	public override void Add(K key, V value) { }

	public override void Clear() { }

	public abstract bool Contains(KeyValuePair<K, V> item) { }

	public abstract bool ContainsKey(K key) { }

	public abstract void CopyTo(KeyValuePair<K, V>[] array, int arrayIndex) { }

	public abstract int get_Count() { }

	public override bool get_IsReadOnly() { }

	public override V get_Item(K key) { }

	public abstract ICollection<K> get_Keys() { }

	public abstract ICollection<V> get_Values() { }

	public abstract IEnumerator<KeyValuePair`2<K, V>> GetEnumerator() { }

	protected abstract V Lookup(K key) { }

	public override bool Remove(K key) { }

	public override bool Remove(KeyValuePair<K, V> item) { }

	public override void set_Item(K key, V value) { }

	private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

	public abstract bool TryGetValue(K key, out V value) { }

}

