namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities.IO.Pem;

public class PemObject : PemObjectGenerator
{
	private string type; //Field offset: 0x10
	private IList<PemHeader> headers; //Field offset: 0x18
	private Byte[] content; //Field offset: 0x20

	public Byte[] Content
	{
		 get { } //Length: 5
	}

	public IList<PemHeader> Headers
	{
		 get { } //Length: 5
	}

	public string Type
	{
		 get { } //Length: 5
	}

	public PemObject(string type, Byte[] content) { }

	public PemObject(string type, IList<PemHeader> headers, Byte[] content) { }

	public override PemObject Generate() { }

	public Byte[] get_Content() { }

	public IList<PemHeader> get_Headers() { }

	public string get_Type() { }

}

