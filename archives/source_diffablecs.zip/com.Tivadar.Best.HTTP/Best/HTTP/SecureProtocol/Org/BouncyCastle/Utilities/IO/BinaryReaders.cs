namespace Best.HTTP.SecureProtocol.Org.BouncyCastle.Utilities.IO;

public static class BinaryReaders
{

	public static Byte[] ReadBytesFully(BinaryReader binaryReader, int count) { }

	public static short ReadInt16BigEndian(BinaryReader binaryReader) { }

	public static short ReadInt16LittleEndian(BinaryReader binaryReader) { }

	public static int ReadInt32BigEndian(BinaryReader binaryReader) { }

	public static int ReadInt32LittleEndian(BinaryReader binaryReader) { }

	public static long ReadInt64BigEndian(BinaryReader binaryReader) { }

	public static long ReadInt64LittleEndian(BinaryReader binaryReader) { }

	[CLSCompliant(False)]
	public static ushort ReadUInt16BigEndian(BinaryReader binaryReader) { }

	[CLSCompliant(False)]
	public static ushort ReadUInt16LittleEndian(BinaryReader binaryReader) { }

	[CLSCompliant(False)]
	public static uint ReadUInt32BigEndian(BinaryReader binaryReader) { }

	[CLSCompliant(False)]
	public static uint ReadUInt32LittleEndian(BinaryReader binaryReader) { }

	[CLSCompliant(False)]
	public static ulong ReadUInt64BigEndian(BinaryReader binaryReader) { }

	[CLSCompliant(False)]
	public static ulong ReadUInt64LittleEndian(BinaryReader binaryReader) { }

}

