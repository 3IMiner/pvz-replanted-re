namespace Best.HTTP.Shared;

[ExecuteInEditMode]
[Il2CppEagerStaticClassConstruction]
public sealed class HTTPUpdateDelegator : MonoBehaviour
{
	private static HTTPUpdateDelegator instance; //Field offset: 0x0
	[CompilerGenerated]
	private static bool <IsCreated>k__BackingField; //Field offset: 0x8
	[CompilerGenerated]
	private static bool <IsThreadRunning>k__BackingField; //Field offset: 0x9
	[CompilerGenerated]
	private static int <ThreadFrequencyInMS>k__BackingField; //Field offset: 0xC
	public static Func<Boolean> OnBeforeApplicationQuit; //Field offset: 0x10
	public static Action<Boolean> OnApplicationForegroundStateChanged; //Field offset: 0x18
	private static bool isSetupCalled; //Field offset: 0x20
	private ThreadingMode _currentThreadingMode; //Field offset: 0x20
	private int isHTTPManagerOnUpdateRunning; //Field offset: 0x24
	private AutoResetEvent pingEvent; //Field offset: 0x28
	private int updateThreadCount; //Field offset: 0x30
	private int mainThreadId; //Field offset: 0x34

	public ThreadingMode CurrentThreadingMode
	{
		 get { } //Length: 4
		 set { } //Length: 8
	}

	public static HTTPUpdateDelegator Instance
	{
		 get { } //Length: 64
	}

	public private static bool IsCreated
	{
		[CompilerGenerated]
		 get { } //Length: 79
		[CompilerGenerated]
		private set { } //Length: 84
	}

	public private static bool IsThreadRunning
	{
		[CompilerGenerated]
		 get { } //Length: 79
		[CompilerGenerated]
		private set { } //Length: 84
	}

	public int MainThreadId
	{
		 get { } //Length: 4
	}

	public static int ThreadFrequencyInMS
	{
		[CompilerGenerated]
		 get { } //Length: 78
		[CompilerGenerated]
		 set { } //Length: 83
	}

	private static HTTPUpdateDelegator() { }

	public HTTPUpdateDelegator() { }

	private void CallOnUpdate() { }

	public static HTTPUpdateDelegator CheckInstance() { }

	public ThreadingMode get_CurrentThreadingMode() { }

	public static HTTPUpdateDelegator get_Instance() { }

	[CompilerGenerated]
	public static bool get_IsCreated() { }

	[CompilerGenerated]
	public static bool get_IsThreadRunning() { }

	public int get_MainThreadId() { }

	[CompilerGenerated]
	public static int get_ThreadFrequencyInMS() { }

	public bool IsMainThread() { }

	private void OnApplicationPause(bool isPaused) { }

	private void OnDisable() { }

	public void PingUpdateThread() { }

	public void set_CurrentThreadingMode(ThreadingMode value) { }

	[CompilerGenerated]
	private static void set_IsCreated(bool value) { }

	[CompilerGenerated]
	private static void set_IsThreadRunning(bool value) { }

	[CompilerGenerated]
	public static void set_ThreadFrequencyInMS(int value) { }

	public void SetThreadingMode(ThreadingMode mode) { }

	public void Setup() { }

	public void SwapThreadingMode() { }

	private void ThreadFunc() { }

	private static bool UnityApplication_WantsToQuit() { }

	private void Update() { }

}

