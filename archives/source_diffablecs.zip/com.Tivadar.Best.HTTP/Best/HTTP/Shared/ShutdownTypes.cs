namespace Best.HTTP.Shared;

public enum ShutdownTypes
{
	Running = 0,
	Gentle = 1,
	Immediate = 2,
}

