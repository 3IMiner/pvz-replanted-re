namespace Best.HTTP.Shared.Extensions;

internal struct HeartbeatUpdateEvent
{
	public HeartbeatUpdateEventType Event; //Field offset: 0x0
	public IHeartbeat Heartbeat; //Field offset: 0x8

}

