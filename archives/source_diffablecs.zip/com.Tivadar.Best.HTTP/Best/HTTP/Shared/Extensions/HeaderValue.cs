namespace Best.HTTP.Shared.Extensions;

public sealed class HeaderValue
{
	[CompilerGenerated]
	private sealed class <>c
	{
		public static readonly <>c <>9; //Field offset: 0x0
		public static Func<Char, Boolean> <>9__18_0; //Field offset: 0x8

		private static <>c() { }

		public <>c() { }

		internal bool <ParseImplementation>b__18_0(char ch) { }

	}

	[CompilerGenerated]
	private string <Key>k__BackingField; //Field offset: 0x10
	[CompilerGenerated]
	private string <Value>k__BackingField; //Field offset: 0x18
	[CompilerGenerated]
	private List<HeaderValue> <Options>k__BackingField; //Field offset: 0x20

	public bool HasValue
	{
		 get { } //Length: 22
	}

	public string Key
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		 set { } //Length: 13
	}

	public List<HeaderValue> Options
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		 set { } //Length: 13
	}

	public string Value
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		 set { } //Length: 13
	}

	public HeaderValue() { }

	public HeaderValue(string key) { }

	public bool get_HasValue() { }

	[CompilerGenerated]
	public string get_Key() { }

	[CompilerGenerated]
	public List<HeaderValue> get_Options() { }

	[CompilerGenerated]
	public string get_Value() { }

	public void Parse(string headerStr, ref int pos) { }

	private void ParseImplementation(string headerStr, ref int pos, bool isOptionIsAnOption) { }

	[CompilerGenerated]
	public void set_Key(string value) { }

	[CompilerGenerated]
	public void set_Options(List<HeaderValue> value) { }

	[CompilerGenerated]
	public void set_Value(string value) { }

	public virtual string ToString() { }

	public bool TryGetOption(string key, out HeaderValue option) { }

}

