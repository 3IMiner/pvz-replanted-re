namespace Best.HTTP.Shared.Extensions;

public interface IHeartbeat
{

	public void OnHeartbeatUpdate(DateTime utcNow, TimeSpan dif) { }

}

