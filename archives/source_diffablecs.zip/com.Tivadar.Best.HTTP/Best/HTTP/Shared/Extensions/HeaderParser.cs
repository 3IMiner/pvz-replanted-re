namespace Best.HTTP.Shared.Extensions;

public sealed class HeaderParser : KeyValuePairList
{

	public HeaderParser(string headerStr) { }

	private List<HeaderValue> Parse(string headerStr) { }

}

