namespace Best.HTTP.Shared.Extensions;

public static class Timer
{
	private sealed class TimerImplementation : IHeartbeat
	{

		public TimerImplementation() { }

		public override void OnHeartbeatUpdate(DateTime now, TimeSpan dif) { }

	}

	private static List<TimerData> _timers; //Field offset: 0x0
	private static ReaderWriterLockSlim _lock; //Field offset: 0x8
	private static int _isSubscribed; //Field offset: 0x10

	private static Timer() { }

	public static void Add(TimerData timer) { }

}

