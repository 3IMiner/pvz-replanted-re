namespace Best.HTTP.Shared.Extensions;

[IsReadOnly]
public struct TimerData
{
	public readonly DateTime Created; //Field offset: 0x0
	public readonly TimeSpan Interval; //Field offset: 0x8
	public readonly object Context; //Field offset: 0x10
	public readonly Func<DateTime, Object, Boolean> OnTimer; //Field offset: 0x18

	public TimerData(TimeSpan interval, object context, Func<DateTime, Object, Boolean> onTimer) { }

	public TimerData CreateNew() { }

	public bool IsOnTime(DateTime now) { }

	public virtual string ToString() { }

}

