namespace Best.HTTP.Shared.Extensions;

public static class ExceptionHelper
{

	public static Exception ServerClosedTCPStream() { }

}

