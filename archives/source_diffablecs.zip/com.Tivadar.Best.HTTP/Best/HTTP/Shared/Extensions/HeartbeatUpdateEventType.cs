namespace Best.HTTP.Shared.Extensions;

internal enum HeartbeatUpdateEventType
{
	Subscribe = 0,
	Unsubscribe = 1,
	Clear = 2,
}

