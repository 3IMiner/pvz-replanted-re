namespace Best.HTTP.Shared.Extensions;

public sealed class RunOnceOnMainThread : IHeartbeat
{
	private Action _action; //Field offset: 0x10
	private int _subscribed; //Field offset: 0x18
	private LoggingContext _context; //Field offset: 0x20

	public RunOnceOnMainThread(Action action, LoggingContext context) { }

	public override void OnHeartbeatUpdate(DateTime now, TimeSpan dif) { }

	public void Subscribe() { }

}

