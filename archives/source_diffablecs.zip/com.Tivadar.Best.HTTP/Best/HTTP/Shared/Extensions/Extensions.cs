namespace Best.HTTP.Shared.Extensions;

[Extension]
public static class Extensions
{
	[CompilerGenerated]
	private sealed class <>c
	{
		public static readonly <>c <>9; //Field offset: 0x0
		public static Func<Char, Boolean> <>9__41_0; //Field offset: 0x8
		public static Func<Char, Boolean> <>9__41_1; //Field offset: 0x10
		public static Func<Char, Boolean> <>9__45_0; //Field offset: 0x18
		public static Func<Char, Boolean> <>9__46_0; //Field offset: 0x20

		private static <>c() { }

		public <>c() { }

		internal bool <ParseOptionalHeader>b__45_0(char ch) { }

		internal bool <ParseQualityParams>b__46_0(char ch) { }

		internal bool <ReadPossibleQuotedText>b__41_0(char ch) { }

		internal bool <ReadPossibleQuotedText>b__41_1(char ch) { }

	}

	[CompilerGenerated]
	private sealed class <>c__DisplayClass39_0
	{
		public char block; //Field offset: 0x10

		public <>c__DisplayClass39_0() { }

		internal bool <Read>b__0(char ch) { }

	}

	private static readonly Regex validIpV4AddressRegex; //Field offset: 0x0

	private static Extensions() { }

	[Extension]
	public static Dictionary<String, List`1<String>> AddHeader(Dictionary<String, List`1<String>> headers, string name, string value) { }

	[Extension]
	public static AutoReleaseBuffer AsAutoRelease(Byte[] buffer) { }

	[Extension]
	public static BufferSegment AsBuffer(Byte[] bytes, int offset, int length) { }

	[Extension]
	public static BufferSegment AsBuffer(Byte[] bytes, int length) { }

	[Extension]
	public static BufferSegment AsBuffer(Byte[] bytes) { }

	[Extension]
	public static string AsciiToString(Byte[] bytes) { }

	[Extension]
	public static string CalculateMD5Hash(BufferSegment input) { }

	[Extension]
	public static string CalculateMD5Hash(string input) { }

	[Extension]
	public static void Clear(ConcurrentQueue<T> queue) { }

	[Extension]
	public static BufferSegment CopyAsBuffer(Byte[] bytes, int offset, int length) { }

	[Extension]
	public static String[] FindOption(String[] options, string option) { }

	[Extension]
	public static String[] FindOption(string str, string option) { }

	[Extension]
	public static BufferSegment GetASCIIBytes(string str) { }

	[Extension]
	public static string GetFirstHeaderValue(Dictionary<String, List`1<String>> headers, string name) { }

	[Extension]
	public static List<String> GetHeaderValues(Dictionary<String, List`1<String>> headers, string name) { }

	[Extension]
	public static string GetRequestPathAndQueryURL(Uri uri) { }

	[Extension]
	public static bool HasHeader(Dictionary<String, List`1<String>> headers, string headerName) { }

	[Extension]
	public static bool HasHeaderWithValue(Dictionary<String, List`1<String>> headers, string headerName, string value) { }

	[Extension]
	public static bool IsHostIsAnIPAddress(Uri uri) { }

	public static bool IsIpV4AddressValid(string address) { }

	public static bool IsIpV6AddressValid(string address) { }

	[Extension]
	internal static List<HeaderValue> ParseOptionalHeader(string str) { }

	[Extension]
	internal static List<HeaderValue> ParseQualityParams(string str) { }

	[Extension]
	internal static Nullable<Char> Peek(string str, int pos) { }

	[Extension]
	internal static string Read(string str, ref int pos, char block, bool needResult = true) { }

	[Extension]
	internal static string Read(string str, ref int pos, Func<Char, Boolean> block, bool needResult = true) { }

	[Extension]
	public static void ReadBuffer(Stream stream, Byte[] buffer, int length) { }

	[Extension]
	public static void ReadBuffer(Stream stream, Byte[] buffer) { }

	[Extension]
	internal static string ReadPossibleQuotedText(string str, ref int pos) { }

	[Extension]
	public static bool RemoveHeader(Dictionary<String, List`1<String>> headers, string name) { }

	[Extension]
	public static void RemoveHeaders(Dictionary<String, List`1<String>> headers) { }

	[Extension]
	public static void SendAsASCII(BinaryWriter stream, string str) { }

	[Extension]
	public static Dictionary<String, List`1<String>> SetHeader(Dictionary<String, List`1<String>> headers, string name, string value) { }

	[Extension]
	internal static void SkipWhiteSpace(string str, ref int pos) { }

	[Extension]
	public static string ToBinaryStr(byte value) { }

	[Extension]
	public static DateTime ToDateTime(string str, DateTime defaultValue = null) { }

	[Extension]
	public static int ToInt32(string str, int defaultValue = 0) { }

	[Extension]
	public static long ToInt64(string str, long defaultValue = 0) { }

	[Extension]
	public static string ToStr(string str, string defaultVale) { }

	[Extension]
	public static string ToStrOrEmpty(string str) { }

	[Extension]
	public static uint ToUInt32(string str, uint defaultValue = 0) { }

	[Extension]
	public static ulong ToUInt64(string str, ulong defaultValue = 0) { }

	[Extension]
	internal static string TrimAndLower(string str) { }

	[Extension]
	public static void WriteArray(Stream stream, Byte[] array) { }

	[Extension]
	public static void WriteBufferSegment(Stream stream, BufferSegment buffer) { }

	[Extension]
	public static void WriteLine(Stream fs, string line) { }

	[Extension]
	public static void WriteLine(Stream fs, string format, Object[] values) { }

	[Extension]
	public static void WriteLine(BufferPoolMemoryStream ms) { }

	[Extension]
	public static void WriteLine(BufferPoolMemoryStream ms, string str) { }

	[Extension]
	public static void WriteLine(Stream fs) { }

	[Extension]
	public static void WriteString(BufferPoolMemoryStream ms, string str) { }

	[Extension]
	public static void WriteString(Stream fs, string value) { }

}

