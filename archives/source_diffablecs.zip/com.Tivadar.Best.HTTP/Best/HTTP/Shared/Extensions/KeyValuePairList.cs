namespace Best.HTTP.Shared.Extensions;

public class KeyValuePairList
{
	[CompilerGenerated]
	private List<HeaderValue> <Values>k__BackingField; //Field offset: 0x10

	public List<HeaderValue> Values
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		 set { } //Length: 13
	}

	public KeyValuePairList() { }

	[CompilerGenerated]
	public List<HeaderValue> get_Values() { }

	[CompilerGenerated]
	protected void set_Values(List<HeaderValue> value) { }

	public bool TryGet(string valueKeyName, out HeaderValue param) { }

}

