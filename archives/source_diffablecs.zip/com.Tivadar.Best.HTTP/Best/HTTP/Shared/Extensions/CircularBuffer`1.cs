namespace Best.HTTP.Shared.Extensions;

[DefaultMember("Item")]
public sealed class CircularBuffer
{
	[CompilerGenerated]
	private int <Capacity>k__BackingField; //Field offset: 0x0
	[CompilerGenerated]
	private int <Count>k__BackingField; //Field offset: 0x0
	private T[] buffer; //Field offset: 0x0
	private int startIdx; //Field offset: 0x0
	private int endIdx; //Field offset: 0x0

	public private int Capacity
	{
		[CompilerGenerated]
		 get { } //Length: 4
		[CompilerGenerated]
		private set { } //Length: 4
	}

	public private int Count
	{
		[CompilerGenerated]
		 get { } //Length: 4
		[CompilerGenerated]
		private set { } //Length: 4
	}

	public int EndIdx
	{
		 get { } //Length: 4
	}

	public T Item
	{
		 get { } //Length: 54
		 set { } //Length: 54
	}

	public int StartIdx
	{
		 get { } //Length: 4
	}

	public CircularBuffer`1(int capacity) { }

	public void Add(T element) { }

	public void Clear() { }

	[CompilerGenerated]
	public int get_Capacity() { }

	[CompilerGenerated]
	public int get_Count() { }

	public int get_EndIdx() { }

	public T get_Item(int idx) { }

	public int get_StartIdx() { }

	[CompilerGenerated]
	private void set_Capacity(int value) { }

	[CompilerGenerated]
	private void set_Count(int value) { }

	public void set_Item(int idx, T value) { }

	public virtual string ToString() { }

}

