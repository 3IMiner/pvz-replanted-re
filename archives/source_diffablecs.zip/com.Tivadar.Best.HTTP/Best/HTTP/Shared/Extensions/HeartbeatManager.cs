namespace Best.HTTP.Shared.Extensions;

public sealed class HeartbeatManager
{
	private List<IHeartbeat> _heartbeats; //Field offset: 0x10
	private DateTime _lastUpdate; //Field offset: 0x18
	private ConcurrentQueue<HeartbeatUpdateEvent> _updates; //Field offset: 0x20

	public HeartbeatManager() { }

	public void Clear() { }

	public void Subscribe(IHeartbeat heartbeat) { }

	public void Unsubscribe(IHeartbeat heartbeat) { }

	public void Update() { }

}

