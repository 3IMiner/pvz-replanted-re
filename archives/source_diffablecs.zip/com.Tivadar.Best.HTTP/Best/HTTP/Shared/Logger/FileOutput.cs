namespace Best.HTTP.Shared.Logger;

public sealed class FileOutput : ILogOutput, IDisposable
{
	[CompilerGenerated]
	private readonly bool <AcceptColor>k__BackingField; //Field offset: 0x10
	private Stream fileStream; //Field offset: 0x18

	public override bool AcceptColor
	{
		[CompilerGenerated]
		 get { } //Length: 5
	}

	public FileOutput(string fileName) { }

	public override void Dispose() { }

	public override void Flush() { }

	[CompilerGenerated]
	public override bool get_AcceptColor() { }

	public override void Write(Loglevels level, string logEntry) { }

}

