namespace Best.HTTP.Shared.Logger;

public sealed class MultiDivisionFilter : IFilter
{
	private String[] _divisions; //Field offset: 0x10

	public MultiDivisionFilter(String[] divisions) { }

	public override bool Include(string division) { }

}

