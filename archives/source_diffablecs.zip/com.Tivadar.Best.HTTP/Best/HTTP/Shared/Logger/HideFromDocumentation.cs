namespace Best.HTTP.Shared.Logger;

[HideFromDocumentation]
public sealed class HideFromDocumentation : Attribute
{

	public HideFromDocumentation() { }

}

