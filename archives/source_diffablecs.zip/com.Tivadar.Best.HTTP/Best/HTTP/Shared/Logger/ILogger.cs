namespace Best.HTTP.Shared.Logger;

public interface ILogger
{

	public IFilter Filter
	{
		 get { } //Length: 0
		 set { } //Length: 0
	}

	public bool IsDiagnostic
	{
		 get { } //Length: 0
	}

	public bool IsEmpty
	{
		 get { } //Length: 0
	}

	public Loglevels Level
	{
		 get { } //Length: 0
		 set { } //Length: 0
	}

	public ILogOutput Output
	{
		 get { } //Length: 0
		 set { } //Length: 0
	}

	public void Error(string division, string msg, LoggingContext context = null) { }

	public void Exception(string division, string msg, Exception ex, LoggingContext context = null) { }

	public IFilter get_Filter() { }

	public bool get_IsDiagnostic() { }

	public bool get_IsEmpty() { }

	public Loglevels get_Level() { }

	public ILogOutput get_Output() { }

	public void Information(string division, string msg, LoggingContext context = null) { }

	public void set_Filter(IFilter value) { }

	public void set_Level(Loglevels value) { }

	public void set_Output(ILogOutput value) { }

	public void Verbose(string division, string msg, LoggingContext context = null) { }

	public void Warning(string division, string msg, LoggingContext context = null) { }

}

