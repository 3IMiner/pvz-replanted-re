namespace Best.HTTP.Shared.Logger;

public sealed class ThreadedLogger : ILogger, IDisposable
{
	[CompilerGenerated]
	private Loglevels <Level>k__BackingField; //Field offset: 0x10
	private ILogOutput _output; //Field offset: 0x18
	[CompilerGenerated]
	private IFilter <Filter>k__BackingField; //Field offset: 0x20
	public int InitialStringBufferCapacity; //Field offset: 0x28
	public TimeSpan ExitThreadAfterInactivity; //Field offset: 0x30
	private ConcurrentQueue<LogJob> jobs; //Field offset: 0x38
	private AutoResetEvent newJobEvent; //Field offset: 0x40
	private int threadCreated; //Field offset: 0x48
	private bool isDisposed; //Field offset: 0x4C
	private StringBuilder sb; //Field offset: 0x50

	public override IFilter Filter
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		 set { } //Length: 13
	}

	public override bool IsDiagnostic
	{
		 get { } //Length: 8
	}

	public override bool IsEmpty
	{
		 get { } //Length: 68
	}

	public override Loglevels Level
	{
		[CompilerGenerated]
		 get { } //Length: 4
		[CompilerGenerated]
		 set { } //Length: 4
	}

	public override ILogOutput Output
	{
		 get { } //Length: 5
		 set { } //Length: 102
	}

	public int QueuedJobs
	{
		 get { } //Length: 68
	}

	public ThreadedLogger() { }

	private void AddJob(Loglevels level, string div, string msg, Exception ex, LoggingContext context) { }

	public override void Dispose() { }

	public override void Error(string division, string msg, LoggingContext context) { }

	public override void Exception(string division, string msg, Exception ex, LoggingContext context) { }

	[CompilerGenerated]
	public override IFilter get_Filter() { }

	public override bool get_IsDiagnostic() { }

	public override bool get_IsEmpty() { }

	[CompilerGenerated]
	public override Loglevels get_Level() { }

	public override ILogOutput get_Output() { }

	public int get_QueuedJobs() { }

	public override void Information(string division, string msg, LoggingContext context) { }

	[CompilerGenerated]
	public override void set_Filter(IFilter value) { }

	[CompilerGenerated]
	public override void set_Level(Loglevels value) { }

	public override void set_Output(ILogOutput value) { }

	private void ThreadFunc() { }

	public override void Verbose(string division, string msg, LoggingContext context) { }

	public override void Warning(string division, string msg, LoggingContext context) { }

	private void WriteJob(ref LogJob job) { }

}

