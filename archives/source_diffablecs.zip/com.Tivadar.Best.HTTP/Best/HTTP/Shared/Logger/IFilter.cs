namespace Best.HTTP.Shared.Logger;

public interface IFilter
{

	public bool Include(string division) { }

}

