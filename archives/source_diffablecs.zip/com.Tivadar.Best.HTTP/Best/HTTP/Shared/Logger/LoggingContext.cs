namespace Best.HTTP.Shared.Logger;

public sealed class LoggingContext
{
	[CompilerGenerated]
	private sealed class <>c__DisplayClass13_0
	{
		public string fieldName; //Field offset: 0x10

		public <>c__DisplayClass13_0() { }

		internal bool <GetStringField>b__0(LoggingContextField f) { }

	}

	private struct LoggingContextField
	{
		public string key; //Field offset: 0x0
		public long longValue; //Field offset: 0x8
		public bool boolValue; //Field offset: 0x10
		public string stringValue; //Field offset: 0x18
		public LoggingContext loggingContextValue; //Field offset: 0x20
		public LoggingContextFieldType fieldType; //Field offset: 0x28

		public virtual string ToString() { }

	}

	private enum LoggingContextFieldType
	{
		Long = 0,
		Bool = 1,
		String = 2,
		AnotherContext = 3,
	}

	[CompilerGenerated]
	private string <Hash>k__BackingField; //Field offset: 0x10
	private List<LoggingContextField> fields; //Field offset: 0x18

	public private string Hash
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 13
	}

	public LoggingContext(object boundto) { }

	public void Add(string key, long value) { }

	public void Add(string key, bool value) { }

	public void Add(string key, string value) { }

	public void Add(string key, LoggingContext value) { }

	private void Add(LoggingContextField field) { }

	public static string Escape(string original) { }

	[CompilerGenerated]
	public string get_Hash() { }

	public string GetStringField(string fieldName) { }

	public void Remove(string key) { }

	[CompilerGenerated]
	private void set_Hash(string value) { }

	public void ToJson(StringBuilder sb) { }

}

