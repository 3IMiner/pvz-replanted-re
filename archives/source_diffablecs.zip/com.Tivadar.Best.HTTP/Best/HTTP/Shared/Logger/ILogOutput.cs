namespace Best.HTTP.Shared.Logger;

public interface ILogOutput : IDisposable
{

	public bool AcceptColor
	{
		 get { } //Length: 0
	}

	public void Flush() { }

	public bool get_AcceptColor() { }

	public void Write(Loglevels level, string logEntry) { }

}

