namespace Best.HTTP.Shared.Logger;

public sealed class SingleDivisionFilter : IFilter
{
	private string _division; //Field offset: 0x10

	public SingleDivisionFilter(string division) { }

	public override bool Include(string division) { }

}

