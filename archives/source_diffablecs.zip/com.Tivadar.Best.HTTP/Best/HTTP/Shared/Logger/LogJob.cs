namespace Best.HTTP.Shared.Logger;

[Il2CppEagerStaticClassConstruction]
internal struct LogJob
{
	private static String[] LevelStrings; //Field offset: 0x0
	public Loglevels level; //Field offset: 0x0
	public string division; //Field offset: 0x8
	public string msg; //Field offset: 0x10
	public Exception ex; //Field offset: 0x18
	public DateTime time; //Field offset: 0x20
	public int threadId; //Field offset: 0x28
	public string stackTrace; //Field offset: 0x30
	public string context; //Field offset: 0x38

	private static LogJob() { }

	private void ProcessStackTrace(StringBuilder sb) { }

	public string ToJson(StringBuilder sb, bool acceptColor) { }

	private static string WrapInColor(string str, string color, bool acceptColor) { }

}

