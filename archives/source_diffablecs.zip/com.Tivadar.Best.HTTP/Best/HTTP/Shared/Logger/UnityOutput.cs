namespace Best.HTTP.Shared.Logger;

public sealed class UnityOutput : ILogOutput, IDisposable
{
	[CompilerGenerated]
	private readonly bool <AcceptColor>k__BackingField; //Field offset: 0x10

	public override bool AcceptColor
	{
		[CompilerGenerated]
		 get { } //Length: 5
	}

	public UnityOutput() { }

	private override void Best.HTTP.Shared.Logger.ILogOutput.Flush() { }

	[CompilerGenerated]
	public override bool get_AcceptColor() { }

	private override void System.IDisposable.Dispose() { }

	public override void Write(Loglevels level, string logEntry) { }

}

