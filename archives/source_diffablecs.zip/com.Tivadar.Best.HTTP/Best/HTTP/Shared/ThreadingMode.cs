namespace Best.HTTP.Shared;

public enum ThreadingMode
{
	UnityUpdate = 0,
	Threaded = 1,
	None = 2,
}

