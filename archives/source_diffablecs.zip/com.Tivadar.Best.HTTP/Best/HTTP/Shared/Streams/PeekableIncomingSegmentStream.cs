namespace Best.HTTP.Shared.Streams;

public sealed class PeekableIncomingSegmentStream : PeekableStream
{
	private int peek_listIdx; //Field offset: 0x40
	private int peek_pos; //Field offset: 0x44

	public PeekableIncomingSegmentStream() { }

	public virtual void BeginPeek() { }

	public virtual int PeekByte() { }

}

