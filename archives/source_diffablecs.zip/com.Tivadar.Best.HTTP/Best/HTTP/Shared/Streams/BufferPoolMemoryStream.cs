namespace Best.HTTP.Shared.Streams;

public sealed class BufferPoolMemoryStream : Stream
{
	private bool canWrite; //Field offset: 0x28
	private bool allowGetBuffer; //Field offset: 0x29
	private int capacity; //Field offset: 0x2C
	private int length; //Field offset: 0x30
	private Byte[] internalBuffer; //Field offset: 0x38
	private int initialIndex; //Field offset: 0x40
	private bool expandable; //Field offset: 0x44
	private bool streamClosed; //Field offset: 0x45
	private int position; //Field offset: 0x48
	private int dirty_bytes; //Field offset: 0x4C
	private bool releaseInternalBuffer; //Field offset: 0x50

	public virtual bool CanRead
	{
		 get { } //Length: 8
	}

	public virtual bool CanSeek
	{
		 get { } //Length: 8
	}

	public virtual bool CanWrite
	{
		 get { } //Length: 14
	}

	public int Capacity
	{
		 get { } //Length: 103
		 set { } //Length: 577
	}

	public virtual long Length
	{
		 get { } //Length: 105
	}

	public virtual long Position
	{
		 get { } //Length: 105
		 set { } //Length: 312
	}

	public BufferPoolMemoryStream() { }

	public BufferPoolMemoryStream(Byte[] buffer, int index, int count, bool writable, bool publiclyVisible, bool releaseBuffer) { }

	public BufferPoolMemoryStream(Byte[] buffer, int index, int count, bool writable, bool publiclyVisible) { }

	public BufferPoolMemoryStream(Byte[] buffer, int index, int count, bool writable) { }

	public BufferPoolMemoryStream(Byte[] buffer, int index, int count, bool writable, bool publiclyVisible, bool releaseBuffer, bool canExpand) { }

	public BufferPoolMemoryStream(Byte[] buffer, bool writable) { }

	public BufferPoolMemoryStream(Byte[] buffer) { }

	public BufferPoolMemoryStream(int capacity) { }

	public BufferPoolMemoryStream(Byte[] buffer, int index, int count) { }

	private int CalculateNewCapacity(int minimum) { }

	private void CheckIfClosedThrowDisposed() { }

	protected virtual void Dispose(bool disposing) { }

	private void Expand(int newSize) { }

	public virtual void Flush() { }

	public virtual bool get_CanRead() { }

	public virtual bool get_CanSeek() { }

	public virtual bool get_CanWrite() { }

	public int get_Capacity() { }

	public virtual long get_Length() { }

	public virtual long get_Position() { }

	public Byte[] GetBuffer() { }

	private void InternalConstructor(Byte[] buffer, int index, int count, bool writable, bool publicallyVisible, bool releaseBuffer, bool canExpand) { }

	public virtual int Read(Byte[] buffer, int offset, int count) { }

	public virtual int ReadByte() { }

	public virtual long Seek(long offset, SeekOrigin loc) { }

	public void set_Capacity(int value) { }

	public virtual void set_Position(long value) { }

	public virtual void SetLength(long value) { }

	public Byte[] ToArray() { }

	public Byte[] ToArray(bool canBeLarger, LoggingContext context) { }

	public BufferSegment ToBufferSegment() { }

	public virtual void Write(Byte[] buffer, int offset, int count) { }

	public virtual void WriteByte(byte value) { }

	public void WriteTo(Stream stream) { }

}

