namespace Best.HTTP.Shared.Streams;

public sealed class WriteOnlyBufferedStream : Stream
{
	private int _position; //Field offset: 0x28
	private Byte[] buffer; //Field offset: 0x30
	private int _bufferSize; //Field offset: 0x38
	private Stream stream; //Field offset: 0x40
	private LoggingContext _context; //Field offset: 0x48

	public virtual bool CanRead
	{
		 get { } //Length: 3
	}

	public virtual bool CanSeek
	{
		 get { } //Length: 3
	}

	public virtual bool CanWrite
	{
		 get { } //Length: 3
	}

	public virtual long Length
	{
		 get { } //Length: 27
	}

	public virtual long Position
	{
		 get { } //Length: 5
		 set { } //Length: 78
	}

	public WriteOnlyBufferedStream(Stream stream, int bufferSize, LoggingContext context) { }

	protected virtual void Dispose(bool disposing) { }

	public virtual void Flush() { }

	public virtual bool get_CanRead() { }

	public virtual bool get_CanSeek() { }

	public virtual bool get_CanWrite() { }

	public virtual long get_Length() { }

	public virtual long get_Position() { }

	public virtual int Read(Byte[] buffer, int offset, int count) { }

	public virtual long Seek(long offset, SeekOrigin origin) { }

	public virtual void set_Position(long value) { }

	public virtual void SetLength(long value) { }

	public virtual void Write(Byte[] bufferFrom, int offset, int count) { }

}

