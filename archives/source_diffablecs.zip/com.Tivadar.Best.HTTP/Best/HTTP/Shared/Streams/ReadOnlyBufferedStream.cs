namespace Best.HTTP.Shared.Streams;

public sealed class ReadOnlyBufferedStream : Stream
{
	public const int READBUFFER = 8192; //Field offset: 0x0
	private Stream stream; //Field offset: 0x28
	private Byte[] buf; //Field offset: 0x30
	private int available; //Field offset: 0x38
	private int pos; //Field offset: 0x3C

	public virtual bool CanRead
	{
		 get { } //Length: 3
	}

	public virtual bool CanSeek
	{
		 get { } //Length: 62
	}

	public virtual bool CanWrite
	{
		 get { } //Length: 62
	}

	public virtual long Length
	{
		 get { } //Length: 62
	}

	public virtual long Position
	{
		 get { } //Length: 62
		 set { } //Length: 62
	}

	public ReadOnlyBufferedStream(Stream nstream) { }

	public ReadOnlyBufferedStream(Stream nstream, int bufferSize) { }

	protected virtual void Dispose(bool disposing) { }

	public virtual void Flush() { }

	public virtual bool get_CanRead() { }

	public virtual bool get_CanSeek() { }

	public virtual bool get_CanWrite() { }

	public virtual long get_Length() { }

	public virtual long get_Position() { }

	public virtual int Read(Byte[] buffer, int offset, int size) { }

	public virtual int ReadByte() { }

	public virtual long Seek(long offset, SeekOrigin origin) { }

	public virtual void set_Position(long value) { }

	public virtual void SetLength(long value) { }

	public virtual void Write(Byte[] buffer, int offset, int count) { }

}

