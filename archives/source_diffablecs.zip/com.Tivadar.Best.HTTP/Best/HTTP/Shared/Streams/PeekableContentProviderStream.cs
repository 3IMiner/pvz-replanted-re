namespace Best.HTTP.Shared.Streams;

public abstract class PeekableContentProviderStream : PeekableStream, IPeekableContentProvider
{
	[CompilerGenerated]
	private IContentConsumer <Consumer>k__BackingField; //Field offset: 0x40

	public private override IContentConsumer Consumer
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 13
	}

	public override PeekableContentProviderStream Peekable
	{
		 get { } //Length: 4
	}

	protected PeekableContentProviderStream() { }

	[CompilerGenerated]
	public override IContentConsumer get_Consumer() { }

	public override PeekableContentProviderStream get_Peekable() { }

	[CompilerGenerated]
	private void set_Consumer(IContentConsumer value) { }

	public override void SetTwoWayBinding(IContentConsumer consumer) { }

	public override void SwitchIf(IContentConsumer from, IContentConsumer to) { }

	public override void Unbind() { }

	public override void UnbindIf(IContentConsumer consumer) { }

}

