namespace Best.HTTP.Shared.Streams;

public sealed class StreamList : Stream
{
	private Stream[] Streams; //Field offset: 0x28
	private int CurrentIdx; //Field offset: 0x30

	public virtual bool CanRead
	{
		 get { } //Length: 86
	}

	public virtual bool CanSeek
	{
		 get { } //Length: 3
	}

	public virtual bool CanWrite
	{
		 get { } //Length: 86
	}

	public virtual long Length
	{
		 get { } //Length: 171
	}

	public virtual long Position
	{
		 get { } //Length: 78
		 set { } //Length: 78
	}

	public StreamList(Stream[] streams) { }

	public void AppendStream(Stream stream) { }

	protected virtual void Dispose(bool disposing) { }

	public virtual void Flush() { }

	public virtual bool get_CanRead() { }

	public virtual bool get_CanSeek() { }

	public virtual bool get_CanWrite() { }

	public virtual long get_Length() { }

	public virtual long get_Position() { }

	public virtual int Read(Byte[] buffer, int offset, int count) { }

	public virtual long Seek(long offset, SeekOrigin origin) { }

	public virtual void set_Position(long value) { }

	public virtual void SetLength(long value) { }

	public virtual void Write(Byte[] buffer, int offset, int count) { }

	public void Write(string str) { }

}

