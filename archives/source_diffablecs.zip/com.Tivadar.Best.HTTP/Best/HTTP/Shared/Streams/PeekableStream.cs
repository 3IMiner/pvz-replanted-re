namespace Best.HTTP.Shared.Streams;

public abstract class PeekableStream : BufferSegmentStream
{

	protected PeekableStream() { }

	public abstract void BeginPeek() { }

	public abstract int PeekByte() { }

}

