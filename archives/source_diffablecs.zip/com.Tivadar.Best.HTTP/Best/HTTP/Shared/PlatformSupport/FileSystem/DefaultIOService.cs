namespace Best.HTTP.Shared.PlatformSupport.FileSystem;

public sealed class DefaultIOService : IIOService
{

	public DefaultIOService() { }

	public override Stream CreateFileStream(string path, FileStreamModes mode) { }

	public override void DirectoryCreate(string path) { }

	public override void DirectoryDelete(string path) { }

	public override bool DirectoryExists(string path) { }

	public override void FileDelete(string path) { }

	public override bool FileExists(string path) { }

	public override String[] GetFiles(string path) { }

}

