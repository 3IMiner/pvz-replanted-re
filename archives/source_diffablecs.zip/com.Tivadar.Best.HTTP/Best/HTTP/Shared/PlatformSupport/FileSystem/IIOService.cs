namespace Best.HTTP.Shared.PlatformSupport.FileSystem;

public interface IIOService
{

	public Stream CreateFileStream(string path, FileStreamModes mode) { }

	public void DirectoryCreate(string path) { }

	public void DirectoryDelete(string path) { }

	public bool DirectoryExists(string path) { }

	public void FileDelete(string path) { }

	public bool FileExists(string path) { }

	public String[] GetFiles(string path) { }

}

