namespace Best.HTTP.Shared.PlatformSupport.Threading;

public struct ReadLock : IDisposable
{
	private ReaderWriterLockSlim rwLock; //Field offset: 0x0
	private bool locked; //Field offset: 0x8

	public ReadLock(ReaderWriterLockSlim rwLock) { }

	public override void Dispose() { }

}

