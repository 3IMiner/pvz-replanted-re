namespace Best.HTTP.Shared.PlatformSupport.Threading;

[Il2CppEagerStaticClassConstruction]
public static class ThreadedRunner
{
	[CompilerGenerated]
	private sealed class <>c__DisplayClass10_0
	{
		public Action<T1, T2, T3, T4> job; //Field offset: 0x0
		public T1 param1; //Field offset: 0x0
		public T2 param2; //Field offset: 0x0
		public T3 param3; //Field offset: 0x0
		public T4 param4; //Field offset: 0x0

		public <>c__DisplayClass10_0`4() { }

		internal void <RunShortLiving>b__0(object _) { }

	}

	[CompilerGenerated]
	private sealed class <>c__DisplayClass11_0
	{
		public Action job; //Field offset: 0x10

		public <>c__DisplayClass11_0() { }

		internal void <RunShortLiving>b__0(object param) { }

	}

	[CompilerGenerated]
	private sealed class <>c__DisplayClass12_0
	{
		public Action job; //Field offset: 0x10

		public <>c__DisplayClass12_0() { }

		internal void <RunLongLiving>b__0(object param) { }

	}

	[CompilerGenerated]
	private sealed class <>c__DisplayClass7_0
	{
		public Action<T> job; //Field offset: 0x0
		public T param; //Field offset: 0x0

		public <>c__DisplayClass7_0`1() { }

		internal void <RunShortLiving>b__0(object _) { }

	}

	[CompilerGenerated]
	private sealed class <>c__DisplayClass8_0
	{
		public Action<T1, T2> job; //Field offset: 0x0
		public T1 param1; //Field offset: 0x0
		public T2 param2; //Field offset: 0x0

		public <>c__DisplayClass8_0`2() { }

		internal void <RunShortLiving>b__0(object _) { }

	}

	[CompilerGenerated]
	private sealed class <>c__DisplayClass9_0
	{
		public Action<T1, T2, T3> job; //Field offset: 0x0
		public T1 param1; //Field offset: 0x0
		public T2 param2; //Field offset: 0x0
		public T3 param3; //Field offset: 0x0

		public <>c__DisplayClass9_0`3() { }

		internal void <RunShortLiving>b__0(object _) { }

	}

	private struct IncDecLongLiving : IDisposable
	{

		public IncDecLongLiving(bool dummy) { }

		public override void Dispose() { }

	}

	private struct IncDecShortLiving : IDisposable
	{

		public IncDecShortLiving(bool dummy) { }

		public override void Dispose() { }

	}

	private static int _shortLivingThreads; //Field offset: 0x0
	private static int _LongLivingThreads; //Field offset: 0x4

	public static int LongLivingThreads
	{
		 get { } //Length: 54
	}

	public static int ShortLivingThreads
	{
		 get { } //Length: 53
	}

	public static int get_LongLivingThreads() { }

	public static int get_ShortLivingThreads() { }

	public static void RunLongLiving(Action job) { }

	public static void RunShortLiving(Action<T> job, T param) { }

	public static void RunShortLiving(Action<T1, T2> job, T1 param1, T2 param2) { }

	public static void RunShortLiving(Action<T1, T2, T3> job, T1 param1, T2 param2, T3 param3) { }

	public static void RunShortLiving(Action<T1, T2, T3, T4> job, T1 param1, T2 param2, T3 param3, T4 param4) { }

	public static void RunShortLiving(Action job) { }

	public static void SetThreadName(string name) { }

}

