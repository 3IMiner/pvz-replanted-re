namespace Best.HTTP.Shared.PlatformSupport.Text;

[Il2CppEagerStaticClassConstruction]
public static class StringBuilderPool
{
	private struct BuilderShelf
	{
		public StringBuilder builder; //Field offset: 0x0
		public DateTime released; //Field offset: 0x8

		public BuilderShelf(StringBuilder sb) { }

	}

	private static bool _isEnabled; //Field offset: 0x0
	public static TimeSpan RemoveOlderThan; //Field offset: 0x8
	public static TimeSpan RunMaintenanceEvery; //Field offset: 0x10
	private static DateTime lastMaintenance; //Field offset: 0x18
	private static readonly ReaderWriterLockSlim rwLock; //Field offset: 0x20
	private static List<BuilderShelf> pooledBuilders; //Field offset: 0x28

	public static bool IsEnabled
	{
		 get { } //Length: 89
		 set { } //Length: 144
	}

	private static StringBuilderPool() { }

	public static void Clear() { }

	public static StringBuilder Get(int lengthHint) { }

	public static bool get_IsEnabled() { }

	internal static void Maintain() { }

	public static void Release(StringBuilder builder) { }

	public static string ReleaseAndGrab(StringBuilder builder) { }

	public static void set_IsEnabled(bool value) { }

}

