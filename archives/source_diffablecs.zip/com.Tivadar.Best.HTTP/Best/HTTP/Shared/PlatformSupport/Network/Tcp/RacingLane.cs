namespace Best.HTTP.Shared.PlatformSupport.Network.Tcp;

internal sealed class RacingLane
{
	public Race Race; //Field offset: 0x10
	public int AddressIndex; //Field offset: 0x18
	public int LaneIndex; //Field offset: 0x1C
	public Socket Socket; //Field offset: 0x20

	public RacingLane() { }

	public virtual string ToString() { }

}

