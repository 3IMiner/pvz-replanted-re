namespace Best.HTTP.Shared.PlatformSupport.Network.Tcp;

[Il2CppEagerStaticClassConstruction]
public static class TCPRingmaster
{

	private static bool CheckForCanceled(DateTime now, object context) { }

	private static void OnLaneFinished(IAsyncResult ar) { }

	private static void OnSocketDisconnect(IAsyncResult ar) { }

	public static void ShuffleAddresses(DNSIPAddress[] addresses) { }

	public static void StartCompetion(TCPRaceParameters parameters) { }

}

