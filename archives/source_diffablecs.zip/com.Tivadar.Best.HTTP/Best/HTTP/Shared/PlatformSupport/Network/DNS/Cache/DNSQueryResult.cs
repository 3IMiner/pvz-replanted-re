namespace Best.HTTP.Shared.PlatformSupport.Network.DNS.Cache;

[IsReadOnly]
public struct DNSQueryResult
{
	public readonly string HostName; //Field offset: 0x0
	public readonly DNSIPAddress[] Addresses; //Field offset: 0x8
	public readonly Exception Error; //Field offset: 0x10

	internal DNSQueryResult(string hostName, DNSIPAddress[] addresses, Exception error) { }

	public virtual string ToString() { }

}

