namespace Best.HTTP.Shared.PlatformSupport.Network.Tcp.Streams;

public sealed class NonblockingUnderlyingStream : PeekableContentProviderStream
{
	private Stream _stream; //Field offset: 0x48
	private int _receiving; //Field offset: 0x50
	private uint _maxBufferSize; //Field offset: 0x54
	private LoggingContext _context; //Field offset: 0x58
	private object _locker; //Field offset: 0x60
	private int peek_listIdx; //Field offset: 0x68
	private int peek_pos; //Field offset: 0x6C

	public NonblockingUnderlyingStream(Stream stream, uint maxBufferSize, LoggingContext context) { }

	public virtual void BeginPeek() { }

	public void BeginReceive() { }

	protected virtual void Dispose(bool disposing) { }

	private void OnReceived(IAsyncResult ar) { }

	public virtual int PeekByte() { }

	public virtual int Read(Byte[] buffer, int offset, int count) { }

}

