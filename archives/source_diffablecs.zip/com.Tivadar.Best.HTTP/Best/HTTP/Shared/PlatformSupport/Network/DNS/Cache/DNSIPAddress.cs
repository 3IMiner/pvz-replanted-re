namespace Best.HTTP.Shared.PlatformSupport.Network.DNS.Cache;

public sealed class DNSIPAddress
{
	[CompilerGenerated]
	private IPAddress <IPAddress>k__BackingField; //Field offset: 0x10
	[CompilerGenerated]
	private bool <IsWorkedLastTime>k__BackingField; //Field offset: 0x18

	public private IPAddress IPAddress
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 13
	}

	public internal bool IsWorkedLastTime
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		internal set { } //Length: 4
	}

	internal DNSIPAddress(IPAddress iPAddress) { }

	[CompilerGenerated]
	public IPAddress get_IPAddress() { }

	[CompilerGenerated]
	public bool get_IsWorkedLastTime() { }

	[CompilerGenerated]
	private void set_IPAddress(IPAddress value) { }

	[CompilerGenerated]
	internal void set_IsWorkedLastTime(bool value) { }

	public virtual string ToString() { }

}

