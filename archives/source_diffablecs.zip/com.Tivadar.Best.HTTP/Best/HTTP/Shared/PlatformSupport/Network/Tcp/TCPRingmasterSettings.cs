namespace Best.HTTP.Shared.PlatformSupport.Network.Tcp;

public sealed class TCPRingmasterSettings
{
	public int MaxSimultaneousRacers; //Field offset: 0x10
	public bool ShuffleAddresses; //Field offset: 0x14
	public Action<TCPRaceParameters> CustomAddressShuffleAlgorithm; //Field offset: 0x18
	public TimeSpan CancellationCheckingGranularity; //Field offset: 0x20

	public TCPRingmasterSettings() { }

	public virtual string ToString() { }

}

