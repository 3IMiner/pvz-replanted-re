namespace Best.HTTP.Shared.PlatformSupport.Network.Tcp;

public interface IContentConsumer
{

	public PeekableContentProviderStream ContentProvider
	{
		 get { } //Length: 0
	}

	public PeekableContentProviderStream get_ContentProvider() { }

	public void OnConnectionClosed() { }

	public void OnContent() { }

	public void OnError(Exception ex) { }

	public void SetBinding(PeekableContentProviderStream contentProvider) { }

	public void UnsetBinding() { }

}

