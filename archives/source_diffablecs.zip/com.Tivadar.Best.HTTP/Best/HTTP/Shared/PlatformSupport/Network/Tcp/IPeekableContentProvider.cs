namespace Best.HTTP.Shared.PlatformSupport.Network.Tcp;

public interface IPeekableContentProvider
{

	public IContentConsumer Consumer
	{
		 get { } //Length: 0
	}

	public PeekableContentProviderStream Peekable
	{
		 get { } //Length: 0
	}

	public IContentConsumer get_Consumer() { }

	public PeekableContentProviderStream get_Peekable() { }

	public void SetTwoWayBinding(IContentConsumer consumer) { }

	public void SwitchIf(IContentConsumer from, IContentConsumer to) { }

	public void Unbind() { }

	public void UnbindIf(IContentConsumer consumer) { }

}

