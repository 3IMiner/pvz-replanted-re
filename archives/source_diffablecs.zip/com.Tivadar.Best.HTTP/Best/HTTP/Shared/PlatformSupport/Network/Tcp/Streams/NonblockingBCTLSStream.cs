namespace Best.HTTP.Shared.PlatformSupport.Network.Tcp.Streams;

public sealed class NonblockingBCTLSStream : PeekableContentProviderStream, ITCPStreamerContentConsumer
{
	public Action<NonblockingBCTLSStream, TCPStreamer, AbstractTls13Client, Exception> OnNegotiated; //Field offset: 0x48
	private long _maxBufferSize; //Field offset: 0x50
	private TlsClientProtocol _tlsClientProtocol; //Field offset: 0x58
	private AbstractTls13Client _tlsClient; //Field offset: 0x60
	private object locker; //Field offset: 0x68
	private TCPStreamer _streamer; //Field offset: 0x70
	private uint _sendBufferSize; //Field offset: 0x78
	private bool _disposeStreamer; //Field offset: 0x7C
	private int peek_listIdx; //Field offset: 0x80
	private int peek_pos; //Field offset: 0x84
	private bool _disposed; //Field offset: 0x88

	public override long MaxBufferSize
	{
		 get { } //Length: 24
		 set { } //Length: 12
	}

	public NonblockingBCTLSStream(TCPStreamer streamer, TlsClientProtocol tlsClientProtocol, AbstractTls13Client tlsClient, bool disposeStreamer, uint maxBufferSize) { }

	public virtual void BeginPeek() { }

	private bool CallOnNegotiated(Exception error) { }

	protected virtual void Dispose(bool disposing) { }

	public override long get_MaxBufferSize() { }

	public override void OnConnectionClosed(TCPStreamer streamer) { }

	public override void OnContent(TCPStreamer streamer) { }

	public override void OnError(TCPStreamer streamer, Exception ex) { }

	public virtual int PeekByte() { }

	private void PullContentFromStreamer() { }

	public virtual int Read(Byte[] buffer, int offset, int count) { }

	public override void set_MaxBufferSize(long value) { }

	public virtual void Write(Byte[] buffer, int offset, int count) { }

	public virtual void Write(BufferSegment bufferSegment) { }

}

