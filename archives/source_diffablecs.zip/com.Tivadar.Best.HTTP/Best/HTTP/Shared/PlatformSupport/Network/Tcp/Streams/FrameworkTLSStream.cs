namespace Best.HTTP.Shared.PlatformSupport.Network.Tcp.Streams;

public sealed class FrameworkTLSStream : PeekableContentProviderStream, ITCPStreamerContentConsumer
{
	[CompilerGenerated]
	private sealed class <>c__DisplayClass24_0
	{
		public FrameworkTLSStream <>4__this; //Field offset: 0x10
		public Byte[] buffer; //Field offset: 0x18

		public <>c__DisplayClass24_0() { }

		internal void <BeginRead>b__0(Task<Int32> ti) { }

	}

	private static bool loggedWarning; //Field offset: 0x0
	public Action<FrameworkTLSStream, TCPStreamer, String, Exception> OnNegotiated; //Field offset: 0x48
	private long _maxBufferSize; //Field offset: 0x50
	private string _targetHost; //Field offset: 0x58
	private TCPStreamer _streamer; //Field offset: 0x60
	private FrameworkTLSByteForwarder _forwarder; //Field offset: 0x68
	private SslStream _sslStream; //Field offset: 0x70
	private LoggingContext _context; //Field offset: 0x78
	private HostSettings _hostSettings; //Field offset: 0x80
	private int peek_listIdx; //Field offset: 0x88
	private int peek_pos; //Field offset: 0x8C
	private object locker; //Field offset: 0x90
	private int _reading; //Field offset: 0x98

	public override long MaxBufferSize
	{
		 get { } //Length: 24
		 set { } //Length: 12
	}

	public FrameworkTLSStream(TCPStreamer streamer, string targetHost, HostSettings hostSettings) { }

	[CompilerGenerated]
	[DebuggerHidden]
	private void <>n__0(BufferSegment bufferSegment) { }

	public virtual void BeginPeek() { }

	private void BeginRead() { }

	private bool CallOnNegotiated(string alpn, Exception error) { }

	protected virtual void Dispose(bool disposing) { }

	public virtual void Flush() { }

	public override long get_MaxBufferSize() { }

	private void OnAuthenticatedAsClient(IAsyncResult ar) { }

	public override void OnConnectionClosed(TCPStreamer streamer) { }

	public override void OnContent(TCPStreamer streamer) { }

	public override void OnError(TCPStreamer streamer, Exception ex) { }

	private void OnRead(IAsyncResult ar) { }

	private X509Certificate OnUserCertificationSelection(object sender, string targetHost, X509CertificateCollection localCertificates, X509Certificate remoteCertificate, String[] acceptableIssuers) { }

	private bool OnUserCertificationValidation(object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { }

	public virtual int PeekByte() { }

	public virtual int Read(Byte[] buffer, int offset, int count) { }

	public override void set_MaxBufferSize(long value) { }

	public virtual void Write(Byte[] buffer, int offset, int count) { }

	public virtual void Write(BufferSegment bufferSegment) { }

}

