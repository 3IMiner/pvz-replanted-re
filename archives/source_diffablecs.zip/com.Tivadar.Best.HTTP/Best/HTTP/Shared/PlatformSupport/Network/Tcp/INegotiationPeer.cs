namespace Best.HTTP.Shared.PlatformSupport.Network.Tcp;

public interface INegotiationPeer
{

	public void EvaluateProxyNegotiationFailure(Negotiator negotiator, Exception error, bool resendForAuthentication) { }

	public List<String> GetSupportedProtocolNames(Negotiator negotiator) { }

	public bool MustStopAdvancingToNextStep(Negotiator negotiator, NegotiationSteps finishedStep, NegotiationSteps nextStep, Exception error) { }

	public void OnNegotiationFailed(Negotiator negotiator, Exception error) { }

	public void OnNegotiationFinished(Negotiator negotiator, PeekableContentProviderStream stream, TCPStreamer streamer, string negotiatedProtocol) { }

}

