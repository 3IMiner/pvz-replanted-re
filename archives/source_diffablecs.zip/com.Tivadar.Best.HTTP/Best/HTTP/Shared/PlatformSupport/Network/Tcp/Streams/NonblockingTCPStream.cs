namespace Best.HTTP.Shared.PlatformSupport.Network.Tcp.Streams;

public sealed class NonblockingTCPStream : PeekableContentProviderStream, ITCPStreamerContentConsumer
{
	private long _maxBufferSize; //Field offset: 0x48
	private TCPStreamer _streamer; //Field offset: 0x50
	private bool _disposeStreamer; //Field offset: 0x58
	private int peek_listIdx; //Field offset: 0x5C
	private int peek_pos; //Field offset: 0x60
	private object _locker; //Field offset: 0x68

	public override long MaxBufferSize
	{
		 get { } //Length: 24
		 set { } //Length: 12
	}

	public NonblockingTCPStream(TCPStreamer streamer, bool disposeStreamer, uint maxBufferSize) { }

	public virtual void BeginPeek() { }

	private void DequeueFromStreamer() { }

	protected virtual void Dispose(bool disposing) { }

	public override long get_MaxBufferSize() { }

	public override void OnConnectionClosed(TCPStreamer streamer) { }

	public override void OnContent(TCPStreamer streamer) { }

	public override void OnError(TCPStreamer streamer, Exception ex) { }

	public virtual int PeekByte() { }

	public virtual int Read(Byte[] buffer, int offset, int count) { }

	public override void set_MaxBufferSize(long value) { }

	public virtual void Write(Byte[] buffer, int offset, int count) { }

	public virtual void Write(BufferSegment buffer) { }

}

