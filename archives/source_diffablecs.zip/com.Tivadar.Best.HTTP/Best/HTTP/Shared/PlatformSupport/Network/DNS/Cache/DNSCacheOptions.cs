namespace Best.HTTP.Shared.PlatformSupport.Network.DNS.Cache;

public sealed class DNSCacheOptions
{
	public TimeSpan RefreshAfter; //Field offset: 0x10
	public TimeSpan RemoveAfter; //Field offset: 0x18
	public TimeSpan CancellationCheckGranularity; //Field offset: 0x20
	public TimeSpan MaintenanceFrequency; //Field offset: 0x28

	public DNSCacheOptions() { }

}

