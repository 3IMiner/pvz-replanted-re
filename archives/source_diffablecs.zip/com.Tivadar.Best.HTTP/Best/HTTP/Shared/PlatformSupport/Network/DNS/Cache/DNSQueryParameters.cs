namespace Best.HTTP.Shared.PlatformSupport.Network.DNS.Cache;

public sealed class DNSQueryParameters
{
	[CompilerGenerated]
	private Hash128 <Key>k__BackingField; //Field offset: 0x10
	[CompilerGenerated]
	private Uri <Address>k__BackingField; //Field offset: 0x20
	public CancellationToken Token; //Field offset: 0x28
	public LoggingContext Context; //Field offset: 0x30
	public Action<DNSQueryParameters, DNSQueryResult> Callback; //Field offset: 0x38
	public object Tag; //Field offset: 0x40

	public private Uri Address
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 13
	}

	public string Hostname
	{
		 get { } //Length: 29
	}

	public bool IsPrefetch
	{
		 get { } //Length: 9
	}

	public private Hash128 Key
	{
		[CompilerGenerated]
		 get { } //Length: 11
		[CompilerGenerated]
		private set { } //Length: 8
	}

	public DNSQueryParameters(Uri address) { }

	[CompilerGenerated]
	public Uri get_Address() { }

	public string get_Hostname() { }

	public bool get_IsPrefetch() { }

	[CompilerGenerated]
	public Hash128 get_Key() { }

	[CompilerGenerated]
	private void set_Address(Uri value) { }

	[CompilerGenerated]
	private void set_Key(Hash128 value) { }

	public virtual string ToString() { }

}

