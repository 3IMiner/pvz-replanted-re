namespace Best.HTTP.Shared.PlatformSupport.Network.DNS.Cache;

[Il2CppEagerStaticClassConstruction]
public static class DNSCache
{
	[CompilerGenerated]
	private sealed class <>c
	{
		public static readonly <>c <>9; //Field offset: 0x0
		public static Action<DNSQueryParameters, DNSQueryResult> <>9__6_0; //Field offset: 0x8

		private static <>c() { }

		public <>c() { }

		internal void <Query>b__6_0(DNSQueryParameters par, DNSQueryResult res) { }

	}

	[CompilerGenerated]
	private sealed class <>c__DisplayClass7_0
	{
		public DNSQueryParameters parameters; //Field offset: 0x10
		public IPAddress[] addresses; //Field offset: 0x18

		public <>c__DisplayClass7_0() { }

		internal DNSCacheEntry <OnGetHostAddresses>g__AddCacheEntry|0(Hash128 key) { }

		internal DNSCacheEntry <OnGetHostAddresses>g__UpdateCacheEntry|1(Hash128 key, DNSCacheEntry oldEntry) { }

	}

	public static DNSCacheOptions Options; //Field offset: 0x0
	private static ConcurrentDictionary<Hash128, DNSCacheEntry> _cache; //Field offset: 0x8
	private static int _isMaintenanceScheduled; //Field offset: 0x10

	private static DNSCache() { }

	private static bool CheckForCanceled(DateTime now, object context) { }

	public static void Clear() { }

	private static bool Maintenance(DateTime now, object context) { }

	private static void OnGetHostAddresses(IAsyncResult ar) { }

	public static void Prefetch(string hostName) { }

	public static void Query(DNSQueryParameters parameters) { }

	public static void ReportAsNonWorking(string hostName, IPAddress address, LoggingContext context) { }

}

