namespace Best.HTTP.Shared.PlatformSupport.Network.Tcp;

public sealed class TCPRaceResult
{
	public Socket WinningSocket; //Field offset: 0x10
	public Exception Error; //Field offset: 0x18

	public TCPRaceResult(Socket socket, Exception ex) { }

	public virtual string ToString() { }

}

