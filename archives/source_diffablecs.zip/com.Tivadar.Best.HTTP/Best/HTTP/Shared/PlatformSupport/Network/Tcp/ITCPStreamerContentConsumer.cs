namespace Best.HTTP.Shared.PlatformSupport.Network.Tcp;

public interface ITCPStreamerContentConsumer
{

	public long MaxBufferSize
	{
		 get { } //Length: 0
		 set { } //Length: 0
	}

	public long get_MaxBufferSize() { }

	public void OnConnectionClosed(TCPStreamer streamer) { }

	public void OnContent(TCPStreamer streamer) { }

	public void OnError(TCPStreamer streamer, Exception ex) { }

	public void set_MaxBufferSize(long value) { }

	public void Write(Byte[] buffer, int offset, int count) { }

	public void Write(BufferSegment buffer) { }

}

