namespace Best.HTTP.Shared.PlatformSupport.Network.Tcp;

internal sealed class WriteState
{
	public Byte[] _writeBuffer; //Field offset: 0x10
	public int _writeInProgress; //Field offset: 0x18
	public ConcurrentQueue<BufferSegment> _segmentsToWrite; //Field offset: 0x20
	public long bufferedLength; //Field offset: 0x28
	public AutoResetEvent blockEvent; //Field offset: 0x30

	public WriteState() { }

}

