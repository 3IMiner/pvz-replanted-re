namespace Best.HTTP.Shared.PlatformSupport.Network.Tcp;

public class Negotiator
{
	private INegotiationPeer _peer; //Field offset: 0x10
	private NegotiationParameters _parameters; //Field offset: 0x18
	private TCPStreamer _streamer; //Field offset: 0x20
	private PeekableContentProviderStream _stream; //Field offset: 0x28

	public NegotiationParameters Parameters
	{
		 get { } //Length: 5
	}

	public INegotiationPeer Peer
	{
		 get { } //Length: 5
	}

	public PeekableContentProviderStream Stream
	{
		 get { } //Length: 5
	}

	public TCPStreamer Streamer
	{
		 get { } //Length: 5
	}

	public Negotiator(INegotiationPeer peer, NegotiationParameters parameters) { }

	public NegotiationParameters get_Parameters() { }

	public INegotiationPeer get_Peer() { }

	public PeekableContentProviderStream get_Stream() { }

	public TCPStreamer get_Streamer() { }

	private void NegotiateTLS() { }

	private void OnBC_TLSNegotiated(NonblockingBCTLSStream stream, TCPStreamer streamer, AbstractTls13Client tlsClient, Exception error) { }

	public void OnCancellationRequested() { }

	private void OnDNSCacheQueryFinished(DNSQueryParameters dnsParameters, DNSQueryResult result) { }

	private void OnFramework_TLSNegotiated(FrameworkTLSStream stream, TCPStreamer streamer, string alpn, Exception error) { }

	private void OnProxyNegotiated(ProxyConnectParameters parameters) { }

	private void OnProxyNegotiationFailed(ProxyConnectParameters parameters, Exception error, bool resendForAuthentication) { }

	private void OnTCPRaceFinished(TCPRaceParameters parameters, TCPRaceResult raceResult) { }

	private void SetupSocket(Socket socket, HostSettings hostSettings) { }

	public void Start() { }

}

