namespace Best.HTTP.Shared.PlatformSupport.Network.Tcp;

public sealed class NegotiationParameters
{
	public Proxy proxy; //Field offset: 0x10
	public bool createProxyTunel; //Field offset: 0x18
	public Uri targetUri; //Field offset: 0x20
	public bool negotiateTLS; //Field offset: 0x28
	public CancellationToken token; //Field offset: 0x30
	public HostSettings hostSettings; //Field offset: 0x38
	public LoggingContext context; //Field offset: 0x40

	public NegotiationParameters() { }

}

