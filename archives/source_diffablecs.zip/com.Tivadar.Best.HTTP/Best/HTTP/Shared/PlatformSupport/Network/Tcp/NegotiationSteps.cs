namespace Best.HTTP.Shared.PlatformSupport.Network.Tcp;

public enum NegotiationSteps
{
	Start = 0,
	DNSQuery = 1,
	TCPRace = 2,
	Proxy = 3,
	TLSNegotiation = 4,
	Finish = 5,
}

