namespace Best.HTTP.Shared.PlatformSupport.Network.Tcp;

internal sealed class ReadState
{
	public int minReceiveBufferSize; //Field offset: 0x10
	public Byte[] receiveBuffer; //Field offset: 0x18
	public int isReceiving; //Field offset: 0x20
	public long totalReceived; //Field offset: 0x28
	public long bufferedLength; //Field offset: 0x30
	public ConcurrentQueue<BufferSegment> bufferedSegments; //Field offset: 0x38

	public ReadState() { }

}

