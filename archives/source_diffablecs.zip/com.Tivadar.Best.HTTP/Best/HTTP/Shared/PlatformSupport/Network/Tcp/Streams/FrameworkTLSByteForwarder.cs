namespace Best.HTTP.Shared.PlatformSupport.Network.Tcp.Streams;

public sealed class FrameworkTLSByteForwarder : Stream, ITCPStreamerContentConsumer
{
	private long _length; //Field offset: 0x28
	private long _maxBufferSize; //Field offset: 0x30
	private TCPStreamer _streamer; //Field offset: 0x38
	private LoggingContext _context; //Field offset: 0x40
	private ITCPStreamerContentConsumer _contentConsumer; //Field offset: 0x48
	private Queue<BufferSegment> _segmentsToReadFrom; //Field offset: 0x50
	private AutoResetEvent _are; //Field offset: 0x58
	private ReaderWriterLockSlim _rws; //Field offset: 0x60
	private BufferSegment _currentReadSegment; //Field offset: 0x68
	private int _pullContentInProgress; //Field offset: 0x78

	public virtual bool CanRead
	{
		 get { } //Length: 3
	}

	public virtual bool CanSeek
	{
		 get { } //Length: 3
	}

	public virtual bool CanWrite
	{
		 get { } //Length: 3
	}

	public virtual long Length
	{
		 get { } //Length: 5
	}

	public override long MaxBufferSize
	{
		 get { } //Length: 24
		 set { } //Length: 12
	}

	public virtual long Position
	{
		 get { } //Length: 62
		 set { } //Length: 62
	}

	public FrameworkTLSByteForwarder(TCPStreamer streamer, ITCPStreamerContentConsumer contentConsumer, long maxBufferSize, LoggingContext context) { }

	protected virtual void Dispose(bool disposing) { }

	public virtual void Flush() { }

	public virtual bool get_CanRead() { }

	public virtual bool get_CanSeek() { }

	public virtual bool get_CanWrite() { }

	public virtual long get_Length() { }

	public override long get_MaxBufferSize() { }

	public virtual long get_Position() { }

	public override void OnConnectionClosed(TCPStreamer streamer) { }

	public override void OnContent(TCPStreamer streamer) { }

	public override void OnError(TCPStreamer streamer, Exception ex) { }

	private void PullContentFromStreamer() { }

	public virtual int Read(Byte[] buffer, int offset, int count) { }

	public virtual long Seek(long offset, SeekOrigin origin) { }

	public override void set_MaxBufferSize(long value) { }

	public virtual void set_Position(long value) { }

	public virtual void SetLength(long value) { }

	public virtual void Write(Byte[] buffer, int offset, int count) { }

	public override void Write(BufferSegment buffer) { }

}

