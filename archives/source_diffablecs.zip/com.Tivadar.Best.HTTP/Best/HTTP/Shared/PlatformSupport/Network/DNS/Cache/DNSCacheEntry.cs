namespace Best.HTTP.Shared.PlatformSupport.Network.DNS.Cache;

internal class DNSCacheEntry
{
	[CompilerGenerated]
	private sealed class <>c__DisplayClass15_0
	{
		public IPAddress nonWorking; //Field offset: 0x10

		public <>c__DisplayClass15_0() { }

		internal bool <ReportNonWorking>b__0(DNSIPAddress adr) { }

	}

	public readonly Hash128 Key; //Field offset: 0x10
	public readonly string Host; //Field offset: 0x20
	public readonly DateTime ResolvedAt; //Field offset: 0x28
	private long _lastUsedTicks; //Field offset: 0x30
	private readonly List<DNSIPAddress> _resolvedAddresses; //Field offset: 0x38
	private int _isRefreshing; //Field offset: 0x40

	public DateTime LastUsed
	{
		 get { } //Length: 40
	}

	public DNSCacheEntry(Hash128 key, string host, List<DNSIPAddress> resolvedAddresses) { }

	private DNSCacheEntry(Hash128 key, string host, long lastUsedTicks, List<DNSIPAddress> resolvedAddresses) { }

	public DNSCacheEntry DeriveWith(List<DNSIPAddress> resolvedAddresses) { }

	public DateTime get_LastUsed() { }

	public DNSIPAddress[] GetAddresses() { }

	public bool IsReadyToRemove(DateTime now) { }

	public bool IsStalled(DateTime now) { }

	public void Refresh() { }

	public void ReportNonWorking(IPAddress nonWorking, LoggingContext context) { }

	public virtual string ToString() { }

}

