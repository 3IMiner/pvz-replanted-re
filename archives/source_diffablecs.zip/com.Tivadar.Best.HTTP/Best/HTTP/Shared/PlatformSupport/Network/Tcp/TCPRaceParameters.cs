namespace Best.HTTP.Shared.PlatformSupport.Network.Tcp;

public sealed class TCPRaceParameters
{
	public DNSIPAddress[] Addresses; //Field offset: 0x10
	public string Hostname; //Field offset: 0x18
	public int Port; //Field offset: 0x20
	public CancellationToken Token; //Field offset: 0x28
	public Action<TCPRaceParameters, TCPRaceResult> AnnounceWinnerCallback; //Field offset: 0x30
	public LoggingContext Context; //Field offset: 0x38
	public object Tag; //Field offset: 0x40

	public TCPRaceParameters() { }

	public virtual string ToString() { }

}

