namespace Best.HTTP.Shared.PlatformSupport.Network.Tcp;

internal sealed class Race
{
	public TCPRaceParameters Parameters; //Field offset: 0x10
	public int NextAddressIndex; //Field offset: 0x18
	public int RunningLanes; //Field offset: 0x1C

	public Race() { }

	public virtual string ToString() { }

}

