namespace Best.HTTP.Shared.PlatformSupport.Network.Tcp;

public sealed class TCPStreamer : IDisposable, IHeartbeat
{
	private ITCPStreamerContentConsumer _contentConsumer; //Field offset: 0x10
	public readonly uint MaxBufferedWriteAmount; //Field offset: 0x18
	private ReadState readState; //Field offset: 0x20
	private WriteState writeState; //Field offset: 0x28
	private Socket _socket; //Field offset: 0x30
	private LoggingContext _loggingContext; //Field offset: 0x38
	private bool _disposed; //Field offset: 0x40
	private int _closed; //Field offset: 0x44
	private int _isDisconnected; //Field offset: 0x48
	public bool _closeInitiatedByServer; //Field offset: 0x4C
	private uint MaxBufferedReadAmount; //Field offset: 0x50

	public ITCPStreamerContentConsumer ContentConsumer
	{
		 get { } //Length: 5
		 set { } //Length: 13
	}

	public LoggingContext Context
	{
		 get { } //Length: 5
	}

	public bool IsConnectionClosed
	{
		 get { } //Length: 20
	}

	public long Length
	{
		 get { } //Length: 27
	}

	public int MinReceiveBufferSize
	{
		 get { } //Length: 26
	}

	public Socket Socket
	{
		 get { } //Length: 5
	}

	public TCPStreamer(Socket socket, uint maxReadBufferSize, uint maxWriteBufferSize, LoggingContext _parentLoggingContext) { }

	public void BeginReceive() { }

	private override void Best.HTTP.Shared.Extensions.IHeartbeat.OnHeartbeatUpdate(DateTime now, TimeSpan dif) { }

	internal void Close() { }

	public BufferSegment DequeueReceived() { }

	public override void Dispose() { }

	public void EnqueueToSend(BufferSegment buffer) { }

	public ITCPStreamerContentConsumer get_ContentConsumer() { }

	public LoggingContext get_Context() { }

	public bool get_IsConnectionClosed() { }

	public long get_Length() { }

	public int get_MinReceiveBufferSize() { }

	public Socket get_Socket() { }

	private void OnDisconnected(IAsyncResult ar) { }

	private void OnReceived(IAsyncResult asyncResult) { }

	private void OnWroteToNetwork(IAsyncResult ar) { }

	private bool SendFromQueue() { }

	public void set_ContentConsumer(ITCPStreamerContentConsumer value) { }

}

