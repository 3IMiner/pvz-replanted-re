namespace Best.HTTP.Shared.PlatformSupport.Memory;

[Il2CppEagerStaticClassConstruction]
public static class BufferPool
{
	[ThreadStatic]
	private static StringBuilder stacktraceBuilder; //Field offset: 0x80000000
	public const long MIN_BUFFER_SIZE = 512; //Field offset: 0x0
	public const long MAX_BUFFER_SIZE = 33554432; //Field offset: 0x0
	public static readonly Byte[] NoData; //Field offset: 0x0
	private static bool _isEnabled; //Field offset: 0x8
	public static TimeSpan RunMaintenanceEvery; //Field offset: 0x10
	public static long MaxPoolSize; //Field offset: 0x18
	private static DateTime lastMaintenance; //Field offset: 0x20
	private static long PoolSize; //Field offset: 0x28
	private static long GetBuffers; //Field offset: 0x30
	private static long ReleaseBuffers; //Field offset: 0x38
	private static long Borrowed; //Field offset: 0x40
	private static long ArrayAllocations; //Field offset: 0x48
	private static readonly Bucket[] _buckets; //Field offset: 0x50
	private static readonly int firstIdx; //Field offset: 0x58
	private static readonly int lastIdx; //Field offset: 0x5C

	public static bool IsEnabled
	{
		 get { } //Length: 90
		 set { } //Length: 407
	}

	public static long MinBufferSize
	{
		 get { } //Length: 6
	}

	private static BufferPool() { }

	public static void Clear() { }

	public static Byte[] Get(long size, bool canBeLarger, LoggingContext context = null) { }

	public static bool get_IsEnabled() { }

	public static long get_MinBufferSize() { }

	[BurstCompile]
	private static int GetIdx(long po2) { }

	public static void GetStatistics(ref BufferPoolStats stats) { }

	public static bool IsPowerOfTwo(long x) { }

	internal static void Maintain() { }

	public static long NextPowerOf2(long x) { }

	public static string ProcessStackTrace(string stackTrace) { }

	public static void Release(Byte[] buffer) { }

	public static void ReleaseBulk(List<BufferSegment> segments) { }

	public static void ReleaseBulk(ConcurrentQueue<BufferSegment> segments) { }

	public static Byte[] Resize(ref Byte[] buffer, int newSize, bool canBeLarger, bool clear, LoggingContext context = null) { }

	public static void set_IsEnabled(bool value) { }

	private static void UpdateMinCount(ref Bucket bucket, int fastItem) { }

}

