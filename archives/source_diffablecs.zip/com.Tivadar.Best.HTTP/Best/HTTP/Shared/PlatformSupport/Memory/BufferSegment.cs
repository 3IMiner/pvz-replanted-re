namespace Best.HTTP.Shared.PlatformSupport.Memory;

[Il2CppEagerStaticClassConstruction]
[IsReadOnly]
public struct BufferSegment
{
	internal const int ToStringMaxDumpLength = 128; //Field offset: 0x0
	public static readonly BufferSegment Empty; //Field offset: 0x0
	public readonly Byte[] Data; //Field offset: 0x0
	public readonly int Offset; //Field offset: 0x8
	public readonly int Count; //Field offset: 0xC

	private static BufferSegment() { }

	public BufferSegment(Byte[] data, int offset, int count) { }

	public AutoReleaseBuffer AsAutoRelease() { }

	public Span<Byte> AsSpan() { }

	public void CopyTo(Byte[] to) { }

	public virtual bool Equals(object obj) { }

	public bool Equals(BufferSegment other) { }

	public bool Equals(AutoReleaseBuffer other) { }

	public virtual int GetHashCode() { }

	public static bool op_Equality(BufferSegment left, BufferSegment right) { }

	public static bool op_Equality(BufferSegment left, AutoReleaseBuffer right) { }

	public static Byte[] op_Implicit(BufferSegment left) { }

	public static bool op_Inequality(BufferSegment left, BufferSegment right) { }

	public static bool op_Inequality(BufferSegment left, AutoReleaseBuffer right) { }

	public BufferSegment Slice(int newOffset) { }

	public BufferSegment Slice(int offset, int count) { }

	public virtual string ToString() { }

}

