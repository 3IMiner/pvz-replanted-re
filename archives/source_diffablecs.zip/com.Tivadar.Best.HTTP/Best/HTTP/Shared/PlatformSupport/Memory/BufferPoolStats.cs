namespace Best.HTTP.Shared.PlatformSupport.Memory;

public struct BufferPoolStats
{
	public long GetBuffers; //Field offset: 0x0
	public long ReleaseBuffers; //Field offset: 0x8
	public long PoolSize; //Field offset: 0x10
	public long MaxPoolSize; //Field offset: 0x18
	public long MinBufferSize; //Field offset: 0x20
	public long MaxBufferSize; //Field offset: 0x28
	public long Borrowed; //Field offset: 0x30
	public long ArrayAllocations; //Field offset: 0x38
	public int FreeBufferCount; //Field offset: 0x40
	public List<BufferStats> FreeBufferStats; //Field offset: 0x48
	public TimeSpan NextMaintenance; //Field offset: 0x50

}

