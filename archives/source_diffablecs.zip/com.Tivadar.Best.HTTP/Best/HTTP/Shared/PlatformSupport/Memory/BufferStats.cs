namespace Best.HTTP.Shared.PlatformSupport.Memory;

public struct BufferStats
{
	public long Size; //Field offset: 0x0
	public int Count; //Field offset: 0x8

}

