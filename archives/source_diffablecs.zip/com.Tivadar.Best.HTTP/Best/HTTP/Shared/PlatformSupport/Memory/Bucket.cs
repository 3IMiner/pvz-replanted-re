namespace Best.HTTP.Shared.PlatformSupport.Memory;

internal struct Bucket
{
	public int MinCount; //Field offset: 0x0
	public Byte[] FastItem; //Field offset: 0x8
	public readonly ConcurrentStack<Byte[]> Items; //Field offset: 0x10

	public Bucket(int size) { }

}

