namespace Best.HTTP.Shared.PlatformSupport.Memory;

[Il2CppEagerStaticClassConstruction]
public struct AutoReleaseBuffer : IDisposable
{
	public static readonly AutoReleaseBuffer Empty; //Field offset: 0x0
	public Byte[] Data; //Field offset: 0x0
	public int Offset; //Field offset: 0x8
	public int Count; //Field offset: 0xC

	private static AutoReleaseBuffer() { }

	public AutoReleaseBuffer(Byte[] data, int offset, int count) { }

	public AutoReleaseBuffer(Byte[] data) { }

	public AutoReleaseBuffer(BufferSegment segment) { }

	public override void Dispose() { }

	public virtual bool Equals(object obj) { }

	public bool Equals(BufferSegment other) { }

	public bool Equals(AutoReleaseBuffer other) { }

	public virtual int GetHashCode() { }

	public static bool op_Equality(AutoReleaseBuffer left, AutoReleaseBuffer right) { }

	public static bool op_Equality(AutoReleaseBuffer left, BufferSegment right) { }

	public static Byte[] op_Implicit(AutoReleaseBuffer left) { }

	public static BufferSegment op_Implicit(AutoReleaseBuffer left) { }

	public static bool op_Inequality(AutoReleaseBuffer left, AutoReleaseBuffer right) { }

	public static bool op_Inequality(AutoReleaseBuffer left, BufferSegment right) { }

	public BufferSegment Slice(int newOffset) { }

	public BufferSegment Slice(int offset, int count) { }

	public virtual string ToString() { }

}

