namespace Best.HTTP.Shared.PlatformSupport.IL2CPP;

[AttributeUsage(6141)]
public sealed class PreserveAttribute : Attribute
{

	public PreserveAttribute() { }

}

