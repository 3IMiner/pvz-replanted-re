namespace Best.HTTP.Shared.PlatformSupport.IL2CPP;

public enum Option
{
	NullChecks = 1,
	ArrayBoundsChecks = 2,
	DivideByZeroChecks = 3,
}

