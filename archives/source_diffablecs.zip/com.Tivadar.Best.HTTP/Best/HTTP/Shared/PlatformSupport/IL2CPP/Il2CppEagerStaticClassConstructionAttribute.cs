namespace Best.HTTP.Shared.PlatformSupport.IL2CPP;

[AttributeUsage(12, Inherited = False, AllowMultiple = False)]
public class Il2CppEagerStaticClassConstructionAttribute : Attribute
{

	public Il2CppEagerStaticClassConstructionAttribute() { }

}

