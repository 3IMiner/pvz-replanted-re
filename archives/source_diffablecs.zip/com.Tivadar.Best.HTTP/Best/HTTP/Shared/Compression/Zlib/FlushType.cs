namespace Best.HTTP.Shared.Compression.Zlib;

public enum FlushType
{
	None = 0,
	Partial = 1,
	Sync = 2,
	Full = 3,
	Finish = 4,
}

