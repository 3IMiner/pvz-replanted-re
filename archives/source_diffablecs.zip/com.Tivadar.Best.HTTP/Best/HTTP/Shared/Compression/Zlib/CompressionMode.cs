namespace Best.HTTP.Shared.Compression.Zlib;

public enum CompressionMode
{
	Compress = 0,
	Decompress = 1,
}

