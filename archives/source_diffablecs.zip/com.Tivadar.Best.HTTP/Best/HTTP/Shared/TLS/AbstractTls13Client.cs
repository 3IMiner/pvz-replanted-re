namespace Best.HTTP.Shared.TLS;

public abstract class AbstractTls13Client : AbstractTlsClient, TlsAuthentication
{
	protected static readonly Int32[] DefaultCipherSuites; //Field offset: 0x0
	protected List<ServerName> _sniServerNames; //Field offset: 0x50
	protected List<ProtocolName> _protocols; //Field offset: 0x58
	[CompilerGenerated]
	private LoggingContext <Context>k__BackingField; //Field offset: 0x60

	protected private LoggingContext Context
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 13
	}

	private static AbstractTls13Client() { }

	protected AbstractTls13Client(List<ServerName> sniServerNames, List<ProtocolName> protocols, TlsCrypto crypto, LoggingContext context) { }

	[CompilerGenerated]
	protected LoggingContext get_Context() { }

	public virtual TlsAuthentication GetAuthentication() { }

	public override TlsCredentials GetClientCredentials(CertificateRequest certificateRequest) { }

	public string GetNegotiatedApplicationProtocol() { }

	protected virtual IList<ProtocolName> GetProtocolNames() { }

	protected virtual IList<ServerName> GetSniServerNames() { }

	protected virtual Int32[] GetSupportedCipherSuites() { }

	protected virtual ProtocolVersion[] GetSupportedVersions() { }

	public virtual void NotifyAlertRaised(short alertLevel, short alertDescription, string message, Exception cause) { }

	public virtual void NotifyAlertReceived(short alertLevel, short alertDescription) { }

	public virtual void NotifyHandshakeBeginning() { }

	public virtual void NotifyHandshakeComplete() { }

	public virtual void NotifyNewSessionTicket(NewSessionTicket newSessionTicket) { }

	public virtual void NotifySecureRenegotiation(bool secureRenegotiation) { }

	public virtual void NotifySelectedCipherSuite(int selectedCipherSuite) { }

	public virtual void NotifySelectedPsk(TlsPsk selectedPsk) { }

	public override void NotifyServerCertificate(TlsServerCertificate serverCertificate) { }

	public virtual void NotifyServerVersion(ProtocolVersion serverVersion) { }

	public virtual void NotifySessionID(Byte[] sessionID) { }

	public virtual void NotifySessionToResume(TlsSession session) { }

	public virtual void ProcessServerExtensions(IDictionary<Int32, Byte[]> serverExtensions) { }

	[CompilerGenerated]
	private void set_Context(LoggingContext value) { }

}

