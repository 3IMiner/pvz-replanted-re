namespace Best.HTTP.Shared.TLS;

public class DefaultTls13Client : AbstractTls13Client
{

	public DefaultTls13Client(List<ServerName> sniServerNames, List<ProtocolName> protocols, LoggingContext context) { }

}

