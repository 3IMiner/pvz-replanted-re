namespace Best.HTTP.Shared.TLS.Crypto.Impl;

[Il2CppEagerStaticClassConstruction]
public sealed class FastAesEngine : IBlockCipher
{
	private static readonly Byte[] S; //Field offset: 0x0
	private const uint m1 = 2155905152; //Field offset: 0x0
	private const uint m2 = 2139062143; //Field offset: 0x0
	private const uint m3 = 27; //Field offset: 0x0
	private const uint m4 = 3233857728; //Field offset: 0x0
	private const uint m5 = 1061109567; //Field offset: 0x0
	private const int BLOCK_SIZE = 16; //Field offset: 0x0
	private static readonly Byte[] Si; //Field offset: 0x8
	private static readonly Byte[] rcon; //Field offset: 0x10
	private static readonly UInt32[] T0; //Field offset: 0x18
	private static readonly UInt32[] Tinv0; //Field offset: 0x20
	private UInt32[][] W; //Field offset: 0x10
	private int ROUNDS; //Field offset: 0x18
	private UInt32[][] WorkingKey; //Field offset: 0x20
	private bool forEncryption; //Field offset: 0x28
	private Byte[] s; //Field offset: 0x30

	public override string AlgorithmName
	{
		 get { } //Length: 44
	}

	private static FastAesEngine() { }

	public FastAesEngine() { }

	private void DecryptBlock(ReadOnlySpan<Byte> input, Span<Byte> output, UInt32[][] KW) { }

	private void EncryptBlock(ReadOnlySpan<Byte> input, Span<Byte> output, UInt32[][] KW) { }

	private static uint FFmulX(uint x) { }

	private static uint FFmulX2(uint x) { }

	private UInt32[][] GenerateWorkingKey(Byte[] key, bool forEncryption) { }

	public override string get_AlgorithmName() { }

	public override int GetBlockSize() { }

	public override void Init(bool forEncryption, ICipherParameters parameters) { }

	private static uint Inv_Mcol(uint x) { }

	public override int ProcessBlock(Byte[] input, int inOff, Byte[] output, int outOff) { }

	public override int ProcessBlock(ReadOnlySpan<Byte> input, Span<Byte> output) { }

	private static uint Shift(uint r, int shift) { }

	private static uint SubWord(uint x) { }

}

