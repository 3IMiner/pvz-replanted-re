namespace Best.HTTP.Shared.TLS.Crypto.Impl;

[Il2CppEagerStaticClassConstruction]
public sealed class FastTlsAeadCipher : TlsCipher
{
	public const int AEAD_CCM = 1; //Field offset: 0x0
	public const int AEAD_CHACHA20_POLY1305 = 2; //Field offset: 0x0
	public const int AEAD_GCM = 3; //Field offset: 0x0
	private const int NONCE_RFC5288 = 1; //Field offset: 0x0
	private const int NONCE_RFC7905 = 2; //Field offset: 0x0
	private readonly TlsCryptoParameters m_cryptoParams; //Field offset: 0x10
	private readonly int m_keySize; //Field offset: 0x18
	private readonly int m_macSize; //Field offset: 0x1C
	private readonly int m_fixed_iv_length; //Field offset: 0x20
	private readonly int m_record_iv_length; //Field offset: 0x24
	private readonly TlsAeadCipherImpl m_decryptCipher; //Field offset: 0x28
	private readonly TlsAeadCipherImpl m_encryptCipher; //Field offset: 0x30
	private readonly Byte[] m_decryptNonce; //Field offset: 0x38
	private readonly Byte[] m_encryptNonce; //Field offset: 0x40
	private readonly bool m_isTlsV13; //Field offset: 0x48
	private readonly int m_nonceMode; //Field offset: 0x4C

	public override bool UsesOpaqueRecordType
	{
		 get { } //Length: 5
	}

	public FastTlsAeadCipher(TlsCryptoParameters cryptoParams, TlsAeadCipherImpl encryptCipher, TlsAeadCipherImpl decryptCipher, int keySize, int macSize, int aeadType) { }

	public override TlsDecodeResult DecodeCiphertext(long seqNo, short recordType, ProtocolVersion recordVersion, Byte[] ciphertext, int ciphertextOffset, int ciphertextLength) { }

	public override TlsEncodeResult EncodePlaintext(long seqNo, short contentType, ProtocolVersion recordVersion, int headerAllocation, Byte[] plaintext, int plaintextOffset, int plaintextLength) { }

	public override TlsEncodeResult EncodePlaintext(long seqNo, short contentType, ProtocolVersion recordVersion, int headerAllocation, ReadOnlySpan<Byte> plaintext) { }

	public override bool get_UsesOpaqueRecordType() { }

	private Byte[] GetAdditionalData(long seqNo, short recordType, ProtocolVersion recordVersion, int ciphertextLength, int plaintextLength) { }

	public override int GetCiphertextDecodeLimit(int plaintextLimit) { }

	public override int GetCiphertextEncodeLimit(int plaintextLength, int plaintextLimit) { }

	private static int GetNonceMode(bool isTLSv13, int aeadType) { }

	public override int GetPlaintextLimit(int ciphertextLimit) { }

	private void RekeyCipher(SecurityParameters securityParameters, TlsAeadCipherImpl cipher, Byte[] nonce, bool serverSecret) { }

	public override void RekeyDecoder() { }

	public override void RekeyEncoder() { }

	private void Setup13Cipher(TlsAeadCipherImpl cipher, Byte[] nonce, TlsSecret secret, int cryptoHashAlgorithm) { }

}

