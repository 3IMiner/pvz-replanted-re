namespace Best.HTTP.Shared.TLS.Crypto.Impl;

[Il2CppEagerStaticClassConstruction]
public sealed class FastChaCha7539Engine : FastSalsa20Engine
{

	public virtual string AlgorithmName
	{
		 get { } //Length: 44
	}

	protected virtual int NonceSize
	{
		 get { } //Length: 6
	}

	public FastChaCha7539Engine() { }

	protected virtual void AdvanceCounter() { }

	internal void DoFinal(Byte[] inBuf, int inOff, int inLen, Byte[] outBuf, int outOff) { }

	protected virtual void GenerateKeyStream(Byte[] output) { }

	public virtual string get_AlgorithmName() { }

	protected virtual int get_NonceSize() { }

	internal void ImplProcessBlock(ReadOnlySpan<Byte> input, Span<Byte> output) { }

	internal void ProcessBlock(ReadOnlySpan<Byte> input, Span<Byte> output) { }

	internal void ProcessBlocks2(ReadOnlySpan<Byte> input, Span<Byte> output) { }

	protected virtual void ResetCounter() { }

	protected virtual void SetKey(Byte[] keyBytes, Byte[] ivBytes) { }

}

