namespace Best.HTTP.Shared.TLS.Crypto.Impl;

public class FastCcmBlockCipher : IAeadBlockCipher, IAeadCipher
{
	private static readonly int BlockSize; //Field offset: 0x0
	private readonly IBlockCipher cipher; //Field offset: 0x10
	private readonly Byte[] macBlock; //Field offset: 0x18
	private bool forEncryption; //Field offset: 0x20
	private Byte[] nonce; //Field offset: 0x28
	private Byte[] initialAssociatedText; //Field offset: 0x30
	private int macSize; //Field offset: 0x38
	private ICipherParameters keyParam; //Field offset: 0x40
	private readonly MemoryStream associatedText; //Field offset: 0x48
	private readonly MemoryStream data; //Field offset: 0x50

	public override string AlgorithmName
	{
		 get { } //Length: 100
	}

	public override IBlockCipher UnderlyingCipher
	{
		 get { } //Length: 5
	}

	private static FastCcmBlockCipher() { }

	public FastCcmBlockCipher(IBlockCipher cipher) { }

	private int CalculateMac(ReadOnlySpan<Byte> data, Span<Byte> macBlock) { }

	private int CalculateMac(Byte[] data, int dataOff, int dataLen, Byte[] macBlock) { }

	public override int DoFinal(Span<Byte> output) { }

	public override int DoFinal(Byte[] outBytes, int outOff) { }

	public override string get_AlgorithmName() { }

	public override IBlockCipher get_UnderlyingCipher() { }

	private int GetAssociatedTextLength() { }

	public override int GetBlockSize() { }

	public override Byte[] GetMac() { }

	private int GetMacSize(bool forEncryption, int requestedMacBits) { }

	public override int GetOutputSize(int len) { }

	public override int GetUpdateOutputSize(int len) { }

	private bool HasAssociatedText() { }

	public override void Init(bool forEncryption, ICipherParameters parameters) { }

	public override void ProcessAadByte(byte input) { }

	public override void ProcessAadBytes(ReadOnlySpan<Byte> input) { }

	public override void ProcessAadBytes(Byte[] inBytes, int inOff, int len) { }

	public override int ProcessByte(byte input, Span<Byte> output) { }

	public override int ProcessByte(byte input, Byte[] outBytes, int outOff) { }

	public override int ProcessBytes(Byte[] inBytes, int inOff, int inLen, Byte[] outBytes, int outOff) { }

	public override int ProcessBytes(ReadOnlySpan<Byte> input, Span<Byte> output) { }

	public override Byte[] ProcessPacket(Byte[] input, int inOff, int inLen) { }

	public override int ProcessPacket(Byte[] input, int inOff, int inLen, Byte[] output, int outOff) { }

	public override int ProcessPacket(ReadOnlySpan<Byte> input, Span<Byte> output) { }

	public override void Reset() { }

}

