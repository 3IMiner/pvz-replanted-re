namespace Best.HTTP.Shared.TLS.Crypto.Impl;

[BurstCompile]
public static class FastChaCha7539EngineHelper
{
	public static class ProcessBlocks2Impl_0000078E$BurstDirectCall
	{
		private static IntPtr Pointer; //Field offset: 0x0

		private static IntPtr GetFunctionPointer() { }

		[BurstDiscard]
		private static void GetFunctionPointerDiscard(ref IntPtr unnamed_param_0) { }

		public static void Invoke(Byte* input, int inputLen, Byte* output, int outLen, UInt32* state, int stateLen, int rounds, Byte* keyStream) { }

	}

	[UnmanagedFunctionPointer(CallingConvention::Cdecl (2))]
	public sealed class ProcessBlocks2Impl_0000078E$PostfixBurstDelegate : MulticastDelegate
	{

		public ProcessBlocks2Impl_0000078E$PostfixBurstDelegate(object unnamed_param_0, IntPtr unnamed_param_1) { }

		public override IAsyncResult BeginInvoke(Byte* input, int inputLen, Byte* output, int outLen, UInt32* state, int stateLen, int rounds, Byte* keyStream, AsyncCallback unnamed_param_8, object unnamed_param_9) { }

		public override void EndInvoke(IAsyncResult unnamed_param_0) { }

		public override void Invoke(Byte* input, int inputLen, Byte* output, int outLen, UInt32* state, int stateLen, int rounds, Byte* keyStream) { }

	}


	public static void ProcessBlocks2(ReadOnlySpan<Byte> input, Span<Byte> output, UInt32[] state, int rounds, Byte[] keyStream) { }

	[BurstCompile]
	[MonoPInvokeCallback(typeof(ProcessBlocks2Impl_0000078E$PostfixBurstDelegate))]
	private static void ProcessBlocks2Impl(Byte* input, int inputLen, Byte* output, int outLen, UInt32* state, int stateLen, int rounds, Byte* keyStream) { }

	[BurstCompile]
	internal static void ProcessBlocks2Impl$BurstManaged(Byte* input, int inputLen, Byte* output, int outLen, UInt32* state, int stateLen, int rounds, Byte* keyStream) { }

}

