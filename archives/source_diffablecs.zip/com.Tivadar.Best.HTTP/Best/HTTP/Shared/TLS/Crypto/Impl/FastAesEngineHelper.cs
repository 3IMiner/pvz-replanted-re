namespace Best.HTTP.Shared.TLS.Crypto.Impl;

internal static class FastAesEngineHelper
{

	public static void EncryptBlock(Byte[] input, int inOff, Byte[] output, int outOff, UInt32[][] KW, int ROUNDS, UInt32[] T0, Byte[] S, Byte[] s) { }

}

