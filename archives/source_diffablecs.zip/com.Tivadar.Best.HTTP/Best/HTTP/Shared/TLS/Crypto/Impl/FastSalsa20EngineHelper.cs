namespace Best.HTTP.Shared.TLS.Crypto.Impl;

[BurstCompile]
internal static class FastSalsa20EngineHelper
{
	public static class ProcessBytes_000007DF$BurstDirectCall
	{
		private static IntPtr Pointer; //Field offset: 0x0

		private static IntPtr GetFunctionPointer() { }

		[BurstDiscard]
		private static void GetFunctionPointerDiscard(ref IntPtr unnamed_param_0) { }

		public static void Invoke(Byte* outBytes, int outOff, Byte* inBytes, int inOff, Byte* keyStream) { }

	}

	[UnmanagedFunctionPointer(CallingConvention::Cdecl (2))]
	public sealed class ProcessBytes_000007DF$PostfixBurstDelegate : MulticastDelegate
	{

		public ProcessBytes_000007DF$PostfixBurstDelegate(object unnamed_param_0, IntPtr unnamed_param_1) { }

		public override IAsyncResult BeginInvoke(Byte* outBytes, int outOff, Byte* inBytes, int inOff, Byte* keyStream, AsyncCallback unnamed_param_5, object unnamed_param_6) { }

		public override void EndInvoke(IAsyncResult unnamed_param_0) { }

		public override void Invoke(Byte* outBytes, int outOff, Byte* inBytes, int inOff, Byte* keyStream) { }

	}


	[BurstCompile]
	[MonoPInvokeCallback(typeof(ProcessBytes_000007DF$PostfixBurstDelegate))]
	public static void ProcessBytes(Byte* outBytes, int outOff, Byte* inBytes, int inOff, Byte* keyStream) { }

	[BurstCompile]
	internal static void ProcessBytes$BurstManaged(Byte* outBytes, int outOff, Byte* inBytes, int inOff, Byte* keyStream) { }

}

