namespace Best.HTTP.Shared.TLS.Crypto.Impl;

public class FastTlsBlockCipher : TlsCipher
{
	protected readonly TlsCryptoParameters m_cryptoParams; //Field offset: 0x10
	protected readonly Byte[] m_randomData; //Field offset: 0x18
	protected readonly bool m_encryptThenMac; //Field offset: 0x20
	protected readonly bool m_useExplicitIV; //Field offset: 0x21
	protected readonly bool m_acceptExtraPadding; //Field offset: 0x22
	protected readonly bool m_useExtraPadding; //Field offset: 0x23
	protected readonly TlsBlockCipherImpl m_decryptCipher; //Field offset: 0x28
	protected readonly TlsBlockCipherImpl m_encryptCipher; //Field offset: 0x30
	protected readonly TlsSuiteMac m_readMac; //Field offset: 0x38
	protected readonly TlsSuiteMac m_writeMac; //Field offset: 0x40

	public override bool UsesOpaqueRecordType
	{
		 get { } //Length: 3
	}

	public FastTlsBlockCipher(TlsCryptoParameters cryptoParams, TlsBlockCipherImpl encryptCipher, TlsBlockCipherImpl decryptCipher, TlsHmac clientMac, TlsHmac serverMac, int cipherKeySize) { }

	protected override int CheckPaddingConstantTime(Byte[] buf, int off, int len, int blockSize, int macSize) { }

	protected override int ChooseExtraPadBlocks(int max) { }

	public override TlsDecodeResult DecodeCiphertext(long seqNo, short recordType, ProtocolVersion recordVersion, Byte[] ciphertext, int offset, int len) { }

	public override TlsEncodeResult EncodePlaintext(long seqNo, short contentType, ProtocolVersion recordVersion, int headerAllocation, Byte[] plaintext, int offset, int len) { }

	public override TlsEncodeResult EncodePlaintext(long seqNo, short contentType, ProtocolVersion recordVersion, int headerAllocation, ReadOnlySpan<Byte> plaintext) { }

	public override bool get_UsesOpaqueRecordType() { }

	public override int GetCiphertextDecodeLimit(int plaintextLimit) { }

	public override int GetCiphertextEncodeLimit(int plaintextLength, int plaintextLimit) { }

	protected override int GetCiphertextLength(int blockSize, int macSize, int maxPadding, int plaintextLength) { }

	public override int GetPlaintextLimit(int ciphertextLimit) { }

	public override void RekeyDecoder() { }

	public override void RekeyEncoder() { }

}

