namespace Best.HTTP.Shared.TLS.Crypto;

[Il2CppEagerStaticClassConstruction]
public sealed class FastCbcBlockCipher : IBlockCipherMode, IBlockCipher
{
	private Byte[] IV; //Field offset: 0x10
	private Byte[] cbcV; //Field offset: 0x18
	private Byte[] cbcNextV; //Field offset: 0x20
	private int blockSize; //Field offset: 0x28
	private IBlockCipher cipher; //Field offset: 0x30
	private bool encrypting; //Field offset: 0x38

	public override string AlgorithmName
	{
		 get { } //Length: 100
	}

	public override bool IsPartialBlockOkay
	{
		 get { } //Length: 3
	}

	public override IBlockCipher UnderlyingCipher
	{
		 get { } //Length: 5
	}

	public FastCbcBlockCipher(IBlockCipher cipher) { }

	private int DecryptBlock(ReadOnlySpan<Byte> input, Span<Byte> output) { }

	private int EncryptBlock(ReadOnlySpan<Byte> input, Span<Byte> output) { }

	public override string get_AlgorithmName() { }

	public override bool get_IsPartialBlockOkay() { }

	public override IBlockCipher get_UnderlyingCipher() { }

	public override int GetBlockSize() { }

	public override void Init(bool forEncryption, ICipherParameters parameters) { }

	public override int ProcessBlock(Byte[] input, int inOff, Byte[] output, int outOff) { }

	public override int ProcessBlock(ReadOnlySpan<Byte> input, Span<Byte> output) { }

	public override void Reset() { }

}

