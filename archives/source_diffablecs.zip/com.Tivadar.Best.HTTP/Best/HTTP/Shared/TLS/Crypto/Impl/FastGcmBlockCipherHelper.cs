namespace Best.HTTP.Shared.TLS.Crypto.Impl;

[BurstCompile]
internal sealed class FastGcmBlockCipherHelper
{
	public static class DecryptBlock_Impl_000007BC$BurstDirectCall
	{
		private static IntPtr Pointer; //Field offset: 0x0

		private static IntPtr GetFunctionPointer() { }

		[BurstDiscard]
		private static void GetFunctionPointerDiscard(ref IntPtr unnamed_param_0) { }

		public static void Invoke(Byte* pinput, int inLen, Byte* poutput, int outLen, Byte* pctrBlock, Byte* pS, int BlockSize) { }

	}

	[UnmanagedFunctionPointer(CallingConvention::Cdecl (2))]
	public sealed class DecryptBlock_Impl_000007BC$PostfixBurstDelegate : MulticastDelegate
	{

		public DecryptBlock_Impl_000007BC$PostfixBurstDelegate(object unnamed_param_0, IntPtr unnamed_param_1) { }

		public override IAsyncResult BeginInvoke(Byte* pinput, int inLen, Byte* poutput, int outLen, Byte* pctrBlock, Byte* pS, int BlockSize, AsyncCallback unnamed_param_7, object unnamed_param_8) { }

		public override void EndInvoke(IAsyncResult unnamed_param_0) { }

		public override void Invoke(Byte* pinput, int inLen, Byte* poutput, int outLen, Byte* pctrBlock, Byte* pS, int BlockSize) { }

	}


	public FastGcmBlockCipherHelper() { }

	public static void DecryptBlock(ReadOnlySpan<Byte> input, Span<Byte> output, Span<Byte> ctrBlock, Span<Byte> S, int BlockSize) { }

	[BurstCompile(CompileSynchronously = True)]
	[MonoPInvokeCallback(typeof(DecryptBlock_Impl_000007BC$PostfixBurstDelegate))]
	private static void DecryptBlock_Impl(Byte* pinput, int inLen, Byte* poutput, int outLen, Byte* pctrBlock, Byte* pS, int BlockSize) { }

	[BurstCompile(CompileSynchronously = True)]
	internal static void DecryptBlock_Impl$BurstManaged(Byte* pinput, int inLen, Byte* poutput, int outLen, Byte* pctrBlock, Byte* pS, int BlockSize) { }

}

