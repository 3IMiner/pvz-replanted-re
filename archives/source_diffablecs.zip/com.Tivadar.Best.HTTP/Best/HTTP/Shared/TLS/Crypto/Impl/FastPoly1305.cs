namespace Best.HTTP.Shared.TLS.Crypto.Impl;

[Il2CppEagerStaticClassConstruction]
public sealed class FastPoly1305 : IMac
{
	private const int BlockSize = 16; //Field offset: 0x0
	private readonly IBlockCipher cipher; //Field offset: 0x10
	private uint r0; //Field offset: 0x18
	private uint r1; //Field offset: 0x1C
	private uint r2; //Field offset: 0x20
	private uint r3; //Field offset: 0x24
	private uint r4; //Field offset: 0x28
	private uint s1; //Field offset: 0x2C
	private uint s2; //Field offset: 0x30
	private uint s3; //Field offset: 0x34
	private uint s4; //Field offset: 0x38
	private uint k0; //Field offset: 0x3C
	private uint k1; //Field offset: 0x40
	private uint k2; //Field offset: 0x44
	private uint k3; //Field offset: 0x48
	private Byte[] currentBlock; //Field offset: 0x50
	private int currentBlockOffset; //Field offset: 0x58
	private uint h0; //Field offset: 0x5C
	private uint h1; //Field offset: 0x60
	private uint h2; //Field offset: 0x64
	private uint h3; //Field offset: 0x68
	private uint h4; //Field offset: 0x6C

	public override string AlgorithmName
	{
		 get { } //Length: 122
	}

	public FastPoly1305() { }

	public FastPoly1305(IBlockCipher cipher) { }

	public override void BlockUpdate(Byte[] input, int inOff, int len) { }

	public override void BlockUpdate(ReadOnlySpan<Byte> input) { }

	public override int DoFinal(Byte[] output, int outOff) { }

	public override int DoFinal(Span<Byte> output) { }

	public override string get_AlgorithmName() { }

	public override int GetMacSize() { }

	public override void Init(ICipherParameters parameters) { }

	private void ProcessBlock(ReadOnlySpan<Byte> block) { }

	public override void Reset() { }

	private void SetKey(Byte[] key, Byte[] nonce) { }

	public override void Update(byte input) { }

}

