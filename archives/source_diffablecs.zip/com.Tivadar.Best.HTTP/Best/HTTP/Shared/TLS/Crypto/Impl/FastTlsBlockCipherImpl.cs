namespace Best.HTTP.Shared.TLS.Crypto.Impl;

internal sealed class FastTlsBlockCipherImpl : TlsBlockCipherImpl
{
	private readonly bool m_isEncrypting; //Field offset: 0x10
	private readonly IBlockCipher m_cipher; //Field offset: 0x18
	private KeyParameter key; //Field offset: 0x20

	internal FastTlsBlockCipherImpl(IBlockCipher cipher, bool isEncrypting) { }

	public override int DoFinal(Byte[] input, int inputOffset, int inputLength, Byte[] output, int outputOffset) { }

	public override int GetBlockSize() { }

	public override void Init(Byte[] iv, int ivOff, int ivLen) { }

	public override void Init(ReadOnlySpan<Byte> iv) { }

	public override void SetKey(Byte[] key, int keyOff, int keyLen) { }

	public override void SetKey(ReadOnlySpan<Byte> key) { }

}

