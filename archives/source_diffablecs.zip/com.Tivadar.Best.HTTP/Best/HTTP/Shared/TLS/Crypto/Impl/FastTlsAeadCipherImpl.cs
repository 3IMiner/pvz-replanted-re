namespace Best.HTTP.Shared.TLS.Crypto.Impl;

internal sealed class FastTlsAeadCipherImpl : TlsAeadCipherImpl
{
	private readonly bool m_isEncrypting; //Field offset: 0x10
	private readonly IAeadCipher m_cipher; //Field offset: 0x18
	private KeyParameter key; //Field offset: 0x20

	internal FastTlsAeadCipherImpl(IAeadCipher cipher, bool isEncrypting) { }

	public override int DoFinal(Byte[] input, int inputOffset, int inputLength, Byte[] output, int outputOffset) { }

	public override int GetOutputSize(int inputLength) { }

	public override void Init(Byte[] nonce, int macSize, Byte[] additionalData) { }

	public override void Reset() { }

	public override void SetKey(Byte[] key, int keyOff, int keyLen) { }

	public override void SetKey(ReadOnlySpan<Byte> key) { }

}

