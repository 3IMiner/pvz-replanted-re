namespace Best.HTTP.Shared.TLS.Crypto.Impl;

[BurstCompile]
internal static class FastChaChaEngineHelper
{
	public static class ChachaCoreImpl_00000798$BurstDirectCall
	{
		private static IntPtr Pointer; //Field offset: 0x0

		private static IntPtr GetFunctionPointer() { }

		[BurstDiscard]
		private static void GetFunctionPointerDiscard(ref IntPtr unnamed_param_0) { }

		public static void Invoke(int rounds, UInt32* input, Byte* output) { }

	}

	[UnmanagedFunctionPointer(CallingConvention::Cdecl (2))]
	public sealed class ChachaCoreImpl_00000798$PostfixBurstDelegate : MulticastDelegate
	{

		public ChachaCoreImpl_00000798$PostfixBurstDelegate(object unnamed_param_0, IntPtr unnamed_param_1) { }

		public override IAsyncResult BeginInvoke(int rounds, UInt32* input, Byte* output, AsyncCallback unnamed_param_3, object unnamed_param_4) { }

		public override void EndInvoke(IAsyncResult unnamed_param_0) { }

		public override void Invoke(int rounds, UInt32* input, Byte* output) { }

	}


	internal static void ChachaCore(int rounds, UInt32[] input, Byte[] output) { }

	[BurstCompile]
	[MonoPInvokeCallback(typeof(ChachaCoreImpl_00000798$PostfixBurstDelegate))]
	[SkipLocalsInit]
	internal static void ChachaCoreImpl(int rounds, UInt32* input, Byte* output) { }

	[BurstCompile]
	[SkipLocalsInit]
	internal static void ChachaCoreImpl$BurstManaged(int rounds, UInt32* input, Byte* output) { }

	internal static void ImplProcessBlock(ReadOnlySpan<Byte> input, Span<Byte> output, Byte[] keyStream) { }

}

