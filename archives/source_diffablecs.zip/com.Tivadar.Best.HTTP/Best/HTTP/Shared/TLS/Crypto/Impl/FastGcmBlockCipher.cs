namespace Best.HTTP.Shared.TLS.Crypto.Impl;

[BurstCompile]
[Il2CppEagerStaticClassConstruction]
public sealed class FastGcmBlockCipher : IAeadBlockCipher, IAeadCipher
{
	public const int BlockSize = 16; //Field offset: 0x0
	private Byte[] ctrBlock; //Field offset: 0x10
	private readonly IBlockCipher cipher; //Field offset: 0x18
	private readonly BurstTables8kGcmMultiplier multiplier; //Field offset: 0x20
	private IGcmExponentiator exp; //Field offset: 0x28
	private bool forEncryption; //Field offset: 0x30
	private bool initialised; //Field offset: 0x31
	private int macSize; //Field offset: 0x34
	private Byte[] lastKey; //Field offset: 0x38
	private Byte[] nonce; //Field offset: 0x40
	private Byte[] initialAssociatedText; //Field offset: 0x48
	private Byte[] H; //Field offset: 0x50
	private Byte[] J0; //Field offset: 0x58
	private Byte[] bufBlock; //Field offset: 0x60
	private Byte[] macBlock; //Field offset: 0x68
	private Byte[] S; //Field offset: 0x70
	private Byte[] S_at; //Field offset: 0x78
	private Byte[] S_atPre; //Field offset: 0x80
	private Byte[] counter; //Field offset: 0x88
	private uint counter32; //Field offset: 0x90
	private uint blocksRemaining; //Field offset: 0x94
	private int bufOff; //Field offset: 0x98
	private ulong totalLength; //Field offset: 0xA0
	private Byte[] atBlock; //Field offset: 0xA8
	private int atBlockPos; //Field offset: 0xB0
	private ulong atLength; //Field offset: 0xB8
	private ulong atLengthPre; //Field offset: 0xC0

	public override string AlgorithmName
	{
		 get { } //Length: 100
	}

	public override IBlockCipher UnderlyingCipher
	{
		 get { } //Length: 5
	}

	public FastGcmBlockCipher(IBlockCipher c) { }

	public FastGcmBlockCipher(IBlockCipher c, IGcmMultiplier m) { }

	private void CheckStatus() { }

	private static IGcmMultiplier CreateGcmMultiplier() { }

	private void DecryptBlock(ReadOnlySpan<Byte> input, Span<Byte> output) { }

	private void DecryptBlocks2(ReadOnlySpan<Byte> input, Span<Byte> outputSample) { }

	public override int DoFinal(Byte[] output, int outOff) { }

	public override int DoFinal(Span<Byte> output) { }

	private void EncryptBlock(ReadOnlySpan<Byte> input, Span<Byte> output) { }

	private void EncryptBlocks2(ReadOnlySpan<Byte> input, Span<Byte> output) { }

	public override string get_AlgorithmName() { }

	public override IBlockCipher get_UnderlyingCipher() { }

	public override int GetBlockSize() { }

	public override Byte[] GetMac() { }

	private void GetNextCtrBlock(Span<Byte> block) { }

	public override int GetOutputSize(int len) { }

	public override int GetUpdateOutputSize(int len) { }

	private void gHASH(Byte[] Y, Byte[] b, int len) { }

	private void gHASHBlock(Byte[] Y, ReadOnlySpan<Byte> b) { }

	private void gHASHPartial(Byte[] Y, ReadOnlySpan<Byte> b) { }

	private void gHASHPartial(Byte[] Y, Byte[] b, int off, int len) { }

	public override void Init(bool forEncryption, ICipherParameters parameters) { }

	private void InitCipher() { }

	public override void ProcessAadByte(byte input) { }

	public override void ProcessAadBytes(ReadOnlySpan<Byte> input) { }

	public override void ProcessAadBytes(Byte[] inBytes, int inOff, int len) { }

	public override int ProcessByte(byte input, Span<Byte> output) { }

	public override int ProcessByte(byte input, Byte[] output, int outOff) { }

	public override int ProcessBytes(ReadOnlySpan<Byte> input, Span<Byte> output) { }

	public override int ProcessBytes(Byte[] input, int inOff, int len, Byte[] output, int outOff) { }

	private void ProcessPartial(Span<Byte> partialBlock, Span<Byte> output) { }

	private void Reset(bool clearMac) { }

	public override void Reset() { }

}

