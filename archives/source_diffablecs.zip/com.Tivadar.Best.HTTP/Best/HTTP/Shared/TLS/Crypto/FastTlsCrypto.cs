namespace Best.HTTP.Shared.TLS.Crypto;

public sealed class FastTlsCrypto : BcTlsCrypto
{

	public FastTlsCrypto(SecureRandom entropySource) { }

	protected virtual IBlockCipher CreateAesEngine() { }

	protected virtual IBlockCipher CreateCbcBlockCipher(IBlockCipher blockCipher) { }

	protected virtual IAeadCipher CreateCcmMode(IBlockCipher engine) { }

	public virtual TlsCipher CreateCipher(TlsCryptoParameters cryptoParams, int encryptionAlgorithm, int macAlgorithm) { }

	protected virtual IAeadCipher CreateGcmMode(IBlockCipher engine) { }

}

