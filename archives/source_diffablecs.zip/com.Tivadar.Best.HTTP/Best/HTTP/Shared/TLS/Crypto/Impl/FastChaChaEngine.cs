namespace Best.HTTP.Shared.TLS.Crypto.Impl;

[Il2CppEagerStaticClassConstruction]
public sealed class FastChaChaEngine : FastSalsa20Engine
{

	public virtual string AlgorithmName
	{
		 get { } //Length: 71
	}

	public FastChaChaEngine() { }

	public FastChaChaEngine(int rounds) { }

	protected virtual void AdvanceCounter() { }

	internal static void ChachaCore(int rounds, UInt32[] input, Byte[] output) { }

	protected virtual void GenerateKeyStream(Byte[] output) { }

	public virtual string get_AlgorithmName() { }

	protected virtual void ResetCounter() { }

	protected virtual void SetKey(Byte[] keyBytes, Byte[] ivBytes) { }

}

