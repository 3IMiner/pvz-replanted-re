namespace Best.HTTP.Shared.TLS.Crypto.Impl;

[Il2CppEagerStaticClassConstruction]
public class FastSalsa20Engine : IStreamCipher
{
	public static readonly int DEFAULT_ROUNDS; //Field offset: 0x0
	private const int StateSize = 16; //Field offset: 0x0
	private static readonly UInt32[] TAU_SIGMA; //Field offset: 0x8
	protected int rounds; //Field offset: 0x10
	internal int index; //Field offset: 0x14
	internal UInt32[] engineState; //Field offset: 0x18
	internal UInt32[] x; //Field offset: 0x20
	internal Byte[] keyStream; //Field offset: 0x28
	internal bool initialised; //Field offset: 0x30
	private uint cW0; //Field offset: 0x34
	private uint cW1; //Field offset: 0x38
	private uint cW2; //Field offset: 0x3C

	public override string AlgorithmName
	{
		 get { } //Length: 188
	}

	protected override int NonceSize
	{
		 get { } //Length: 6
	}

	private static FastSalsa20Engine() { }

	public FastSalsa20Engine() { }

	public FastSalsa20Engine(int rounds) { }

	protected override void AdvanceCounter() { }

	protected override void GenerateKeyStream(Byte[] output) { }

	public override string get_AlgorithmName() { }

	protected override int get_NonceSize() { }

	public override void Init(bool forEncryption, ICipherParameters parameters) { }

	internal bool LimitExceeded(uint len) { }

	internal bool LimitExceeded() { }

	internal void PackTauOrSigma(int keyLength, UInt32[] state, int stateOffset) { }

	public override void ProcessBytes(Byte[] inBytes, int inOff, int len, Byte[] outBytes, int outOff) { }

	public override void ProcessBytes(ReadOnlySpan<Byte> input, Span<Byte> output) { }

	private static void QuarterRound(ref uint a, ref uint b, ref uint c, ref uint d) { }

	public override void Reset() { }

	protected override void ResetCounter() { }

	internal void ResetLimitCounter() { }

	public override byte ReturnByte(byte input) { }

	internal static void SalsaCore(int rounds, ReadOnlySpan<UInt32> input, Span<UInt32> output) { }

	protected override void SetKey(Byte[] keyBytes, Byte[] ivBytes) { }

}

