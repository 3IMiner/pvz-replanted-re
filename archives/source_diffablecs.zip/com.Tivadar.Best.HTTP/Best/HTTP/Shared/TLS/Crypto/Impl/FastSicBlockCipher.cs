namespace Best.HTTP.Shared.TLS.Crypto.Impl;

public class FastSicBlockCipher : IBlockCipherMode, IBlockCipher
{
	private readonly IBlockCipher cipher; //Field offset: 0x10
	private readonly int blockSize; //Field offset: 0x18
	private readonly Byte[] counter; //Field offset: 0x20
	private readonly Byte[] counterOut; //Field offset: 0x28
	private Byte[] IV; //Field offset: 0x30

	public override string AlgorithmName
	{
		 get { } //Length: 197
	}

	public override bool IsPartialBlockOkay
	{
		 get { } //Length: 3
	}

	public override IBlockCipher UnderlyingCipher
	{
		 get { } //Length: 5
	}

	public FastSicBlockCipher(IBlockCipher cipher) { }

	public override string get_AlgorithmName() { }

	public override bool get_IsPartialBlockOkay() { }

	public override IBlockCipher get_UnderlyingCipher() { }

	public override int GetBlockSize() { }

	public override void Init(bool forEncryption, ICipherParameters parameters) { }

	public override int ProcessBlock(Byte[] input, int inOff, Byte[] output, int outOff) { }

	public override int ProcessBlock(ReadOnlySpan<Byte> input, Span<Byte> output) { }

	public override void Reset() { }

}

