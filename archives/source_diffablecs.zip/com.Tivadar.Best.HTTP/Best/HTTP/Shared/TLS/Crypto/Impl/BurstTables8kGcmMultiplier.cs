namespace Best.HTTP.Shared.TLS.Crypto.Impl;

[BurstCompile]
[Il2CppEagerStaticClassConstruction]
public sealed class BurstTables8kGcmMultiplier
{
	public static class MultiplyHImpl_0000074B$BurstDirectCall
	{
		private static IntPtr Pointer; //Field offset: 0x0

		private static IntPtr GetFunctionPointer() { }

		[BurstDiscard]
		private static void GetFunctionPointerDiscard(ref IntPtr unnamed_param_0) { }

		public static void Invoke(Byte* px, FieldElement* pT0, FieldElement* pT1) { }

	}

	[UnmanagedFunctionPointer(CallingConvention::Cdecl (2))]
	public sealed class MultiplyHImpl_0000074B$PostfixBurstDelegate : MulticastDelegate
	{

		public MultiplyHImpl_0000074B$PostfixBurstDelegate(object unnamed_param_0, IntPtr unnamed_param_1) { }

		public override IAsyncResult BeginInvoke(Byte* px, FieldElement* pT0, FieldElement* pT1, AsyncCallback unnamed_param_3, object unnamed_param_4) { }

		public override void EndInvoke(IAsyncResult unnamed_param_0) { }

		public override void Invoke(Byte* px, FieldElement* pT0, FieldElement* pT1) { }

	}

	private Byte[] H; //Field offset: 0x10
	private FieldElement[][] T; //Field offset: 0x18

	public BurstTables8kGcmMultiplier() { }

	public void Init(Byte[] H) { }

	public void MultiplyH(Byte[] x) { }

	[BurstCompile]
	[MonoPInvokeCallback(typeof(MultiplyHImpl_0000074B$PostfixBurstDelegate))]
	private static void MultiplyHImpl(Byte* px, FieldElement* pT0, FieldElement* pT1) { }

	[BurstCompile]
	internal static void MultiplyHImpl$BurstManaged(Byte* px, FieldElement* pT0, FieldElement* pT1) { }

}

