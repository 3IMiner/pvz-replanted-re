namespace Best.HTTP.Shared.TLS.Crypto.Impl;

public sealed class FastBcChaCha20Poly1305 : TlsAeadCipherImpl
{
	private static readonly Byte[] Zeroes; //Field offset: 0x0
	private readonly FastChaCha7539Engine m_cipher; //Field offset: 0x10
	private readonly FastPoly1305 m_mac; //Field offset: 0x18
	private readonly bool m_isEncrypting; //Field offset: 0x20
	private int m_additionalDataLength; //Field offset: 0x24
	private Byte[] firstBlock; //Field offset: 0x28

	private static FastBcChaCha20Poly1305() { }

	public FastBcChaCha20Poly1305(bool isEncrypting) { }

	public override int DoFinal(Byte[] input, int inputOffset, int inputLength, Byte[] output, int outputOffset) { }

	public override int GetOutputSize(int inputLength) { }

	public override void Init(Byte[] nonce, int macSize, Byte[] additionalData) { }

	private void InitMac() { }

	public override void Reset() { }

	public override void SetKey(Byte[] key, int keyOff, int keyLen) { }

	public override void SetKey(ReadOnlySpan<Byte> key) { }

	private void UpdateMac(Byte[] buf, int off, int len) { }

}

