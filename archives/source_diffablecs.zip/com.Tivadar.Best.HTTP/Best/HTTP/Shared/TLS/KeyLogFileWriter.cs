namespace Best.HTTP.Shared.TLS;

internal static class KeyLogFileWriter
{

	private static string GetKeylogFileName() { }

	[Conditional("UNITY_EDITOR")]
	public static void WriteLabel(Labels label, Byte[] clientRandom, TlsSecret secret) { }

	[Conditional("UNITY_EDITOR")]
	public static void WriteLabel(Labels label, SecurityParameters securityParameters) { }

}

