namespace Best.HTTP.Shared.Databases;

public abstract class Database : IDisposable, IHeartbeat
{
	[CompilerGenerated]
	private sealed class <>c
	{
		public static readonly <>c<ContentType, MetadataType, IndexingServiceType, MetadataServiceType> <>9; //Field offset: 0x0
		public static Func<MetadataType, Int32> <>9__41_0; //Field offset: 0x0

		private static <>c() { }

		public <>c() { }

		internal int <FromMetadatas>b__41_0(MetadataType m) { }

	}

	[CompilerGenerated]
	private sealed class <FromMetadataIndexes>d__42 : IEnumerable<ContentType>, IEnumerable, IEnumerator<ContentType>, IEnumerator, IDisposable
	{
		private int <>1__state; //Field offset: 0x0
		private ContentType <>2__current; //Field offset: 0x0
		private int <>l__initialThreadId; //Field offset: 0x0
		private IEnumerable<Int32> metadataIndexes; //Field offset: 0x0
		public IEnumerable<Int32> <>3__metadataIndexes; //Field offset: 0x0
		public Database<ContentType, MetadataType, IndexingServiceType, MetadataServiceType> <>4__this; //Field offset: 0x0
		private IEnumerator<Int32> <>7__wrap1; //Field offset: 0x0

		private override ContentType System.Collections.Generic.IEnumerator<ContentType>.Current
		{
			[DebuggerHidden]
			private get { } //Length: 5
		}

		private override object System.Collections.IEnumerator.Current
		{
			[DebuggerHidden]
			private get { } //Length: 5
		}

		[DebuggerHidden]
		public <FromMetadataIndexes>d__42(int <>1__state) { }

		private void <>m__Finally1() { }

		private override bool MoveNext() { }

		[DebuggerHidden]
		private override IEnumerator<ContentType> System.Collections.Generic.IEnumerable<ContentType>.GetEnumerator() { }

		[DebuggerHidden]
		private override ContentType System.Collections.Generic.IEnumerator<ContentType>.get_Current() { }

		[DebuggerHidden]
		private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

		[DebuggerHidden]
		private override object System.Collections.IEnumerator.get_Current() { }

		[DebuggerHidden]
		private override void System.Collections.IEnumerator.Reset() { }

		[DebuggerHidden]
		private override void System.IDisposable.Dispose() { }

	}

	public static FolderAndFileOptions FolderAndFileOptions; //Field offset: 0x0
	[CompilerGenerated]
	private string <SaveDir>k__BackingField; //Field offset: 0x0
	[CompilerGenerated]
	private MetadataServiceType <MetadataService>k__BackingField; //Field offset: 0x0
	[CompilerGenerated]
	private DatabaseOptions <Options>k__BackingField; //Field offset: 0x0
	[CompilerGenerated]
	private IndexingServiceType <IndexingService>k__BackingField; //Field offset: 0x0
	[CompilerGenerated]
	private DiskManager<ContentType> <DiskManager>k__BackingField; //Field offset: 0x0
	protected int isDirty; //Field offset: 0x0
	protected ReaderWriterLockSlim rwlock; //Field offset: 0x0

	public string DatabaseFileName
	{
		 get { } //Length: 239
	}

	public string DatabaseFreeListFileName
	{
		 get { } //Length: 239
	}

	protected private DiskManager<ContentType> DiskManager
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 13
	}

	public string HashFileName
	{
		 get { } //Length: 239
	}

	protected private IndexingServiceType IndexingService
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 13
	}

	public string MetadataFileName
	{
		 get { } //Length: 239
	}

	public private MetadataServiceType MetadataService
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 13
	}

	public string Name
	{
		 get { } //Length: 27
	}

	protected private DatabaseOptions Options
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 13
	}

	public private string SaveDir
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 13
	}

	private static Database`4() { }

	public Database`4(string directory, DatabaseOptions options, IndexingServiceType indexingService, IDiskContentParser<ContentType> diskContentParser, MetadataServiceType metadataService) { }

	private override void Best.HTTP.Shared.Extensions.IHeartbeat.OnHeartbeatUpdate(DateTime now, TimeSpan dif) { }

	public int Clear() { }

	public int Delete(IEnumerable<Int32> metadataIndexes) { }

	public int Delete(IEnumerable<MetadataType> metadatas) { }

	protected bool DeleteMetadata(MetadataType metadata) { }

	public override void Dispose() { }

	protected void FlagDirty(int dirty) { }

	public ContentType FromFirstMetadataIndex(IEnumerable<Int32> metadataIndexes) { }

	public ContentType FromMetadata(MetadataType metadata) { }

	public ContentType FromMetadataIndex(int metadataIndex) { }

	[IteratorStateMachine(typeof(<FromMetadataIndexes>d__42))]
	public IEnumerable<ContentType> FromMetadataIndexes(IEnumerable<Int32> metadataIndexes) { }

	public IEnumerable<ContentType> FromMetadatas(IEnumerable<MetadataType> metadatas) { }

	public string get_DatabaseFileName() { }

	public string get_DatabaseFreeListFileName() { }

	[CompilerGenerated]
	protected DiskManager<ContentType> get_DiskManager() { }

	public string get_HashFileName() { }

	[CompilerGenerated]
	protected IndexingServiceType get_IndexingService() { }

	public string get_MetadataFileName() { }

	[CompilerGenerated]
	public MetadataServiceType get_MetadataService() { }

	public string get_Name() { }

	[CompilerGenerated]
	protected DatabaseOptions get_Options() { }

	[CompilerGenerated]
	public string get_SaveDir() { }

	public bool Save() { }

	[CompilerGenerated]
	private void set_DiskManager(DiskManager<ContentType> value) { }

	[CompilerGenerated]
	private void set_IndexingService(IndexingServiceType value) { }

	[CompilerGenerated]
	private void set_MetadataService(MetadataServiceType value) { }

	[CompilerGenerated]
	private void set_Options(DatabaseOptions value) { }

	[CompilerGenerated]
	private void set_SaveDir(string value) { }

}

