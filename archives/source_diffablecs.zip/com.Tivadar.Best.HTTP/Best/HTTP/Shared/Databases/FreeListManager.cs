namespace Best.HTTP.Shared.Databases;

public sealed class FreeListManager : IDisposable
{
	private struct FreeSpot
	{
		public int pos; //Field offset: 0x0
		public int length; //Field offset: 0x4

	}

	private Stream stream; //Field offset: 0x10
	private List<FreeSpot> freeList; //Field offset: 0x18

	public FreeListManager(Stream stream) { }

	public void Add(int pos, int length) { }

	public void Clear() { }

	public override void Dispose() { }

	public int FindFreeIndex(int length) { }

	private void Load() { }

	public int Occupy(int idx, int length) { }

	public void Save() { }

}

