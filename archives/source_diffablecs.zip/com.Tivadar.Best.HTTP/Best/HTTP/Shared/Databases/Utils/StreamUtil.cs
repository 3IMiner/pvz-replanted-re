namespace Best.HTTP.Shared.Databases.Utils;

[Extension]
public static class StreamUtil
{

	[Extension]
	public static long DecodeSignedVariableByteInteger(Stream stream) { }

	[Extension]
	public static ulong DecodeUnsignedVariableByteInteger(Stream decodeFrom) { }

	[Extension]
	public static void EncodeSignedVariableByteInteger(Stream encodeTo, long value) { }

	[Extension]
	public static void EncodeUnsignedVariableByteInteger(Stream encodeTo, ulong value) { }

	[Extension]
	public static string ReadLengthPrefixedString(Stream stream) { }

	[Extension]
	public static void WriteLengthPrefixedString(Stream stream, string str) { }

}

