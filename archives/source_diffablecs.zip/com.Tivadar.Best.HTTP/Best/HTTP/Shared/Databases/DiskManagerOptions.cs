namespace Best.HTTP.Shared.Databases;

public sealed class DiskManagerOptions
{
	public int MaxCacheSizeInBytes; //Field offset: 0x10
	public string HashDigest; //Field offset: 0x18

	public DiskManagerOptions() { }

}

