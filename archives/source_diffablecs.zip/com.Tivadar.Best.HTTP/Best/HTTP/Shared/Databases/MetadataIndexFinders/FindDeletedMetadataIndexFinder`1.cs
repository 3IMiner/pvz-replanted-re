namespace Best.HTTP.Shared.Databases.MetadataIndexFinders;

public sealed class FindDeletedMetadataIndexFinder : IEmptyMetadataIndexFinder<MetadataType>
{

	public FindDeletedMetadataIndexFinder`1() { }

	public override int FindFreeIndex(List<MetadataType> metadatas) { }

}

