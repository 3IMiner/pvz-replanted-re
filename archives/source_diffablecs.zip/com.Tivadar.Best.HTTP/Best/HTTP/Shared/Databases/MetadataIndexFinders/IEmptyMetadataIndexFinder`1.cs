namespace Best.HTTP.Shared.Databases.MetadataIndexFinders;

public interface IEmptyMetadataIndexFinder
{

	public int FindFreeIndex(List<MetadataType> metadatas) { }

}

