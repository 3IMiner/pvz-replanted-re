namespace Best.HTTP.Shared.Databases.MetadataIndexFinders;

public sealed class DefaultEmptyMetadataIndexFinder : IEmptyMetadataIndexFinder<MetadataType>
{

	public DefaultEmptyMetadataIndexFinder`1() { }

	public override int FindFreeIndex(List<MetadataType> metadatas) { }

}

