namespace Best.HTTP.Shared.Databases;

public sealed class FolderAndFileOptions
{
	public string FolderName; //Field offset: 0x10
	public string DatabaseFolderName; //Field offset: 0x18
	public string MetadataExtension; //Field offset: 0x20
	public string DatabaseExtension; //Field offset: 0x28
	public string DatabaseFreeListExtension; //Field offset: 0x30
	public string HashExtension; //Field offset: 0x38

	public FolderAndFileOptions() { }

}

