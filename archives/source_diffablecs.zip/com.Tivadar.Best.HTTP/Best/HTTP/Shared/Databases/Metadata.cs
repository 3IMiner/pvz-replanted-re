namespace Best.HTTP.Shared.Databases;

public abstract class Metadata
{
	public int Index; //Field offset: 0x10
	public int FilePosition; //Field offset: 0x14
	public int Length; //Field offset: 0x18

	public bool IsDeleted
	{
		 get { } //Length: 17
	}

	protected Metadata() { }

	public bool get_IsDeleted() { }

	public override void LoadFrom(Stream stream) { }

	public void MarkForDelete() { }

	public override void SaveTo(Stream stream) { }

	public virtual string ToString() { }

}

