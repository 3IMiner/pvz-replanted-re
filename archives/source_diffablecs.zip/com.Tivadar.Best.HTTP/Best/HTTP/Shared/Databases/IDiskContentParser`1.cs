namespace Best.HTTP.Shared.Databases;

public interface IDiskContentParser
{

	public void Encode(Stream stream, T content) { }

	public T Parse(Stream stream, int length) { }

}

