namespace Best.HTTP.Shared.Databases;

public struct MetadataStats
{
	public int min; //Field offset: 0x0
	public int max; //Field offset: 0x4
	public int count; //Field offset: 0x8
	public int sum; //Field offset: 0xC

}

