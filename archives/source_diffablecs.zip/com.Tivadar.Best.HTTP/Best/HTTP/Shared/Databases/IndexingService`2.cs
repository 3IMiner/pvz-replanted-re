namespace Best.HTTP.Shared.Databases;

public abstract class IndexingService
{

	protected IndexingService`2() { }

	public override void Clear() { }

	public override IEnumerable<Int32> GetOptimizedIndexes() { }

	public override void Index(MetadataType metadata) { }

	public override void Remove(MetadataType metadata) { }

}

