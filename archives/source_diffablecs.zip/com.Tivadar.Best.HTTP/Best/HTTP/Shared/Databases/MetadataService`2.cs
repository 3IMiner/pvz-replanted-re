namespace Best.HTTP.Shared.Databases;

public abstract class MetadataService
{
	[CompilerGenerated]
	private List<MetadataType> <Metadatas>k__BackingField; //Field offset: 0x0
	[CompilerGenerated]
	private IndexingService<ContentType, MetadataType> <IndexingService>k__BackingField; //Field offset: 0x0
	[CompilerGenerated]
	private IEmptyMetadataIndexFinder<MetadataType> <EmptyMetadataIndexFinder>k__BackingField; //Field offset: 0x0

	public IEmptyMetadataIndexFinder<MetadataType> EmptyMetadataIndexFinder
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		 set { } //Length: 13
	}

	public IndexingService<ContentType, MetadataType> IndexingService
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		 set { } //Length: 13
	}

	public List<MetadataType> Metadatas
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		 set { } //Length: 13
	}

	protected MetadataService`2(IndexingService<ContentType, MetadataType> indexingService, IEmptyMetadataIndexFinder<MetadataType> emptyMetadataIndexFinder) { }

	public override void Clear() { }

	protected MetadataType CreateDefault(ContentType content, int filePos, int length, Action<ContentType, MetadataType> setupCallback) { }

	public override MetadataType CreateFrom(Stream stream) { }

	[CompilerGenerated]
	public IEmptyMetadataIndexFinder<MetadataType> get_EmptyMetadataIndexFinder() { }

	[CompilerGenerated]
	public IndexingService<ContentType, MetadataType> get_IndexingService() { }

	[CompilerGenerated]
	public List<MetadataType> get_Metadatas() { }

	public MetadataStats GetStats() { }

	public void LoadFrom(Stream stream) { }

	public void Remove(MetadataType metadata) { }

	public void SaveTo(Stream stream) { }

	[CompilerGenerated]
	protected void set_EmptyMetadataIndexFinder(IEmptyMetadataIndexFinder<MetadataType> value) { }

	[CompilerGenerated]
	protected void set_IndexingService(IndexingService<ContentType, MetadataType> value) { }

	[CompilerGenerated]
	protected void set_Metadatas(List<MetadataType> value) { }

}

