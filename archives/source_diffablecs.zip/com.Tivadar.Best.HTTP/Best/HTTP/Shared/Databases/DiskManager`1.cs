namespace Best.HTTP.Shared.Databases;

public sealed class DiskManager : IDisposable
{
	[CompilerGenerated]
	private sealed class <>c__16
	{
		public static readonly <>c__16<T, Meta> <>9; //Field offset: 0x0
		public static Comparison<Meta> <>9__16_0; //Field offset: 0x0

		private static <>c__16`1() { }

		public <>c__16`1() { }

		internal int <LoadAll>b__16_0(Meta m1, Meta m2) { }

	}

	private struct CachePointer
	{
		public static readonly CachePointer<T, CacheType> Empty; //Field offset: 0x0
		public int Position; //Field offset: 0x0
		public int Length; //Field offset: 0x0
		public CacheType Content; //Field offset: 0x0

		private static CachePointer`1() { }

		public virtual string ToString() { }

	}

	[CompilerGenerated]
	private int <CacheSize>k__BackingField; //Field offset: 0x0
	private Stream stream; //Field offset: 0x0
	private List<CachePointer`1<T, T>> cache; //Field offset: 0x0
	private IDiskContentParser<T> diskContentParser; //Field offset: 0x0
	private DiskManagerOptions options; //Field offset: 0x0
	private FreeListManager freeListManager; //Field offset: 0x0
	private ReaderWriterLockSlim rwLock; //Field offset: 0x0

	public private int CacheSize
	{
		[CompilerGenerated]
		 get { } //Length: 4
		[CompilerGenerated]
		private set { } //Length: 4
	}

	public DiskManager`1(Stream stream, Stream freeListStream, IDiskContentParser<T> contentParser, DiskManagerOptions options) { }

	private void AddToCache(T parsedContent, int pos, int length) { }

	public ValueTuple<Int32, Int32> Append(T content) { }

	public BufferSegment CalculateHash() { }

	public void Clear() { }

	public void Delete(Metadata metadata) { }

	public override void Dispose() { }

	[CompilerGenerated]
	public int get_CacheSize() { }

	private CachePointer<T, T> GetCached(int position) { }

	public T Load(Metadata metadata) { }

	public List<KeyValuePair`2<Meta, T>> LoadAll(List<Meta> metadatas) { }

	public void Save() { }

	public void SaveChanged(Metadata metadata, T content) { }

	[CompilerGenerated]
	private void set_CacheSize(int value) { }

}

