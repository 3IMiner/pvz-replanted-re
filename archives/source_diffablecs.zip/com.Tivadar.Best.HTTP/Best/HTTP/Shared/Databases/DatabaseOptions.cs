namespace Best.HTTP.Shared.Databases;

public class DatabaseOptions
{
	public string Name; //Field offset: 0x10
	public bool UseHashFile; //Field offset: 0x18
	public DiskManagerOptions DiskManager; //Field offset: 0x20

	public DatabaseOptions(string dbName) { }

}

