namespace Best.HTTP.Shared.Databases.Indexing.Comparers;

public sealed class UInt16Comparer : IComparer<UInt16>
{

	public UInt16Comparer() { }

	public override int Compare(ushort x, ushort y) { }

}

