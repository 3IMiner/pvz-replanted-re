namespace Best.HTTP.Shared.Databases.Indexing.Comparers;

public sealed class Hash128Comparer : IComparer<Hash128>
{

	public Hash128Comparer() { }

	public override int Compare(Hash128 x, Hash128 y) { }

}

