namespace Best.HTTP.Shared.Databases.Indexing;

public enum Side
{
	Left = 0,
	Right = 1,
}

