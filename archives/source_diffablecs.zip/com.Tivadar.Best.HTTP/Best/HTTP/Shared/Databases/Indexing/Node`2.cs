namespace Best.HTTP.Shared.Databases.Indexing;

[DefaultMember("Item")]
public sealed class Node
{
	public Node<KeyT, ValueT> Parent; //Field offset: 0x0
	public Node<KeyT, ValueT> Left; //Field offset: 0x0
	public Node<KeyT, ValueT> Right; //Field offset: 0x0
	[CompilerGenerated]
	private KeyT <Key>k__BackingField; //Field offset: 0x0
	public int Depth; //Field offset: 0x0
	private NoAllocList<ValueT> _item; //Field offset: 0x0

	public int BalanceFactor
	{
		 get { } //Length: 40
	}

	public int ChildCount
	{
		 get { } //Length: 23
	}

	public int Count
	{
		 get { } //Length: 24
	}

	public bool IsRoot
	{
		 get { } //Length: 9
	}

	public ValueT Item
	{
		 get { } //Length: 24
	}

	public private KeyT Key
	{
		[CompilerGenerated]
		 get { } //Length: 11
		[CompilerGenerated]
		private set { } //Length: 8
	}

	public int LeftDepth
	{
		 get { } //Length: 21
	}

	public int RightDepth
	{
		 get { } //Length: 21
	}

	public Node`2(Node<KeyT, ValueT> parent, KeyT key, ValueT value) { }

	public void Add(ValueT value) { }

	public void BubbleUpDepthChange() { }

	public void Clear() { }

	public int get_BalanceFactor() { }

	public int get_ChildCount() { }

	public int get_Count() { }

	public bool get_IsRoot() { }

	public ValueT get_Item(int index) { }

	[CompilerGenerated]
	public KeyT get_Key() { }

	public int get_LeftDepth() { }

	public int get_RightDepth() { }

	public bool Remove(ValueT value) { }

	[CompilerGenerated]
	private void set_Key(KeyT value) { }

	public List<ValueT> ToList() { }

	public virtual string ToString() { }

}

