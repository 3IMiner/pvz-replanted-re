namespace Best.HTTP.Shared.Databases.Indexing;

[DefaultMember("Item")]
public struct NoAllocList
{
	private T _value; //Field offset: 0x0
	private bool _hasValue; //Field offset: 0x0
	private List<T> _values; //Field offset: 0x0

	public int Count
	{
		 get { } //Length: 64
	}

	public T Item
	{
		 get { } //Length: 93
		 set { } //Length: 225
	}

	public NoAllocList`1(T value) { }

	public void Add(T item) { }

	public void Clear() { }

	public bool Contains(T item) { }

	public int get_Count() { }

	public T get_Item(int index) { }

	public bool Remove(T item) { }

	public void RemoveAt(int index) { }

	public void set_Item(int index, T value) { }

}

