namespace Best.HTTP.Shared.Databases.Indexing.Comparers;

public sealed class ByteArrayComparer : IComparer<Byte[]>
{

	public ByteArrayComparer() { }

	public override int Compare(Byte[] x, Byte[] y) { }

}

