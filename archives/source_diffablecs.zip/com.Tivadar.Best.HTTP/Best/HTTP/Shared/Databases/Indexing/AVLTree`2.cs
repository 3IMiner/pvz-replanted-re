namespace Best.HTTP.Shared.Databases.Indexing;

public sealed class AVLTree
{
	[CompilerGenerated]
	private sealed class <WalkHorizontal>d__27 : IEnumerable<Value>, IEnumerable, IEnumerator<Value>, IEnumerator, IDisposable
	{
		private int <>1__state; //Field offset: 0x0
		private Value <>2__current; //Field offset: 0x0
		private int <>l__initialThreadId; //Field offset: 0x0
		public AVLTree<Key, Value> <>4__this; //Field offset: 0x0
		private Queue<Node`2<Key, Value>> <toWalk>5__2; //Field offset: 0x0
		private Node<Key, Value> <current>5__3; //Field offset: 0x0
		private int <i>5__4; //Field offset: 0x0

		private override Value System.Collections.Generic.IEnumerator<Value>.Current
		{
			[DebuggerHidden]
			private get { } //Length: 4
		}

		private override object System.Collections.IEnumerator.Current
		{
			[DebuggerHidden]
			private get { } //Length: 41
		}

		[DebuggerHidden]
		public <WalkHorizontal>d__27(int <>1__state) { }

		private override bool MoveNext() { }

		[DebuggerHidden]
		private override IEnumerator<Value> System.Collections.Generic.IEnumerable<Value>.GetEnumerator() { }

		[DebuggerHidden]
		private override Value System.Collections.Generic.IEnumerator<Value>.get_Current() { }

		[DebuggerHidden]
		private override IEnumerator System.Collections.IEnumerable.GetEnumerator() { }

		[DebuggerHidden]
		private override object System.Collections.IEnumerator.get_Current() { }

		[DebuggerHidden]
		private override void System.Collections.IEnumerator.Reset() { }

		[DebuggerHidden]
		private override void System.IDisposable.Dispose() { }

	}

	[CompilerGenerated]
	private int <ElemCount>k__BackingField; //Field offset: 0x0
	[CompilerGenerated]
	private int <NodeCount>k__BackingField; //Field offset: 0x0
	public IComparer<Key> Comparer; //Field offset: 0x0
	[CompilerGenerated]
	private Node<Key, Value> <RootNode>k__BackingField; //Field offset: 0x0
	private List<Side> path; //Field offset: 0x0

	public private int ElemCount
	{
		[CompilerGenerated]
		 get { } //Length: 4
		[CompilerGenerated]
		private set { } //Length: 4
	}

	public private int NodeCount
	{
		[CompilerGenerated]
		 get { } //Length: 4
		[CompilerGenerated]
		private set { } //Length: 4
	}

	public private Node<Key, Value> RootNode
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 13
	}

	public AVLTree`2(IComparer<Key> comparer) { }

	public void Add(Key key, Value item, bool clearValues = false) { }

	public void Clear() { }

	public bool ContainsKey(Key key) { }

	public List<Value> Find(Key key) { }

	private Node<Key, Value> FindMax(Node<Key, Value> node) { }

	private Node<Key, Value> FindMin(Node<Key, Value> node) { }

	[CompilerGenerated]
	public int get_ElemCount() { }

	[CompilerGenerated]
	public int get_NodeCount() { }

	[CompilerGenerated]
	public Node<Key, Value> get_RootNode() { }

	private Node<Key, Value> RebalanceForRemoval(Node<Key, Value> removedParentNode, Side side) { }

	private Node<Key, Value> RebalanceFrom(Node<Key, Value> newNode) { }

	public List<Value> Remove(Key key) { }

	public void Remove(Key key, Value value) { }

	private void RemoveNode(Node<Key, Value> node) { }

	private Node<Key, Value> RotateLeft(Node<Key, Value> current) { }

	private Node<Key, Value> RotateRight(Node<Key, Value> current) { }

	[CompilerGenerated]
	private void set_ElemCount(int value) { }

	[CompilerGenerated]
	private void set_NodeCount(int value) { }

	[CompilerGenerated]
	private void set_RootNode(Node<Key, Value> value) { }

	public bool TestBalance() { }

	private bool TestBalance(Node<Key, Value> node) { }

	[IteratorStateMachine(typeof(<WalkHorizontal>d__27))]
	public IEnumerable<Value> WalkHorizontal() { }

}

