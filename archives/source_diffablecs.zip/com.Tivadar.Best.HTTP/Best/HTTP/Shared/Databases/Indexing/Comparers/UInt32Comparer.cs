namespace Best.HTTP.Shared.Databases.Indexing.Comparers;

public sealed class UInt32Comparer : IComparer<UInt32>
{

	public UInt32Comparer() { }

	public override int Compare(uint x, uint y) { }

}

