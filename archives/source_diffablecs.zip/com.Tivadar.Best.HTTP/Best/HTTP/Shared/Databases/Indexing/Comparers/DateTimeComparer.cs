namespace Best.HTTP.Shared.Databases.Indexing.Comparers;

public sealed class DateTimeComparer : IComparer<DateTime>
{

	public DateTimeComparer() { }

	public override int Compare(DateTime x, DateTime y) { }

}

