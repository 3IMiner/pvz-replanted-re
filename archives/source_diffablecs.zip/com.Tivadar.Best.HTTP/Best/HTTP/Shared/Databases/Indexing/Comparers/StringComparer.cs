namespace Best.HTTP.Shared.Databases.Indexing.Comparers;

public sealed class StringComparer : IComparer<String>
{

	public StringComparer() { }

	public override int Compare(string x, string y) { }

}

