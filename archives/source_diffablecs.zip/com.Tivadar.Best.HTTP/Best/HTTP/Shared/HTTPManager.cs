namespace Best.HTTP.Shared;

[Il2CppEagerStaticClassConstruction]
public static class HTTPManager
{
	[CompilerGenerated]
	private sealed class <>c
	{
		public static readonly <>c <>9; //Field offset: 0x0
		public static Action<HTTPRequest> <>9__42_0; //Field offset: 0x8

		private static <>c() { }

		public <>c() { }

		internal void <SendRequest>b__42_0(HTTPRequest request) { }

	}

	public static OnSetupFinishedDelegate OnSetupFinished; //Field offset: 0x0
	[CompilerGenerated]
	private static HostSettingsManager <PerHostSettings>k__BackingField; //Field offset: 0x8
	[CompilerGenerated]
	private static DateTime <CurrentFrameDateTime>k__BackingField; //Field offset: 0x10
	[CompilerGenerated]
	private static Func<String> <RootSaveFolderProvider>k__BackingField; //Field offset: 0x18
	private static ProxyDetector _proxyDetector; //Field offset: 0x20
	[CompilerGenerated]
	private static Proxy <Proxy>k__BackingField; //Field offset: 0x28
	private static HeartbeatManager heartbeats; //Field offset: 0x30
	private static ILogger logger; //Field offset: 0x38
	public static IIOService IOService; //Field offset: 0x40
	public static string UserAgent; //Field offset: 0x48
	private static bool _isQuitting; //Field offset: 0x50
	public static string RootFolderName; //Field offset: 0x58
	private static HTTPCache _httpCache; //Field offset: 0x60
	private static bool IsSetupCalled; //Field offset: 0x68
	private static long _lastNetworkBytesSent; //Field offset: 0x70
	private static long _lastNetworkBytesReceived; //Field offset: 0x78
	private static BufferPoolStats bufferPoolStats; //Field offset: 0x80

	public private static DateTime CurrentFrameDateTime
	{
		[CompilerGenerated]
		 get { } //Length: 79
		[CompilerGenerated]
		private set { } //Length: 85
	}

	public static HeartbeatManager Heartbeats
	{
		 get { } //Length: 246
	}

	public private static bool IsQuitting
	{
		 get { } //Length: 90
		private set { } //Length: 86
	}

	public static HTTPCache LocalCache
	{
		 get { } //Length: 79
		 set { } //Length: 192
	}

	public static ILogger Logger
	{
		 get { } //Length: 297
		 set { } //Length: 110
	}

	public private static HostSettingsManager PerHostSettings
	{
		[CompilerGenerated]
		 get { } //Length: 79
		[CompilerGenerated]
		private set { } //Length: 110
	}

	public static Proxy Proxy
	{
		[CompilerGenerated]
		 get { } //Length: 79
		[CompilerGenerated]
		 set { } //Length: 110
	}

	public static ProxyDetector ProxyDetector
	{
		 get { } //Length: 79
		 set { } //Length: 161
	}

	public static Func<String> RootSaveFolderProvider
	{
		[CompilerGenerated]
		 get { } //Length: 79
		[CompilerGenerated]
		 set { } //Length: 110
	}

	private static HTTPManager() { }

	public static void AbortAll() { }

	[CompilerGenerated]
	public static DateTime get_CurrentFrameDateTime() { }

	public static HeartbeatManager get_Heartbeats() { }

	public static bool get_IsQuitting() { }

	public static HTTPCache get_LocalCache() { }

	public static ILogger get_Logger() { }

	[CompilerGenerated]
	public static HostSettingsManager get_PerHostSettings() { }

	[CompilerGenerated]
	public static Proxy get_Proxy() { }

	public static ProxyDetector get_ProxyDetector() { }

	[CompilerGenerated]
	public static Func<String> get_RootSaveFolderProvider() { }

	public static string GetRootSaveFolder() { }

	public static void OnQuit() { }

	public static void OnUpdate() { }

	internal static HTTPRequest SendRequest(HTTPRequest request) { }

	[CompilerGenerated]
	private static void set_CurrentFrameDateTime(DateTime value) { }

	private static void set_IsQuitting(bool value) { }

	public static void set_LocalCache(HTTPCache value) { }

	public static void set_Logger(ILogger value) { }

	[CompilerGenerated]
	private static void set_PerHostSettings(HostSettingsManager value) { }

	[CompilerGenerated]
	public static void set_Proxy(Proxy value) { }

	public static void set_ProxyDetector(ProxyDetector value) { }

	[CompilerGenerated]
	public static void set_RootSaveFolderProvider(Func<String> value) { }

	public static void Setup() { }

}

