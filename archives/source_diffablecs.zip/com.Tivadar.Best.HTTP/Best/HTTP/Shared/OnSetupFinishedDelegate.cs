namespace Best.HTTP.Shared;

public sealed class OnSetupFinishedDelegate : MulticastDelegate
{

	public OnSetupFinishedDelegate(object object, IntPtr method) { }

	public override IAsyncResult BeginInvoke(AsyncCallback callback, object object) { }

	public override void EndInvoke(IAsyncResult result) { }

	public override void Invoke() { }

}

