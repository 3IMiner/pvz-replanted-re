namespace Best.HTTP.Proxies;

internal sealed class HTTPProxyResponse : IContentConsumer
{
	private enum ContentDeliveryMode
	{
		Raw = 0,
		RawUnknownLength = 1,
		Chunked = 2,
	}

	internal enum PeekableReadState
	{
		StatusLine = 0,
		Headers = 1,
		PrepareForContent = 2,
		ContentSetup = 3,
		RawContent = 4,
		Content = 5,
		Finished = 6,
	}

	private enum ReadChunkedStates
	{
		ReadChunkLength = 0,
		ReadChunk = 1,
		ReadTrailingCRLF = 2,
		ReadTrailingHeaders = 3,
	}

	[CompilerGenerated]
	private int <VersionMajor>k__BackingField; //Field offset: 0x10
	[CompilerGenerated]
	private int <VersionMinor>k__BackingField; //Field offset: 0x14
	[CompilerGenerated]
	private int <StatusCode>k__BackingField; //Field offset: 0x18
	[CompilerGenerated]
	private string <Message>k__BackingField; //Field offset: 0x20
	[CompilerGenerated]
	private Dictionary<String, List`1<String>> <Headers>k__BackingField; //Field offset: 0x28
	[CompilerGenerated]
	private PeekableContentProviderStream <ContentProvider>k__BackingField; //Field offset: 0x30
	private PeekableReadState _readState; //Field offset: 0x38
	private ContentDeliveryMode _deliveryMode; //Field offset: 0x3C
	private ProxyConnectParameters _parameters; //Field offset: 0x40
	private long _expectedLength; //Field offset: 0x80
	private BufferPoolMemoryStream _output; //Field offset: 0x88
	private int _chunkLength; //Field offset: 0x90
	private ReadChunkedStates _readChunkedState; //Field offset: 0x94
	private long _downloaded; //Field offset: 0x98
	public Action<ProxyConnectParameters, HTTPProxyResponse, Exception> OnFinished; //Field offset: 0xA0
	[CompilerGenerated]
	private string <DataAsText>k__BackingField; //Field offset: 0xA8

	public private override PeekableContentProviderStream ContentProvider
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 13
	}

	public private string DataAsText
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		private set { } //Length: 19
	}

	public private Dictionary<String, List`1<String>> Headers
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 13
	}

	public private string Message
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 13
	}

	public private PeekableReadState ReadState
	{
		 get { } //Length: 4
		private set { } //Length: 278
	}

	public private int StatusCode
	{
		[CompilerGenerated]
		 get { } //Length: 4
		[CompilerGenerated]
		private set { } //Length: 4
	}

	public private int VersionMajor
	{
		[CompilerGenerated]
		 get { } //Length: 4
		[CompilerGenerated]
		private set { } //Length: 4
	}

	public private int VersionMinor
	{
		[CompilerGenerated]
		 get { } //Length: 4
		[CompilerGenerated]
		private set { } //Length: 4
	}

	public HTTPProxyResponse(ProxyConnectParameters parameters) { }

	public void AddHeader(string name, string value) { }

	private void CallFinished(Exception error) { }

	[CompilerGenerated]
	public override PeekableContentProviderStream get_ContentProvider() { }

	[CompilerGenerated]
	public string get_DataAsText() { }

	[CompilerGenerated]
	public Dictionary<String, List`1<String>> get_Headers() { }

	[CompilerGenerated]
	public string get_Message() { }

	public PeekableReadState get_ReadState() { }

	[CompilerGenerated]
	public int get_StatusCode() { }

	[CompilerGenerated]
	public int get_VersionMajor() { }

	[CompilerGenerated]
	public int get_VersionMinor() { }

	public string GetFirstHeaderValue(string name) { }

	public List<String> GetHeaderValues(string name) { }

	public bool HasHeaderWithValue(string headerName, string value) { }

	private bool IsNewLinePresent(PeekableStream peekable) { }

	public override void OnConnectionClosed() { }

	public override void OnContent() { }

	public override void OnError(Exception ex) { }

	private void PostProcessContent() { }

	private void ProcessChunk(BufferSegment chunk) { }

	private void ProcessReadChunked(PeekableStream peekable) { }

	private void ProcessReadHeaders(PeekableStream peekable, PeekableReadState targetState) { }

	private void ProcessReadRaw(PeekableStream peekable) { }

	private void ProcessReadRawUnknownLength(PeekableStream peekable) { }

	[CompilerGenerated]
	private void set_ContentProvider(PeekableContentProviderStream value) { }

	[CompilerGenerated]
	private void set_DataAsText(string value) { }

	[CompilerGenerated]
	private void set_Headers(Dictionary<String, List`1<String>> value) { }

	[CompilerGenerated]
	private void set_Message(string value) { }

	private void set_ReadState(PeekableReadState value) { }

	[CompilerGenerated]
	private void set_StatusCode(int value) { }

	[CompilerGenerated]
	private void set_VersionMajor(int value) { }

	[CompilerGenerated]
	private void set_VersionMinor(int value) { }

	public override void SetBinding(PeekableContentProviderStream contentProvider) { }

	public virtual string ToString() { }

	private bool TryReadChunkLength(PeekableStream peekable, out int result) { }

	public override void UnsetBinding() { }

	private void VerboseLogging(string v) { }

}

