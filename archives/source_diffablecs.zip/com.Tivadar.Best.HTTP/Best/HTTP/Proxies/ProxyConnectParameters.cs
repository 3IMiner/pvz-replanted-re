namespace Best.HTTP.Proxies;

public struct ProxyConnectParameters
{
	public const int MaxAuthenticationAttempts = 1; //Field offset: 0x0
	public Proxy proxy; //Field offset: 0x0
	public PeekableContentProviderStream stream; //Field offset: 0x8
	public Uri uri; //Field offset: 0x10
	public CancellationToken token; //Field offset: 0x18
	public int AuthenticationAttempts; //Field offset: 0x20
	public bool createTunel; //Field offset: 0x24
	public LoggingContext context; //Field offset: 0x28
	public Action<ProxyConnectParameters> OnSuccess; //Field offset: 0x30
	public Action<ProxyConnectParameters, Exception, Boolean> OnError; //Field offset: 0x38

}

