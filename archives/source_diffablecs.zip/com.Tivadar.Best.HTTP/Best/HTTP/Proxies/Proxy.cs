namespace Best.HTTP.Proxies;

public abstract class Proxy
{
	[CompilerGenerated]
	private Uri <Address>k__BackingField; //Field offset: 0x10
	[CompilerGenerated]
	private Credentials <Credentials>k__BackingField; //Field offset: 0x18
	[CompilerGenerated]
	private List<String> <Exceptions>k__BackingField; //Field offset: 0x20

	public Uri Address
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		 set { } //Length: 13
	}

	public Credentials Credentials
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		 set { } //Length: 13
	}

	public List<String> Exceptions
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		 set { } //Length: 13
	}

	internal Proxy(Uri address, Credentials credentials) { }

	internal abstract void BeginConnect(ProxyConnectParameters parameters) { }

	[CompilerGenerated]
	public Uri get_Address() { }

	[CompilerGenerated]
	public Credentials get_Credentials() { }

	[CompilerGenerated]
	public List<String> get_Exceptions() { }

	public abstract string GetRequestPath(Uri uri) { }

	[CompilerGenerated]
	public void set_Address(Uri value) { }

	[CompilerGenerated]
	public void set_Credentials(Credentials value) { }

	[CompilerGenerated]
	public void set_Exceptions(List<String> value) { }

	internal abstract bool SetupRequest(HTTPRequest request) { }

	public bool UseProxyForAddress(Uri address) { }

}

