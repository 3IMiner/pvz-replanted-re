namespace Best.HTTP.Proxies.Implementations;

internal sealed class SOCKSV5Negotiator : IContentConsumer
{
	private enum NegotiationStates
	{
		MethodSelection = 0,
		ExpectAuthenticationResponse = 1,
		ConnectResponse = 2,
	}

	[CompilerGenerated]
	private PeekableContentProviderStream <ContentProvider>k__BackingField; //Field offset: 0x10
	private NegotiationStates _state; //Field offset: 0x18
	private SOCKSProxy _proxy; //Field offset: 0x20
	private ProxyConnectParameters _parameters; //Field offset: 0x28

	public private override PeekableContentProviderStream ContentProvider
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 13
	}

	public SOCKSV5Negotiator(SOCKSProxy proxy, ProxyConnectParameters parameters) { }

	private void CallOnError(Exception ex) { }

	private void CallOnSuccess() { }

	[CompilerGenerated]
	public override PeekableContentProviderStream get_ContentProvider() { }

	public override void OnConnectionClosed() { }

	public override void OnContent() { }

	public override void OnError(Exception ex) { }

	private void SendConnect() { }

	private void SendHandshake() { }

	[CompilerGenerated]
	private void set_ContentProvider(PeekableContentProviderStream value) { }

	public override void SetBinding(PeekableContentProviderStream contentProvider) { }

	public override void UnsetBinding() { }

	private void WriteBytes(Byte[] buffer, ref int count, Byte[] bytes) { }

	private void WriteString(Byte[] buffer, ref int count, string str) { }

}

