namespace Best.HTTP.Proxies.Implementations;

internal enum SOCKSMethods
{
	NoAuthenticationRequired = 0,
	GSSAPI = 1,
	UsernameAndPassword = 2,
	NoAcceptableMethods = 255,
}

