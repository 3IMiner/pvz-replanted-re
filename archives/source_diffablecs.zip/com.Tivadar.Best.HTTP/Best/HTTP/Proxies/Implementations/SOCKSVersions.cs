namespace Best.HTTP.Proxies.Implementations;

internal enum SOCKSVersions
{
	Unknown = 0,
	V5 = 5,
}

