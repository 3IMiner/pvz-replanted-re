namespace Best.HTTP.Proxies.Implementations;

internal enum SOCKSAddressTypes
{
	IPV4 = 0,
	DomainName = 3,
	IPv6 = 4,
}

