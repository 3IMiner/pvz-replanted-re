namespace Best.HTTP.Proxies.Autodetect;

public sealed class FrameworkProxyDetector : IProxyDetector
{

	public FrameworkProxyDetector() { }

	private override Proxy Best.HTTP.Proxies.Autodetect.IProxyDetector.GetProxy(HTTPRequest request) { }

	private Proxy SetExceptionList(Proxy proxy, WebProxy detectedProxy) { }

}

