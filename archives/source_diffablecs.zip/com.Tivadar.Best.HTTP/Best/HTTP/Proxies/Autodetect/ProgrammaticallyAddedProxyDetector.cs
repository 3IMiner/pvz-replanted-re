namespace Best.HTTP.Proxies.Autodetect;

public sealed class ProgrammaticallyAddedProxyDetector : IProxyDetector
{

	public ProgrammaticallyAddedProxyDetector() { }

	private override Proxy Best.HTTP.Proxies.Autodetect.IProxyDetector.GetProxy(HTTPRequest request) { }

}

