namespace Best.HTTP.Proxies.Autodetect;

public enum ProxyDetectionMode
{
	Continuous = 0,
	CacheFirstFound = 1,
}

