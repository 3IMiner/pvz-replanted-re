namespace Best.HTTP.Proxies.Autodetect;

public sealed class ProxyDetector
{
	private IProxyDetector[] _proxyDetectors; //Field offset: 0x10
	private ProxyDetectionMode _detectionMode; //Field offset: 0x18
	private bool _attached; //Field offset: 0x1C

	public ProxyDetector() { }

	public ProxyDetector(ProxyDetectionMode detectionMode) { }

	public ProxyDetector(ProxyDetectionMode detectionMode, IProxyDetector[] proxyDetectors) { }

	public void Detach() { }

	public static IProxyDetector[] GetDefaultDetectors() { }

	private void OnRequestEvent(RequestEventInfo event) { }

	public void Reattach() { }

}

