namespace Best.HTTP.Proxies.Autodetect;

public sealed class EnvironmentProxyDetector : IProxyDetector
{
	private Proxy _cachedProxy; //Field offset: 0x10

	public EnvironmentProxyDetector() { }

	private override Proxy Best.HTTP.Proxies.Autodetect.IProxyDetector.GetProxy(HTTPRequest request) { }

	private string GetEnv(string key) { }

}

