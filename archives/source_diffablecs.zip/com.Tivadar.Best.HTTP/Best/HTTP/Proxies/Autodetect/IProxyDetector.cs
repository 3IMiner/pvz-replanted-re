namespace Best.HTTP.Proxies.Autodetect;

public interface IProxyDetector
{

	public Proxy GetProxy(HTTPRequest request) { }

}

