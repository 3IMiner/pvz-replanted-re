namespace Best.HTTP.Proxies;

public sealed class HTTPProxy : Proxy
{
	[CompilerGenerated]
	private bool <IsTransparent>k__BackingField; //Field offset: 0x28
	[CompilerGenerated]
	private bool <SendWholeUri>k__BackingField; //Field offset: 0x29
	[CompilerGenerated]
	private bool <NonTransparentForHTTPS>k__BackingField; //Field offset: 0x2A

	public bool IsTransparent
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		 set { } //Length: 4
	}

	public bool NonTransparentForHTTPS
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		 set { } //Length: 4
	}

	public bool SendWholeUri
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		 set { } //Length: 4
	}

	public HTTPProxy(Uri address) { }

	public HTTPProxy(Uri address, Credentials credentials) { }

	public HTTPProxy(Uri address, Credentials credentials, bool isTransparent) { }

	public HTTPProxy(Uri address, Credentials credentials, bool isTransparent, bool sendWholeUri) { }

	public HTTPProxy(Uri address, Credentials credentials, bool isTransparent, bool sendWholeUri, bool nonTransparentForHTTPS) { }

	internal virtual void BeginConnect(ProxyConnectParameters parameters) { }

	[CompilerGenerated]
	public bool get_IsTransparent() { }

	[CompilerGenerated]
	public bool get_NonTransparentForHTTPS() { }

	[CompilerGenerated]
	public bool get_SendWholeUri() { }

	public virtual string GetRequestPath(Uri uri) { }

	private void OnProxyResponse(ProxyConnectParameters connectParameters, HTTPProxyResponse resp, Exception error) { }

	[CompilerGenerated]
	public void set_IsTransparent(bool value) { }

	[CompilerGenerated]
	public void set_NonTransparentForHTTPS(bool value) { }

	[CompilerGenerated]
	public void set_SendWholeUri(bool value) { }

	internal virtual bool SetupRequest(HTTPRequest request) { }

}

