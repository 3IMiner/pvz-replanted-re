namespace Best.HTTP.Proxies;

public sealed class SOCKSProxy : Proxy
{

	public SOCKSProxy(Uri address, Credentials credentials) { }

	internal virtual void BeginConnect(ProxyConnectParameters parameters) { }

	public virtual string GetRequestPath(Uri uri) { }

	internal virtual bool SetupRequest(HTTPRequest request) { }

}

