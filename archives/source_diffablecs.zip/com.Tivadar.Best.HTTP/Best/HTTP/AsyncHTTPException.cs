namespace Best.HTTP;

public sealed class AsyncHTTPException : Exception
{
	public readonly int StatusCode; //Field offset: 0x90
	public readonly string Content; //Field offset: 0x98

	public AsyncHTTPException(string message) { }

	public AsyncHTTPException(string message, Exception innerException) { }

	public AsyncHTTPException(int statusCode, string message, string content) { }

	public virtual string ToString() { }

}

