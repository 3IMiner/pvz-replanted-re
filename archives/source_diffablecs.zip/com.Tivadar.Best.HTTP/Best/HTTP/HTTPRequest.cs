namespace Best.HTTP;

public sealed class HTTPRequest : IEnumerator
{
	public static readonly String[] MethodNames; //Field offset: 0x0
	[CompilerGenerated]
	private HTTPMethods <MethodType>k__BackingField; //Field offset: 0x10
	[CompilerGenerated]
	private Uri <Uri>k__BackingField; //Field offset: 0x18
	[CompilerGenerated]
	private HTTPResponse <Response>k__BackingField; //Field offset: 0x20
	public DownloadSettings DownloadSettings; //Field offset: 0x28
	public UploadSettings UploadSettings; //Field offset: 0x30
	public TimeoutSettings TimeoutSettings; //Field offset: 0x38
	public RetrySettings RetrySettings; //Field offset: 0x40
	public ProxySettings ProxySettings; //Field offset: 0x48
	[CompilerGenerated]
	private RedirectSettings <RedirectSettings>k__BackingField; //Field offset: 0x50
	[CompilerGenerated]
	private OnRequestFinishedDelegate <Callback>k__BackingField; //Field offset: 0x58
	[CompilerGenerated]
	private CancellationTokenSource <CancellationTokenSource>k__BackingField; //Field offset: 0x60
	public Action<HTTPRequest> OnCancellationRequested; //Field offset: 0x68
	[CompilerGenerated]
	private Exception <Exception>k__BackingField; //Field offset: 0x70
	[CompilerGenerated]
	private object <Tag>k__BackingField; //Field offset: 0x78
	private HTTPRequestStates _state; //Field offset: 0x80
	[CompilerGenerated]
	private TimingCollector <Timing>k__BackingField; //Field offset: 0x88
	public IAuthenticator Authenticator; //Field offset: 0x90
	[CompilerGenerated]
	private LoggingContext <Context>k__BackingField; //Field offset: 0x98
	[CompilerGenerated]
	private Dictionary<String, List`1<String>> <Headers>k__BackingField; //Field offset: 0xA0

	public OnRequestFinishedDelegate Callback
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		 set { } //Length: 13
	}

	internal CancellationTokenSource CancellationTokenSource
	{
		[CompilerGenerated]
		internal get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 13
	}

	public private LoggingContext Context
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		private set { } //Length: 19
	}

	public override object Current
	{
		 get { } //Length: 3
	}

	public HostKey CurrentHostKey
	{
		 get { } //Length: 45
	}

	public Uri CurrentUri
	{
		 get { } //Length: 42
	}

	public internal Exception Exception
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		internal set { } //Length: 13
	}

	private Dictionary<String, List`1<String>> Headers
	{
		[CompilerGenerated]
		private get { } //Length: 8
		[CompilerGenerated]
		private set { } //Length: 19
	}

	public bool IsCancellationRequested
	{
		 get { } //Length: 21
	}

	public HTTPMethods MethodType
	{
		[CompilerGenerated]
		 get { } //Length: 4
		[CompilerGenerated]
		 set { } //Length: 4
	}

	public private RedirectSettings RedirectSettings
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 13
	}

	public HTTPResponse Response
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		 set { } //Length: 13
	}

	public internal HTTPRequestStates State
	{
		 get { } //Length: 25
		internal set { } //Length: 560
	}

	public object Tag
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		 set { } //Length: 13
	}

	public private TimingCollector Timing
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		private set { } //Length: 19
	}

	public Uri Uri
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		 set { } //Length: 13
	}

	private static HTTPRequest() { }

	public HTTPRequest(Uri uri, HTTPMethods methodType, OnRequestFinishedDelegate callback) { }

	public HTTPRequest(Uri uri, HTTPMethods methodType) { }

	public HTTPRequest(Uri uri, OnRequestFinishedDelegate callback) { }

	public HTTPRequest(Uri uri) { }

	public HTTPRequest(string url, HTTPMethods methodType, OnRequestFinishedDelegate callback) { }

	public HTTPRequest(string url, HTTPMethods methodType) { }

	public HTTPRequest(string url, OnRequestFinishedDelegate callback) { }

	public HTTPRequest(string url) { }

	public void Abort() { }

	public void AddHeader(string name, string value) { }

	public void Clear() { }

	public static HTTPRequest CreateGet(string url) { }

	public static HTTPRequest CreateGet(Uri uri, OnRequestFinishedDelegate callback) { }

	public static HTTPRequest CreateGet(Uri uri) { }

	public static HTTPRequest CreateGet(string url, OnRequestFinishedDelegate callback) { }

	public static HTTPRequest CreatePost(Uri uri, OnRequestFinishedDelegate callback) { }

	public static HTTPRequest CreatePost(string url, OnRequestFinishedDelegate callback) { }

	public static HTTPRequest CreatePost(Uri uri) { }

	public static HTTPRequest CreatePost(string url) { }

	public static HTTPRequest CreatePut(Uri uri) { }

	public static HTTPRequest CreatePut(string url) { }

	public static HTTPRequest CreatePut(string url, OnRequestFinishedDelegate callback) { }

	public static HTTPRequest CreatePut(Uri uri, OnRequestFinishedDelegate callback) { }

	internal void Dispose() { }

	public void EnumerateHeaders(OnHeaderEnumerationDelegate callback, bool callBeforeSendCallback) { }

	[CompilerGenerated]
	public OnRequestFinishedDelegate get_Callback() { }

	[CompilerGenerated]
	internal CancellationTokenSource get_CancellationTokenSource() { }

	[CompilerGenerated]
	public LoggingContext get_Context() { }

	public override object get_Current() { }

	public HostKey get_CurrentHostKey() { }

	public Uri get_CurrentUri() { }

	[CompilerGenerated]
	public Exception get_Exception() { }

	[CompilerGenerated]
	private Dictionary<String, List`1<String>> get_Headers() { }

	public bool get_IsCancellationRequested() { }

	[CompilerGenerated]
	public HTTPMethods get_MethodType() { }

	[CompilerGenerated]
	public RedirectSettings get_RedirectSettings() { }

	[CompilerGenerated]
	public HTTPResponse get_Response() { }

	public HTTPRequestStates get_State() { }

	[CompilerGenerated]
	public object get_Tag() { }

	[CompilerGenerated]
	public TimingCollector get_Timing() { }

	[CompilerGenerated]
	public Uri get_Uri() { }

	public string GetFirstHeaderValue(string name) { }

	public List<String> GetHeaderValues(string name) { }

	public bool HasHeader(string name) { }

	public override bool MoveNext() { }

	internal void Prepare() { }

	public bool RemoveHeader(string name) { }

	public void RemoveHeaders() { }

	internal void RemoveUnsafeHeaders() { }

	public override void Reset() { }

	public HTTPRequest Send() { }

	[CompilerGenerated]
	public void set_Callback(OnRequestFinishedDelegate value) { }

	[CompilerGenerated]
	private void set_CancellationTokenSource(CancellationTokenSource value) { }

	[CompilerGenerated]
	private void set_Context(LoggingContext value) { }

	[CompilerGenerated]
	internal void set_Exception(Exception value) { }

	[CompilerGenerated]
	private void set_Headers(Dictionary<String, List`1<String>> value) { }

	[CompilerGenerated]
	public void set_MethodType(HTTPMethods value) { }

	[CompilerGenerated]
	private void set_RedirectSettings(RedirectSettings value) { }

	[CompilerGenerated]
	public void set_Response(HTTPResponse value) { }

	internal void set_State(HTTPRequestStates value) { }

	[CompilerGenerated]
	public void set_Tag(object value) { }

	[CompilerGenerated]
	private void set_Timing(TimingCollector value) { }

	[CompilerGenerated]
	public void set_Uri(Uri value) { }

	public void SetHeader(string name, string value) { }

	public void SetRangeHeader(long firstBytePos, long lastBytePos) { }

	public void SetRangeHeader(long firstBytePos) { }

	public virtual string ToString() { }

}

