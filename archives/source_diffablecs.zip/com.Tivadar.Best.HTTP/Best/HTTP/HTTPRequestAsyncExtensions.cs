namespace Best.HTTP;

[Extension]
public static class HTTPRequestAsyncExtensions
{
	[CompilerGenerated]
	private sealed class <>c
	{
		public static readonly <>c <>9; //Field offset: 0x0
		public static Action<HTTPRequest, HTTPResponse, TaskCompletionSource`1<HTTPResponse>> <>9__1_0; //Field offset: 0x8
		public static Action<HTTPRequest, HTTPResponse, TaskCompletionSource`1<String>> <>9__2_0; //Field offset: 0x10
		public static Action<HTTPRequest, HTTPResponse, TaskCompletionSource`1<Texture2D>> <>9__3_0; //Field offset: 0x18
		public static Action<HTTPRequest, HTTPResponse, TaskCompletionSource`1<Byte[]>> <>9__4_0; //Field offset: 0x20

		private static <>c() { }

		public <>c() { }

		internal void <GetAsStringAsync>b__2_0(HTTPRequest req, HTTPResponse resp, TaskCompletionSource<String> tcs) { }

		internal void <GetAsTexture2DAsync>b__3_0(HTTPRequest req, HTTPResponse resp, TaskCompletionSource<Texture2D> tcs) { }

		internal void <GetHTTPResponseAsync>b__1_0(HTTPRequest req, HTTPResponse resp, TaskCompletionSource<HTTPResponse> tcs) { }

		internal void <GetRawDataAsync>b__4_0(HTTPRequest req, HTTPResponse resp, TaskCompletionSource<Byte[]> tcs) { }

	}

	[CompilerGenerated]
	private sealed class <>c__5
	{
		public static readonly <>c__5<T> <>9; //Field offset: 0x0
		public static Action<HTTPRequest, HTTPResponse, TaskCompletionSource`1<T>> <>9__5_0; //Field offset: 0x0

		private static <>c__5`1() { }

		public <>c__5`1() { }

		internal void <GetFromJsonResultAsync>b__5_0(HTTPRequest req, HTTPResponse resp, TaskCompletionSource<T> tcs) { }

	}

	[CompilerGenerated]
	private sealed class <>c__6
	{
		public static readonly <>c__6<T> <>9; //Field offset: 0x0
		public static Action<Object> <>9__6_1; //Field offset: 0x0

		private static <>c__6`1() { }

		public <>c__6`1() { }

		internal void <CreateTask>b__6_1(object state) { }

	}

	[CompilerGenerated]
	private sealed class <>c__DisplayClass0_0
	{
		private struct <<GetAssetBundleAsync>b__0>d : IAsyncStateMachine
		{
			public int <>1__state; //Field offset: 0x0
			public AsyncVoidMethodBuilder <>t__builder; //Field offset: 0x8
			public HTTPRequest req; //Field offset: 0x28
			public HTTPResponse resp; //Field offset: 0x30
			public <>c__DisplayClass0_0 <>4__this; //Field offset: 0x38
			public TaskCompletionSource<AssetBundle> tcs; //Field offset: 0x40
			private AssetBundleCreateRequest <bundleLoadOp>5__2; //Field offset: 0x48
			private Awaiter <>u__1; //Field offset: 0x50

			private override void MoveNext() { }

			[DebuggerHidden]
			private override void SetStateMachine(IAsyncStateMachine stateMachine) { }

		}

		public CancellationToken token; //Field offset: 0x10

		public <>c__DisplayClass0_0() { }

		[AsyncStateMachine(typeof(<<GetAssetBundleAsync>b__0>d))]
		internal void <GetAssetBundleAsync>b__0(HTTPRequest req, HTTPResponse resp, TaskCompletionSource<AssetBundle> tcs) { }

	}

	[CompilerGenerated]
	private sealed class <>c__DisplayClass6_0
	{
		public CancellationToken token; //Field offset: 0x0
		public TaskCompletionSource<T> tcs; //Field offset: 0x0
		public Action<HTTPRequest, HTTPResponse, TaskCompletionSource`1<T>> callback; //Field offset: 0x0

		public <>c__DisplayClass6_0`1() { }

		internal void <CreateTask>b__0(HTTPRequest req, HTTPResponse resp) { }

	}


	[EditorBrowsable(EditorBrowsableState::Never (1))]
	public static Exception CreateException(string errorMessage, HTTPResponse resp = null, Exception ex = null) { }

	[EditorBrowsable(EditorBrowsableState::Never (1))]
	public static Task<T> CreateTask(HTTPRequest request, CancellationToken token, Action<HTTPRequest, HTTPResponse, TaskCompletionSource`1<T>> callback) { }

	public static void GenericResponseHandler(HTTPRequest req, HTTPResponse resp, TaskCompletionSource<T> tcs) { }

	[Extension]
	public static Task<AssetBundle> GetAssetBundleAsync(HTTPRequest request, CancellationToken token = null) { }

	[Extension]
	public static Task<String> GetAsStringAsync(HTTPRequest request, CancellationToken token = null) { }

	[Extension]
	public static Task<Texture2D> GetAsTexture2DAsync(HTTPRequest request, CancellationToken token = null) { }

	[Extension]
	public static Task<T> GetFromJsonResultAsync(HTTPRequest request, CancellationToken token = null) { }

	[Extension]
	public static Task<HTTPResponse> GetHTTPResponseAsync(HTTPRequest request, CancellationToken token = null) { }

	[Extension]
	public static Task<Byte[]> GetRawDataAsync(HTTPRequest request, CancellationToken token = null) { }

	[EditorBrowsable(EditorBrowsableState::Never (1))]
	public static void Log(HTTPRequest request, string str) { }

}

