namespace Best.HTTP.Response;

public static class HTTPStatusCodes
{
	public const int Continue = 100; //Field offset: 0x0
	public const int LengthRequired = 411; //Field offset: 0x0
	public const int PreconditionFailed = 412; //Field offset: 0x0
	public const int ContentTooLarge = 413; //Field offset: 0x0
	public const int URITooLong = 414; //Field offset: 0x0
	public const int UnsupportedMediaType = 415; //Field offset: 0x0
	public const int RangeNotSatisfiable = 416; //Field offset: 0x0
	public const int ExpectationFailed = 417; //Field offset: 0x0
	public const int ImATeapot = 418; //Field offset: 0x0
	public const int MisdirectedRequest = 421; //Field offset: 0x0
	public const int UnprocessableContent = 422; //Field offset: 0x0
	public const int Locked = 423; //Field offset: 0x0
	public const int FailedDependency = 424; //Field offset: 0x0
	public const int TooEarly = 425; //Field offset: 0x0
	public const int UpgradeRequired = 426; //Field offset: 0x0
	public const int PreconditionRequired = 428; //Field offset: 0x0
	public const int TooManyRequests = 429; //Field offset: 0x0
	public const int RequestHeaderFieldsTooLarge = 431; //Field offset: 0x0
	public const int UnavailableForLegalReasons = 451; //Field offset: 0x0
	public const int InternalServerError = 500; //Field offset: 0x0
	public const int NotImplemented = 501; //Field offset: 0x0
	public const int BadGateway = 502; //Field offset: 0x0
	public const int ServiceUnavailable = 503; //Field offset: 0x0
	public const int GatewayTimeout = 504; //Field offset: 0x0
	public const int HTTPVersionNotSupported = 505; //Field offset: 0x0
	public const int VariantAlsoNegotiates = 506; //Field offset: 0x0
	public const int InsufficientStorage = 507; //Field offset: 0x0
	public const int LoopDetected = 508; //Field offset: 0x0
	public const int Gone = 410; //Field offset: 0x0
	public const int NotExtended = 510; //Field offset: 0x0
	public const int Conflict = 409; //Field offset: 0x0
	public const int ProxyAuthenticationRequired = 407; //Field offset: 0x0
	public const int SwitchingProtocols = 101; //Field offset: 0x0
	public const int Processing = 102; //Field offset: 0x0
	public const int EarlyHints_Experimental = 103; //Field offset: 0x0
	public const int OK = 200; //Field offset: 0x0
	public const int Created = 201; //Field offset: 0x0
	public const int Accepted = 202; //Field offset: 0x0
	public const int NonAuthoritativeInformation = 203; //Field offset: 0x0
	public const int NoContent = 204; //Field offset: 0x0
	public const int ResetContent = 205; //Field offset: 0x0
	public const int PartialContent = 206; //Field offset: 0x0
	public const int MultiStatus = 207; //Field offset: 0x0
	public const int AlreadyReported = 208; //Field offset: 0x0
	public const int IMUsed = 226; //Field offset: 0x0
	public const int MultipleChoices = 300; //Field offset: 0x0
	public const int MovedPermanently = 301; //Field offset: 0x0
	public const int Found = 302; //Field offset: 0x0
	public const int SeeOther = 303; //Field offset: 0x0
	public const int NotModified = 304; //Field offset: 0x0
	public const int TemporaryRedirect = 307; //Field offset: 0x0
	public const int PermanentRedirect = 308; //Field offset: 0x0
	public const int BadRequest = 400; //Field offset: 0x0
	public const int Unauthorized = 401; //Field offset: 0x0
	public const int PaymentRequired = 402; //Field offset: 0x0
	public const int Forbidden = 403; //Field offset: 0x0
	public const int NotFound = 404; //Field offset: 0x0
	public const int MethodNotAllowed = 405; //Field offset: 0x0
	public const int NotAcceptable = 406; //Field offset: 0x0
	public const int RequestTimeout = 408; //Field offset: 0x0
	public const int NetworkAuthenticationRequired = 511; //Field offset: 0x0

}

