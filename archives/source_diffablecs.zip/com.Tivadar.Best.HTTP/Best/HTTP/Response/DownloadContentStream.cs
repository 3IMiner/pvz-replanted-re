namespace Best.HTTP.Response;

public class DownloadContentStream : Stream
{
	[CompilerGenerated]
	private HTTPResponse <Response>k__BackingField; //Field offset: 0x28
	protected long _length; //Field offset: 0x30
	[CompilerGenerated]
	private long <MaxBuffered>k__BackingField; //Field offset: 0x38
	private bool _isDetached; //Field offset: 0x40
	protected IDownloadContentBufferAvailable _bufferAvailableHandler; //Field offset: 0x48
	protected ConcurrentQueue<BufferSegment> _segments; //Field offset: 0x50
	protected BufferSegment _currentSegment; //Field offset: 0x58
	protected bool _isCompleted; //Field offset: 0x68
	protected ExceptionDispatchInfo _exceptionInfo; //Field offset: 0x70
	private int _isFullCheckCount; //Field offset: 0x78
	protected bool _isDisposed; //Field offset: 0x7C

	public virtual bool CanRead
	{
		 get { } //Length: 3
	}

	public virtual bool CanSeek
	{
		 get { } //Length: 3
	}

	public virtual bool CanWrite
	{
		 get { } //Length: 3
	}

	public Exception CompletedWith
	{
		 get { } //Length: 15
	}

	public override bool IsCompleted
	{
		 get { } //Length: 183
	}

	public bool IsDetached
	{
		 get { } //Length: 5
		 set { } //Length: 280
	}

	public bool IsFull
	{
		 get { } //Length: 41
	}

	public virtual long Length
	{
		 get { } //Length: 11
	}

	public long MaxBuffered
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		 set { } //Length: 5
	}

	public virtual long Position
	{
		 get { } //Length: 62
		 set { } //Length: 62
	}

	public HTTPResponse Response
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		 set { } //Length: 13
	}

	public DownloadContentStream(HTTPResponse response, long maxBuffered, IDownloadContentBufferAvailable bufferAvailableHandler) { }

	internal override void CompleteAdding(Exception error) { }

	protected virtual void Dispose(bool disposing) { }

	internal bool DoFullCheck(int limit) { }

	public void EmergencyIncreaseMaxBuffered() { }

	public virtual void Flush() { }

	public virtual bool get_CanRead() { }

	public virtual bool get_CanSeek() { }

	public virtual bool get_CanWrite() { }

	public Exception get_CompletedWith() { }

	public override bool get_IsCompleted() { }

	public bool get_IsDetached() { }

	public bool get_IsFull() { }

	public virtual long get_Length() { }

	[CompilerGenerated]
	public long get_MaxBuffered() { }

	public virtual long get_Position() { }

	[CompilerGenerated]
	public HTTPResponse get_Response() { }

	public virtual int Read(Byte[] buffer, int offset, int count) { }

	public virtual long Seek(long offset, SeekOrigin origin) { }

	public void set_IsDetached(bool value) { }

	[CompilerGenerated]
	protected void set_MaxBuffered(long value) { }

	public virtual void set_Position(long value) { }

	[CompilerGenerated]
	protected void set_Response(HTTPResponse value) { }

	public virtual void SetLength(long value) { }

	public override bool TryTake(out BufferSegment segment) { }

	public override void Write(BufferSegment segment) { }

	public virtual void Write(Byte[] buffer, int offset, int count) { }

}

