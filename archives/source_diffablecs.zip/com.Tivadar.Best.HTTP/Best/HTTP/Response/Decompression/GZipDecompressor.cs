namespace Best.HTTP.Response.Decompression;

public sealed class GZipDecompressor : IDecompressor, IDisposable
{
	public static bool IsSupported; //Field offset: 0x0
	private BufferPoolMemoryStream decompressorInputStream; //Field offset: 0x10
	private BufferPoolMemoryStream decompressorOutputStream; //Field offset: 0x18
	private GZipStream decompressorStream; //Field offset: 0x20
	private int MinLengthToDecompress; //Field offset: 0x28

	private static GZipDecompressor() { }

	public GZipDecompressor(int minLengthToDecompress) { }

	public override ValueTuple<BufferSegment, Boolean> Decompress(BufferSegment segment, bool forceDecompress, bool dataCanBeLarger, LoggingContext context) { }

	public override void Dispose() { }

	protected virtual void Finalize() { }

}

