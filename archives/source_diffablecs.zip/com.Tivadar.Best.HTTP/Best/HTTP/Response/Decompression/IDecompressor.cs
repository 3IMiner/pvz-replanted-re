namespace Best.HTTP.Response.Decompression;

public interface IDecompressor : IDisposable
{

	public ValueTuple<BufferSegment, Boolean> Decompress(BufferSegment segment, bool forceDecompress, bool dataCanBeLarger, LoggingContext context) { }

}

