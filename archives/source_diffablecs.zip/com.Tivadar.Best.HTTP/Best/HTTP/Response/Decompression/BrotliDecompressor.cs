namespace Best.HTTP.Response.Decompression;

public sealed class BrotliDecompressor : IDecompressor, IDisposable
{
	private BufferSegmentStream decompressorInputStream; //Field offset: 0x10
	private BufferPoolMemoryStream decompressorOutputStream; //Field offset: 0x18
	private BrotliStream decompressorStream; //Field offset: 0x20
	private Byte[] copyBuffer; //Field offset: 0x28
	private int _minLengthToDecompress; //Field offset: 0x30

	public BrotliDecompressor(int minLengthToDecompress) { }

	public override ValueTuple<BufferSegment, Boolean> Decompress(BufferSegment segment, bool forceDecompress, bool dataCanBeLarger, LoggingContext context) { }

	public override void Dispose() { }

	public static bool IsSupported() { }

}

