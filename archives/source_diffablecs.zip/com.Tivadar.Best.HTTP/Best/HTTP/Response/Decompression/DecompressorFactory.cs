namespace Best.HTTP.Response.Decompression;

public static class DecompressorFactory
{
	public const int MinLengthToDecompress = 256; //Field offset: 0x0
	private static string AcceptEncoding; //Field offset: 0x0

	public static IDecompressor GetDecompressor(string encoding, LoggingContext context) { }

	public static void SetupHeaders(HTTPRequest request) { }

}

