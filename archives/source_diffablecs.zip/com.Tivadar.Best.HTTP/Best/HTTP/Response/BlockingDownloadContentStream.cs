namespace Best.HTTP.Response;

public sealed class BlockingDownloadContentStream : DownloadContentStream
{
	private AutoResetEvent _are; //Field offset: 0x80

	public BlockingDownloadContentStream(HTTPResponse response, long maxBuffered, IDownloadContentBufferAvailable bufferAvailableHandler) { }

	internal virtual void CompleteAdding(Exception error) { }

	protected virtual void Dispose(bool disposing) { }

	public virtual int Read(Byte[] buffer, int offset, int count) { }

	public BufferSegment Take() { }

	public BufferSegment Take(TimeSpan timeout) { }

	public virtual bool TryTake(out BufferSegment segment) { }

	private bool WaitForEvent(TimeSpan timeoutTS) { }

	public virtual void Write(BufferSegment segment) { }

}

