namespace Best.HTTP.Cookies;

public sealed class Cookie : IComparable<Cookie>, IEquatable<Cookie>
{
	[CompilerGenerated]
	private sealed class <>c
	{
		public static readonly <>c <>9; //Field offset: 0x0
		public static Func<Char, Boolean> <>9__66_0; //Field offset: 0x8

		private static <>c() { }

		public <>c() { }

		internal bool <ParseCookieHeader>b__66_0(char ch) { }

	}

	private const int Version = 1; //Field offset: 0x0
	[CompilerGenerated]
	private string <Name>k__BackingField; //Field offset: 0x10
	[CompilerGenerated]
	private string <Value>k__BackingField; //Field offset: 0x18
	[CompilerGenerated]
	private DateTime <Date>k__BackingField; //Field offset: 0x20
	[CompilerGenerated]
	private DateTime <LastAccess>k__BackingField; //Field offset: 0x28
	[CompilerGenerated]
	private DateTime <Expires>k__BackingField; //Field offset: 0x30
	[CompilerGenerated]
	private long <MaxAge>k__BackingField; //Field offset: 0x38
	[CompilerGenerated]
	private bool <IsSession>k__BackingField; //Field offset: 0x40
	[CompilerGenerated]
	private string <Domain>k__BackingField; //Field offset: 0x48
	[CompilerGenerated]
	private string <Path>k__BackingField; //Field offset: 0x50
	[CompilerGenerated]
	private bool <IsSecure>k__BackingField; //Field offset: 0x58
	[CompilerGenerated]
	private bool <IsHttpOnly>k__BackingField; //Field offset: 0x59
	[CompilerGenerated]
	private string <SameSite>k__BackingField; //Field offset: 0x60

	public internal DateTime Date
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		internal set { } //Length: 5
	}

	public internal string Domain
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		internal set { } //Length: 13
	}

	public private DateTime Expires
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 5
	}

	public private bool IsHttpOnly
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 4
	}

	public private bool IsSecure
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 4
	}

	public private bool IsSession
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 4
	}

	public DateTime LastAccess
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		 set { } //Length: 5
	}

	public private long MaxAge
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 5
	}

	public private string Name
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 13
	}

	public internal string Path
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		internal set { } //Length: 13
	}

	public private string SameSite
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 13
	}

	public private string Value
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 13
	}

	internal Cookie() { }

	public Cookie(Uri uri, string name, string value, long maxAge = -1, bool isSession = true) { }

	public Cookie(Uri uri, string name, string value, DateTime expires, bool isSession = true) { }

	public Cookie(string name, string value) { }

	public Cookie(string name, string value, string path, string domain) { }

	public Cookie(string name, string value, string path) { }

	public override int CompareTo(Cookie other) { }

	public override bool Equals(Cookie cookie) { }

	public virtual bool Equals(object obj) { }

	[CompilerGenerated]
	public DateTime get_Date() { }

	[CompilerGenerated]
	public string get_Domain() { }

	[CompilerGenerated]
	public DateTime get_Expires() { }

	[CompilerGenerated]
	public bool get_IsHttpOnly() { }

	[CompilerGenerated]
	public bool get_IsSecure() { }

	[CompilerGenerated]
	public bool get_IsSession() { }

	[CompilerGenerated]
	public DateTime get_LastAccess() { }

	[CompilerGenerated]
	public long get_MaxAge() { }

	[CompilerGenerated]
	public string get_Name() { }

	[CompilerGenerated]
	public string get_Path() { }

	[CompilerGenerated]
	public string get_SameSite() { }

	[CompilerGenerated]
	public string get_Value() { }

	public virtual int GetHashCode() { }

	public uint GuessSize() { }

	internal void LoadFrom(BinaryReader stream) { }

	public static Cookie Parse(string header, Uri defaultDomain, LoggingContext context) { }

	private static List<HeaderValue> ParseCookieHeader(string str) { }

	private static string ReadValue(string str, ref int pos) { }

	internal void SaveTo(BinaryWriter stream) { }

	[CompilerGenerated]
	internal void set_Date(DateTime value) { }

	[CompilerGenerated]
	internal void set_Domain(string value) { }

	[CompilerGenerated]
	private void set_Expires(DateTime value) { }

	[CompilerGenerated]
	private void set_IsHttpOnly(bool value) { }

	[CompilerGenerated]
	private void set_IsSecure(bool value) { }

	[CompilerGenerated]
	private void set_IsSession(bool value) { }

	[CompilerGenerated]
	public void set_LastAccess(DateTime value) { }

	[CompilerGenerated]
	private void set_MaxAge(long value) { }

	[CompilerGenerated]
	private void set_Name(string value) { }

	[CompilerGenerated]
	internal void set_Path(string value) { }

	[CompilerGenerated]
	private void set_SameSite(string value) { }

	[CompilerGenerated]
	private void set_Value(string value) { }

	public string ToHeaderValue() { }

	public virtual string ToString() { }

	public bool WillExpireInTheFuture() { }

}

