namespace Best.HTTP.Cookies;

public static class CookieJar
{
	[CompilerGenerated]
	private static uint <MaximumSize>k__BackingField; //Field offset: 0x0
	private const int Version = 1; //Field offset: 0x0
	public static TimeSpan AccessThreshold; //Field offset: 0x8
	public static bool IsSessionOverride; //Field offset: 0x10
	public static bool IsEnabled; //Field offset: 0x11
	private static List<Cookie> Cookies; //Field offset: 0x18
	[CompilerGenerated]
	private static string <CookieFolder>k__BackingField; //Field offset: 0x20
	[CompilerGenerated]
	private static string <LibraryPath>k__BackingField; //Field offset: 0x28
	private static ReaderWriterLockSlim rwLock; //Field offset: 0x30
	private static bool _isSavingSupported; //Field offset: 0x38
	private static bool IsSupportCheckDone; //Field offset: 0x39
	private static bool Loaded; //Field offset: 0x3A
	private static RunOnceOnMainThread _saveLibraryRunner; //Field offset: 0x40

	private static string CookieFolder
	{
		[CompilerGenerated]
		private get { } //Length: 79
		[CompilerGenerated]
		private set { } //Length: 110
	}

	public static bool IsSavingSupported
	{
		 get { } //Length: 622
	}

	private static string LibraryPath
	{
		[CompilerGenerated]
		private get { } //Length: 79
		[CompilerGenerated]
		private set { } //Length: 110
	}

	public static uint MaximumSize
	{
		[CompilerGenerated]
		 get { } //Length: 77
		[CompilerGenerated]
		 set { } //Length: 82
	}

	private static CookieJar() { }

	public static void Clear(string domain) { }

	public static void Clear(TimeSpan olderThan) { }

	public static void Clear() { }

	private static Cookie Find(Cookie cookie, out int idx) { }

	public static List<Cookie> Get(Uri uri) { }

	[CompilerGenerated]
	private static string get_CookieFolder() { }

	public static bool get_IsSavingSupported() { }

	[CompilerGenerated]
	private static string get_LibraryPath() { }

	[CompilerGenerated]
	public static uint get_MaximumSize() { }

	public static List<Cookie> GetAll() { }

	internal static void Load() { }

	internal static void Maintain(bool sendEvent) { }

	internal static void Persist() { }

	public static void Remove(Uri uri, string name) { }

	public static void Set(Uri uri, Cookie cookie) { }

	public static void Set(Cookie cookie) { }

	[CompilerGenerated]
	private static void set_CookieFolder(string value) { }

	[CompilerGenerated]
	private static void set_LibraryPath(string value) { }

	[CompilerGenerated]
	public static void set_MaximumSize(uint value) { }

	internal static bool SetFromRequest(HTTPResponse response) { }

	internal static void SetupFolder() { }

	internal static void SetupRequest(HTTPRequest request) { }

}

