namespace Best.HTTP;

public sealed class OnRequestFinishedDelegate : MulticastDelegate
{

	public OnRequestFinishedDelegate(object object, IntPtr method) { }

	public override IAsyncResult BeginInvoke(HTTPRequest req, HTTPResponse resp, AsyncCallback callback, object object) { }

	public override void EndInvoke(IAsyncResult result) { }

	public override void Invoke(HTTPRequest req, HTTPResponse resp) { }

}

