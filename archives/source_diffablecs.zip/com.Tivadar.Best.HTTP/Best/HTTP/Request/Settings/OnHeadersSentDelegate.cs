namespace Best.HTTP.Request.Settings;

public sealed class OnHeadersSentDelegate : MulticastDelegate
{

	public OnHeadersSentDelegate(object object, IntPtr method) { }

	public override IAsyncResult BeginInvoke(HTTPRequest req, AsyncCallback callback, object object) { }

	public override void EndInvoke(IAsyncResult result) { }

	public override void Invoke(HTTPRequest req) { }

}

