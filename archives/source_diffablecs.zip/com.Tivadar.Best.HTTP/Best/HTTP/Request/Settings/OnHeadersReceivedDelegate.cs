namespace Best.HTTP.Request.Settings;

public sealed class OnHeadersReceivedDelegate : MulticastDelegate
{

	public OnHeadersReceivedDelegate(object object, IntPtr method) { }

	public override IAsyncResult BeginInvoke(HTTPRequest req, HTTPResponse resp, Dictionary<String, List`1<String>> headers, AsyncCallback callback, object object) { }

	public override void EndInvoke(IAsyncResult result) { }

	public override void Invoke(HTTPRequest req, HTTPResponse resp, Dictionary<String, List`1<String>> headers) { }

}

