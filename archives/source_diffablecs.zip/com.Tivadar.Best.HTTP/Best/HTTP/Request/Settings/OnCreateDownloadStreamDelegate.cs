namespace Best.HTTP.Request.Settings;

public sealed class OnCreateDownloadStreamDelegate : MulticastDelegate
{

	public OnCreateDownloadStreamDelegate(object object, IntPtr method) { }

	public override IAsyncResult BeginInvoke(HTTPRequest req, HTTPResponse resp, IDownloadContentBufferAvailable bufferAvailableHandler, AsyncCallback callback, object object) { }

	public override DownloadContentStream EndInvoke(IAsyncResult result) { }

	public override DownloadContentStream Invoke(HTTPRequest req, HTTPResponse resp, IDownloadContentBufferAvailable bufferAvailableHandler) { }

}

