namespace Best.HTTP.Request.Settings;

public sealed class OnUpgradedDelegate : MulticastDelegate
{

	public OnUpgradedDelegate(object object, IntPtr method) { }

	public override IAsyncResult BeginInvoke(HTTPRequest req, HTTPResponse resp, PeekableContentProviderStream contentProvider, AsyncCallback callback, object object) { }

	public override bool EndInvoke(IAsyncResult result) { }

	public override bool Invoke(HTTPRequest req, HTTPResponse resp, PeekableContentProviderStream contentProvider) { }

}

