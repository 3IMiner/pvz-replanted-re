namespace Best.HTTP.Request.Settings;

public class UploadSettings : IDisposable
{
	[CompilerGenerated]
	private sealed class <>c__DisplayClass9_0
	{
		public UploadSettings <>4__this; //Field offset: 0x10
		public HTTPRequest request; //Field offset: 0x18

		public <>c__DisplayClass9_0() { }

		internal void <SetupRequest>b__0() { }

	}

	public int UploadChunkSize; //Field offset: 0x10
	public Stream UploadStream; //Field offset: 0x18
	public bool DisposeStream; //Field offset: 0x20
	public OnProgressDelegate OnUploadProgress; //Field offset: 0x28
	private OnHeadersSentDelegate _onHeadersSent; //Field offset: 0x30
	private bool isDisposed; //Field offset: 0x38

	public event OnHeadersSentDelegate OnHeadersSent
	{
		 add { } //Length: 159
		 remove { } //Length: 159
	}

	public UploadSettings() { }

	public void add_OnHeadersSent(OnHeadersSentDelegate value) { }

	protected void call_onBeforeHeaderSend(HTTPRequest request) { }

	protected override void Dispose(bool disposing) { }

	public override void Dispose() { }

	public void remove_OnHeadersSent(OnHeadersSentDelegate value) { }

	public override void SetupRequest(HTTPRequest request, bool dispatchHeadersSentCallback) { }

}

