namespace Best.HTTP.Request.Settings;

public sealed class OnBeforeRedirectionDelegate : MulticastDelegate
{

	public OnBeforeRedirectionDelegate(object object, IntPtr method) { }

	public override IAsyncResult BeginInvoke(HTTPRequest req, HTTPResponse resp, Uri redirectUri, AsyncCallback callback, object object) { }

	public override bool EndInvoke(IAsyncResult result) { }

	public override bool Invoke(HTTPRequest req, HTTPResponse resp, Uri redirectUri) { }

}

