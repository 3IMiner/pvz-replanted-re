namespace Best.HTTP.Request.Settings;

public class RedirectSettings
{
	[CompilerGenerated]
	private bool <IsRedirected>k__BackingField; //Field offset: 0x10
	[CompilerGenerated]
	private Uri <RedirectUri>k__BackingField; //Field offset: 0x18
	[CompilerGenerated]
	private int <MaxRedirects>k__BackingField; //Field offset: 0x20
	[CompilerGenerated]
	private int <RedirectCount>k__BackingField; //Field offset: 0x24
	private OnBeforeRedirectionDelegate onBeforeRedirection; //Field offset: 0x28

	public event OnBeforeRedirectionDelegate OnBeforeRedirection
	{
		 add { } //Length: 159
		 remove { } //Length: 159
	}

	public internal bool IsRedirected
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		internal set { } //Length: 4
	}

	public int MaxRedirects
	{
		[CompilerGenerated]
		 get { } //Length: 4
		[CompilerGenerated]
		 set { } //Length: 4
	}

	public internal int RedirectCount
	{
		[CompilerGenerated]
		 get { } //Length: 4
		[CompilerGenerated]
		internal set { } //Length: 4
	}

	public internal Uri RedirectUri
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		internal set { } //Length: 13
	}

	public RedirectSettings(int maxRedirects) { }

	public void add_OnBeforeRedirection(OnBeforeRedirectionDelegate value) { }

	internal bool CallOnBeforeRedirection(HTTPRequest req, HTTPResponse resp, Uri redirectUri) { }

	[CompilerGenerated]
	public bool get_IsRedirected() { }

	[CompilerGenerated]
	public int get_MaxRedirects() { }

	[CompilerGenerated]
	public int get_RedirectCount() { }

	[CompilerGenerated]
	public Uri get_RedirectUri() { }

	public void remove_OnBeforeRedirection(OnBeforeRedirectionDelegate value) { }

	public void Reset() { }

	[CompilerGenerated]
	internal void set_IsRedirected(bool value) { }

	[CompilerGenerated]
	public void set_MaxRedirects(int value) { }

	[CompilerGenerated]
	internal void set_RedirectCount(int value) { }

	[CompilerGenerated]
	internal void set_RedirectUri(Uri value) { }

}

