namespace Best.HTTP.Request.Settings;

public class ProxySettings
{
	[CompilerGenerated]
	private Proxy <Proxy>k__BackingField; //Field offset: 0x10

	public Proxy Proxy
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		 set { } //Length: 13
	}

	public ProxySettings() { }

	public void AddToHash(Uri requestUri, ref Hash128 hash) { }

	[CompilerGenerated]
	public Proxy get_Proxy() { }

	public bool Handle407(HTTPRequest request) { }

	public bool HasProxyFor(Uri uri) { }

	[CompilerGenerated]
	public void set_Proxy(Proxy value) { }

	public void SetupRequest(HTTPRequest request) { }

	public virtual string ToString() { }

}

