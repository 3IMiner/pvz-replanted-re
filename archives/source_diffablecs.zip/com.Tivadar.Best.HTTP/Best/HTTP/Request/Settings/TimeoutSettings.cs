namespace Best.HTTP.Request.Settings;

public class TimeoutSettings
{
	[CompilerGenerated]
	private DateTime <QueuedAt>k__BackingField; //Field offset: 0x10
	[CompilerGenerated]
	private DateTime <ProcessingStarted>k__BackingField; //Field offset: 0x18
	private Nullable<TimeSpan> _connectTimeout; //Field offset: 0x20
	private Nullable<TimeSpan> _timeout; //Field offset: 0x30
	private HTTPRequest _request; //Field offset: 0x40

	public TimeSpan ConnectTimeout
	{
		 get { } //Length: 302
		 set { } //Length: 92
	}

	public internal DateTime ProcessingStarted
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		internal set { } //Length: 5
	}

	public internal DateTime QueuedAt
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		internal set { } //Length: 5
	}

	public TimeSpan Timeout
	{
		 get { } //Length: 302
		 set { } //Length: 92
	}

	public TimeoutSettings(HTTPRequest request) { }

	public TimeSpan get_ConnectTimeout() { }

	[CompilerGenerated]
	public DateTime get_ProcessingStarted() { }

	[CompilerGenerated]
	public DateTime get_QueuedAt() { }

	public TimeSpan get_Timeout() { }

	public bool IsConnectTimedOut(DateTime now) { }

	public bool IsTimedOut(DateTime now) { }

	public void set_ConnectTimeout(TimeSpan value) { }

	[CompilerGenerated]
	internal void set_ProcessingStarted(DateTime value) { }

	[CompilerGenerated]
	internal void set_QueuedAt(DateTime value) { }

	public void set_Timeout(TimeSpan value) { }

	public void SetProcessing(DateTime now) { }

}

