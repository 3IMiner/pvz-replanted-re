namespace Best.HTTP.Request.Settings;

public sealed class OnProgressDelegate : MulticastDelegate
{

	public OnProgressDelegate(object object, IntPtr method) { }

	public override IAsyncResult BeginInvoke(HTTPRequest req, long progress, long length, AsyncCallback callback, object object) { }

	public override void EndInvoke(IAsyncResult result) { }

	public override void Invoke(HTTPRequest req, long progress, long length) { }

}

