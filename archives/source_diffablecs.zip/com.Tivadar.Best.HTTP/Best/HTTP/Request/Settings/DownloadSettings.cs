namespace Best.HTTP.Request.Settings;

public class DownloadSettings
{
	[CompilerGenerated]
	private sealed class <>c
	{
		public static readonly <>c <>9; //Field offset: 0x0
		public static OnCreateDownloadStreamDelegate <>9__14_0; //Field offset: 0x8

		private static <>c() { }

		public <>c() { }

		internal DownloadContentStream <.ctor>b__14_0(HTTPRequest req, HTTPResponse resp, IDownloadContentBufferAvailable bufferAvailableHandler) { }

	}

	public long ContentStreamMaxBuffered; //Field offset: 0x10
	[CompilerGenerated]
	private bool <DisableCache>k__BackingField; //Field offset: 0x18
	[CompilerGenerated]
	private bool <CacheOnly>k__BackingField; //Field offset: 0x19
	public OnHeadersReceivedDelegate OnHeadersReceived; //Field offset: 0x20
	public OnCreateDownloadStreamDelegate DownloadStreamFactory; //Field offset: 0x28
	public OnDownloadStartedDelegate OnDownloadStarted; //Field offset: 0x30
	public OnProgressDelegate OnDownloadProgress; //Field offset: 0x38
	public OnUpgradedDelegate OnUpgraded; //Field offset: 0x40

	public bool CacheOnly
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		 set { } //Length: 4
	}

	public bool DisableCache
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		 set { } //Length: 4
	}

	public DownloadSettings() { }

	[CompilerGenerated]
	public bool get_CacheOnly() { }

	[CompilerGenerated]
	public bool get_DisableCache() { }

	[CompilerGenerated]
	public void set_CacheOnly(bool value) { }

	[CompilerGenerated]
	public void set_DisableCache(bool value) { }

}

