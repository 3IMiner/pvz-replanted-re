namespace Best.HTTP.Request.Settings;

public sealed class OnDownloadStartedDelegate : MulticastDelegate
{

	public OnDownloadStartedDelegate(object object, IntPtr method) { }

	public override IAsyncResult BeginInvoke(HTTPRequest req, HTTPResponse resp, DownloadContentStream stream, AsyncCallback callback, object object) { }

	public override void EndInvoke(IAsyncResult result) { }

	public override void Invoke(HTTPRequest req, HTTPResponse resp, DownloadContentStream stream) { }

}

