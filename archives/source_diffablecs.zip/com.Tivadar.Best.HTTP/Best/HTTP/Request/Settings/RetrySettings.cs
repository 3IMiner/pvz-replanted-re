namespace Best.HTTP.Request.Settings;

public class RetrySettings
{
	[CompilerGenerated]
	private int <Retries>k__BackingField; //Field offset: 0x10
	[CompilerGenerated]
	private int <MaxRetries>k__BackingField; //Field offset: 0x14

	public int MaxRetries
	{
		[CompilerGenerated]
		 get { } //Length: 4
		[CompilerGenerated]
		 set { } //Length: 4
	}

	public int Retries
	{
		[CompilerGenerated]
		 get { } //Length: 4
		[CompilerGenerated]
		 set { } //Length: 4
	}

	public RetrySettings(int maxRetries) { }

	[CompilerGenerated]
	public int get_MaxRetries() { }

	[CompilerGenerated]
	public int get_Retries() { }

	[CompilerGenerated]
	public void set_MaxRetries(int value) { }

	[CompilerGenerated]
	public void set_Retries(int value) { }

}

