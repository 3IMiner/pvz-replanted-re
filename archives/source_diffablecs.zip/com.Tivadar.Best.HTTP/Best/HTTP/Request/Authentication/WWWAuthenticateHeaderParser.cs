namespace Best.HTTP.Request.Authentication;

public sealed class WWWAuthenticateHeaderParser : KeyValuePairList
{
	[CompilerGenerated]
	private sealed class <>c
	{
		public static readonly <>c <>9; //Field offset: 0x0
		public static Func<Char, Boolean> <>9__1_0; //Field offset: 0x8

		private static <>c() { }

		public <>c() { }

		internal bool <ParseQuotedHeader>b__1_0(char ch) { }

	}


	public WWWAuthenticateHeaderParser(string headerValue) { }

	private List<HeaderValue> ParseQuotedHeader(string str) { }

}

