namespace Best.HTTP.Request.Authentication;

public static class DigestStore
{
	[CompilerGenerated]
	private sealed class <>c__DisplayClass6_0
	{
		public int i; //Field offset: 0x10

		public <>c__DisplayClass6_0() { }

		internal bool <FindBest>b__0(string header) { }

	}

	private static ConcurrentDictionary<String, Digest> Digests; //Field offset: 0x0
	private static String[] SupportedAlgorithms; //Field offset: 0x8

	private static DigestStore() { }

	public static void Clear() { }

	public static string FindBest(List<String> authHeaders) { }

	public static Digest Get(Uri uri) { }

	public static Digest GetOrCreate(Uri uri) { }

	public static void Remove(Uri uri) { }

}

