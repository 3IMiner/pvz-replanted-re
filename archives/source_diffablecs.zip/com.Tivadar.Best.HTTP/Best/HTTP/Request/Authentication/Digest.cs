namespace Best.HTTP.Request.Authentication;

public sealed class Digest
{
	[CompilerGenerated]
	private Uri <Uri>k__BackingField; //Field offset: 0x10
	[CompilerGenerated]
	private AuthenticationTypes <Type>k__BackingField; //Field offset: 0x18
	[CompilerGenerated]
	private string <Realm>k__BackingField; //Field offset: 0x20
	[CompilerGenerated]
	private bool <Stale>k__BackingField; //Field offset: 0x28
	[CompilerGenerated]
	private string <Nonce>k__BackingField; //Field offset: 0x30
	[CompilerGenerated]
	private string <Opaque>k__BackingField; //Field offset: 0x38
	[CompilerGenerated]
	private string <Algorithm>k__BackingField; //Field offset: 0x40
	[CompilerGenerated]
	private List<String> <ProtectedUris>k__BackingField; //Field offset: 0x48
	[CompilerGenerated]
	private string <QualityOfProtections>k__BackingField; //Field offset: 0x50
	[CompilerGenerated]
	private int <NonceCount>k__BackingField; //Field offset: 0x58
	[CompilerGenerated]
	private string <HA1Sess>k__BackingField; //Field offset: 0x60

	private string Algorithm
	{
		[CompilerGenerated]
		private get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 13
	}

	private string HA1Sess
	{
		[CompilerGenerated]
		private get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 13
	}

	private string Nonce
	{
		[CompilerGenerated]
		private get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 13
	}

	private int NonceCount
	{
		[CompilerGenerated]
		private get { } //Length: 4
		[CompilerGenerated]
		private set { } //Length: 4
	}

	private string Opaque
	{
		[CompilerGenerated]
		private get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 13
	}

	public private List<String> ProtectedUris
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 13
	}

	private string QualityOfProtections
	{
		[CompilerGenerated]
		private get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 13
	}

	public private string Realm
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 13
	}

	public private bool Stale
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 4
	}

	public private AuthenticationTypes Type
	{
		[CompilerGenerated]
		 get { } //Length: 4
		[CompilerGenerated]
		private set { } //Length: 4
	}

	public private Uri Uri
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 13
	}

	internal Digest(Uri uri) { }

	public string GenerateResponseHeader(Credentials credentials, bool isProxy, HTTPMethods methodType, Uri currentUri) { }

	[CompilerGenerated]
	private string get_Algorithm() { }

	[CompilerGenerated]
	private string get_HA1Sess() { }

	[CompilerGenerated]
	private string get_Nonce() { }

	[CompilerGenerated]
	private int get_NonceCount() { }

	[CompilerGenerated]
	private string get_Opaque() { }

	[CompilerGenerated]
	public List<String> get_ProtectedUris() { }

	[CompilerGenerated]
	private string get_QualityOfProtections() { }

	[CompilerGenerated]
	public string get_Realm() { }

	[CompilerGenerated]
	public bool get_Stale() { }

	[CompilerGenerated]
	public AuthenticationTypes get_Type() { }

	[CompilerGenerated]
	public Uri get_Uri() { }

	public bool IsUriProtected(Uri uri) { }

	public void ParseChallange(string header) { }

	[CompilerGenerated]
	private void set_Algorithm(string value) { }

	[CompilerGenerated]
	private void set_HA1Sess(string value) { }

	[CompilerGenerated]
	private void set_Nonce(string value) { }

	[CompilerGenerated]
	private void set_NonceCount(int value) { }

	[CompilerGenerated]
	private void set_Opaque(string value) { }

	[CompilerGenerated]
	private void set_ProtectedUris(List<String> value) { }

	[CompilerGenerated]
	private void set_QualityOfProtections(string value) { }

	[CompilerGenerated]
	private void set_Realm(string value) { }

	[CompilerGenerated]
	private void set_Stale(bool value) { }

	[CompilerGenerated]
	private void set_Type(AuthenticationTypes value) { }

	[CompilerGenerated]
	private void set_Uri(Uri value) { }

}

