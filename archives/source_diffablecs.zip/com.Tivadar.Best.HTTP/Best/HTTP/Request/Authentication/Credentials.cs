namespace Best.HTTP.Request.Authentication;

public sealed class Credentials
{
	[CompilerGenerated]
	private AuthenticationTypes <Type>k__BackingField; //Field offset: 0x10
	[CompilerGenerated]
	private string <UserName>k__BackingField; //Field offset: 0x18
	[CompilerGenerated]
	private string <Password>k__BackingField; //Field offset: 0x20

	public private string Password
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 13
	}

	public private AuthenticationTypes Type
	{
		[CompilerGenerated]
		 get { } //Length: 4
		[CompilerGenerated]
		private set { } //Length: 4
	}

	public private string UserName
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 13
	}

	public Credentials(string userName, string password) { }

	public Credentials(AuthenticationTypes type, string userName, string password) { }

	[CompilerGenerated]
	public string get_Password() { }

	[CompilerGenerated]
	public AuthenticationTypes get_Type() { }

	[CompilerGenerated]
	public string get_UserName() { }

	[CompilerGenerated]
	private void set_Password(string value) { }

	[CompilerGenerated]
	private void set_Type(AuthenticationTypes value) { }

	[CompilerGenerated]
	private void set_UserName(string value) { }

}

