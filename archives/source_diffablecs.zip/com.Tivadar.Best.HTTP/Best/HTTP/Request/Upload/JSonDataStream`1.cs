namespace Best.HTTP.Request.Upload;

public sealed class JSonDataStream : UploadStreamBase
{
	private BufferPoolMemoryStream _innerStream; //Field offset: 0x0
	private T _objToJson; //Field offset: 0x0

	public virtual bool CanRead
	{
		 get { } //Length: 3
	}

	public virtual bool CanSeek
	{
		 get { } //Length: 3
	}

	public virtual bool CanWrite
	{
		 get { } //Length: 3
	}

	public virtual long Length
	{
		 get { } //Length: 67
	}

	public virtual long Position
	{
		 get { } //Length: 57
		 set { } //Length: 57
	}

	public JSonDataStream`1(T obj) { }

	public virtual void BeforeSendHeaders(HTTPRequest request) { }

	protected virtual void Dispose(bool disposing) { }

	public virtual void Flush() { }

	public virtual bool get_CanRead() { }

	public virtual bool get_CanSeek() { }

	public virtual bool get_CanWrite() { }

	public virtual long get_Length() { }

	public virtual long get_Position() { }

	public virtual int Read(Byte[] buffer, int offset, int count) { }

	public virtual long Seek(long offset, SeekOrigin origin) { }

	public virtual void set_Position(long value) { }

	public virtual void SetLength(long value) { }

	public virtual void Write(Byte[] buffer, int offset, int count) { }

}

