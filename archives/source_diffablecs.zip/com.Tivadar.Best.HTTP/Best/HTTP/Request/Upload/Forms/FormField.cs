namespace Best.HTTP.Request.Upload.Forms;

[IsReadOnly]
internal struct FormField
{
	public readonly string Key; //Field offset: 0x0
	public readonly string TextValue; //Field offset: 0x8
	public readonly Byte[] BinaryValue; //Field offset: 0x10

	public FormField(string key, string textValue) { }

	public FormField(string key, Byte[] binaryValue) { }

}

