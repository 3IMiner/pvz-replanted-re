namespace Best.HTTP.Request.Upload.Forms;

public sealed class MultipartFormDataStream : UploadStreamBase
{
	private long _length; //Field offset: 0x30
	private string boundary; //Field offset: 0x38
	private Queue<StreamList> fields; //Field offset: 0x40
	private StreamList currentField; //Field offset: 0x48

	public virtual bool CanRead
	{
		 get { } //Length: 3
	}

	public virtual bool CanSeek
	{
		 get { } //Length: 3
	}

	public virtual bool CanWrite
	{
		 get { } //Length: 3
	}

	public virtual long Length
	{
		 get { } //Length: 5
	}

	public virtual long Position
	{
		 get { } //Length: 62
		 set { } //Length: 62
	}

	public MultipartFormDataStream() { }

	public MultipartFormDataStream(string boundary) { }

	public MultipartFormDataStream AddField(string fieldName, string value) { }

	public MultipartFormDataStream AddField(string fieldName, string value, Encoding encoding) { }

	public MultipartFormDataStream AddField(string fieldName, Byte[] data) { }

	public MultipartFormDataStream AddStreamField(string fieldName, Stream stream) { }

	public MultipartFormDataStream AddStreamField(string fieldName, Stream stream, string fileName) { }

	public MultipartFormDataStream AddStreamField(string fieldName, Stream stream, string fileName, string mimeType) { }

	public virtual void BeforeSendBody(HTTPRequest request, IThreadSignaler threadSignaler) { }

	public virtual void BeforeSendHeaders(HTTPRequest request) { }

	protected virtual void Dispose(bool disposing) { }

	public virtual void Flush() { }

	public virtual bool get_CanRead() { }

	public virtual bool get_CanSeek() { }

	public virtual bool get_CanWrite() { }

	public virtual long get_Length() { }

	public virtual long get_Position() { }

	public virtual int Read(Byte[] buffer, int offset, int length) { }

	public virtual long Seek(long offset, SeekOrigin origin) { }

	public virtual void set_Position(long value) { }

	public virtual void SetLength(long value) { }

	public virtual void Write(Byte[] buffer, int offset, int count) { }

}

