namespace Best.HTTP.Request.Upload.Forms;

public sealed class UrlEncodedStream : UploadStreamBase
{
	private const int EscapeTreshold = 256; //Field offset: 0x0
	private MemoryStream _memoryStream; //Field offset: 0x30
	private List<FormField> _fields; //Field offset: 0x38

	public virtual bool CanRead
	{
		 get { } //Length: 3
	}

	public virtual bool CanSeek
	{
		 get { } //Length: 3
	}

	public virtual bool CanWrite
	{
		 get { } //Length: 3
	}

	public virtual long Length
	{
		 get { } //Length: 42
	}

	public virtual long Position
	{
		 get { } //Length: 62
		 set { } //Length: 62
	}

	public UrlEncodedStream() { }

	public UrlEncodedStream AddBinaryData(string fieldName, Byte[] content) { }

	public UrlEncodedStream AddField(string fieldName, string value) { }

	public virtual void BeforeSendHeaders(HTTPRequest request) { }

	protected virtual void Dispose(bool disposing) { }

	private static string EscapeString(string originalString) { }

	public virtual void Flush() { }

	public virtual bool get_CanRead() { }

	public virtual bool get_CanSeek() { }

	public virtual bool get_CanWrite() { }

	public virtual long get_Length() { }

	public virtual long get_Position() { }

	public virtual int Read(Byte[] buffer, int offset, int count) { }

	public virtual long Seek(long offset, SeekOrigin origin) { }

	public virtual void set_Position(long value) { }

	public virtual void SetLength(long value) { }

	public virtual void Write(Byte[] buffer, int offset, int count) { }

}

