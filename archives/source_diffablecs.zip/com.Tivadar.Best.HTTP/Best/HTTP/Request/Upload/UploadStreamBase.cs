namespace Best.HTTP.Request.Upload;

public abstract class UploadStreamBase : Stream
{
	[CompilerGenerated]
	private IThreadSignaler <Signaler>k__BackingField; //Field offset: 0x28

	public virtual long Length
	{
		 get { } //Length: 62
	}

	public private IThreadSignaler Signaler
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 13
	}

	protected UploadStreamBase() { }

	public override void BeforeSendBody(HTTPRequest request, IThreadSignaler threadSignaler) { }

	public abstract void BeforeSendHeaders(HTTPRequest request) { }

	protected virtual void Dispose(bool disposing) { }

	public virtual long get_Length() { }

	[CompilerGenerated]
	public IThreadSignaler get_Signaler() { }

	[CompilerGenerated]
	private void set_Signaler(IThreadSignaler value) { }

}

