namespace Best.HTTP.Request.Upload;

public sealed class DynamicUploadStream : UploadStreamBase
{
	private long _bufferedLength; //Field offset: 0x30
	private bool _isCompleted; //Field offset: 0x38
	private ConcurrentQueue<BufferSegment> _chunks; //Field offset: 0x40
	private BufferSegment _current; //Field offset: 0x48
	private string _contentType; //Field offset: 0x58

	public long BufferedLength
	{
		 get { } //Length: 5
	}

	public virtual bool CanRead
	{
		 get { } //Length: 3
	}

	public virtual bool CanSeek
	{
		 get { } //Length: 3
	}

	public virtual bool CanWrite
	{
		 get { } //Length: 3
	}

	public virtual long Length
	{
		 get { } //Length: 8
	}

	public virtual long Position
	{
		 get { } //Length: 62
		 set { } //Length: 62
	}

	public DynamicUploadStream(string contentType = "application/octet-stream") { }

	public virtual void BeforeSendBody(HTTPRequest request, IThreadSignaler threadSignaler) { }

	public virtual void BeforeSendHeaders(HTTPRequest request) { }

	public void Complete() { }

	public virtual void Flush() { }

	public long get_BufferedLength() { }

	public virtual bool get_CanRead() { }

	public virtual bool get_CanSeek() { }

	public virtual bool get_CanWrite() { }

	public virtual long get_Length() { }

	public virtual long get_Position() { }

	public virtual int Read(Byte[] buffer, int offset, int count) { }

	public virtual long Seek(long offset, SeekOrigin origin) { }

	public virtual void set_Position(long value) { }

	public virtual void SetLength(long value) { }

	public virtual void Write(Byte[] buffer, int offset, int count) { }

	public void Write(BufferSegment segment) { }

}

