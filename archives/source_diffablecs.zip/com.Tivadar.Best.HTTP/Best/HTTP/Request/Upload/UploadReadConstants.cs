namespace Best.HTTP.Request.Upload;

public static class UploadReadConstants
{
	public static int WaitForMore; //Field offset: 0x0
	public static int Completed; //Field offset: 0x4

	private static UploadReadConstants() { }

}

