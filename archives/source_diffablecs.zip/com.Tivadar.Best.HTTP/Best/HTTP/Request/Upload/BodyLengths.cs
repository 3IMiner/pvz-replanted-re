namespace Best.HTTP.Request.Upload;

public static class BodyLengths
{
	public const long UnknownWithChunkedTransferEncoding = -2; //Field offset: 0x0
	public const long UnknownRaw = -1; //Field offset: 0x0
	public const long NoBody = 0; //Field offset: 0x0

}

