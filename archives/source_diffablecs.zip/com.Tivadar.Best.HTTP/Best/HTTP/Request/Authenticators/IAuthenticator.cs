namespace Best.HTTP.Request.Authenticators;

public interface IAuthenticator
{

	public bool HandleChallange(HTTPRequest req, HTTPResponse resp) { }

	public void SetupRequest(HTTPRequest request) { }

}

