namespace Best.HTTP.Request.Authenticators;

public class BearerTokenAuthenticator : IAuthenticator
{
	[CompilerGenerated]
	private string <Token>k__BackingField; //Field offset: 0x10

	public private string Token
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 13
	}

	public BearerTokenAuthenticator(string token) { }

	[CompilerGenerated]
	public string get_Token() { }

	public override bool HandleChallange(HTTPRequest req, HTTPResponse resp) { }

	[CompilerGenerated]
	private void set_Token(string value) { }

	public override void SetupRequest(HTTPRequest request) { }

}

