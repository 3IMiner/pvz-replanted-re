namespace Best.HTTP.Request.Authenticators;

public class CredentialAuthenticator : IAuthenticator
{
	[CompilerGenerated]
	private Credentials <Credentials>k__BackingField; //Field offset: 0x10

	public Credentials Credentials
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		 set { } //Length: 13
	}

	public CredentialAuthenticator(Credentials credentials) { }

	[CompilerGenerated]
	public Credentials get_Credentials() { }

	public override bool HandleChallange(HTTPRequest req, HTTPResponse resp) { }

	[CompilerGenerated]
	public void set_Credentials(Credentials value) { }

	public override void SetupRequest(HTTPRequest request) { }

}

