namespace Best.HTTP.Request.Timings;

public static class TimingEventNames
{
	public const string Initial = "Initial"; //Field offset: 0x0
	public const string Queued = "Queued"; //Field offset: 0x0
	public const string ProxyDetection = "Proxy Detection"; //Field offset: 0x0
	public const string DNS_Lookup = "DNS Lookup"; //Field offset: 0x0
	public const string TCP_Connection = "TCP Connection"; //Field offset: 0x0
	public const string Proxy_Negotiation = "Proxy Negotiation"; //Field offset: 0x0
	public const string TLS_Negotiation = "TLS Negotiation"; //Field offset: 0x0
	public const string Request_Sent = "Request Sent"; //Field offset: 0x0
	public const string Waiting_TTFB = "Waiting (TTFB)"; //Field offset: 0x0
	public const string Headers = "Headers"; //Field offset: 0x0
	public const string Response_Received = "Response Received"; //Field offset: 0x0
	public const string Finished = "Finished in"; //Field offset: 0x0
	public const string Callback = "Callback"; //Field offset: 0x0

}

