namespace Best.HTTP.Request.Timings;

public enum TimingEvents
{
	StartNext = 0,
	Finish = 1,
}

