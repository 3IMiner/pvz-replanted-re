namespace Best.HTTP.Request.Timings;

[IsReadOnly]
public struct TimingEventInfo
{
	public readonly HTTPRequest SourceRequest; //Field offset: 0x0
	public readonly TimingEvents Event; //Field offset: 0x8
	public readonly string Name; //Field offset: 0x10
	public readonly DateTime Time; //Field offset: 0x18

	public TimingEventInfo(HTTPRequest parentRequest, TimingEvents timingEvent) { }

	public TimingEventInfo(HTTPRequest parentRequest, TimingEvents timingEvent, string eventName) { }

	public virtual string ToString() { }

}

