namespace Best.HTTP.Request.Timings;

public struct TimingEvent : IEquatable<TimingEvent>
{
	public static readonly TimingEvent Empty; //Field offset: 0x0
	public readonly string Name; //Field offset: 0x0
	public readonly TimeSpan Duration; //Field offset: 0x8
	public readonly DateTime Start; //Field offset: 0x10

	private static TimingEvent() { }

	public TimingEvent(string name, TimeSpan duration) { }

	public TimingEvent(string name, DateTime when, TimeSpan duration) { }

	public TimeSpan CalculateDuration(TimingEvent tEvent) { }

	public override bool Equals(TimingEvent other) { }

	public virtual bool Equals(object obj) { }

	public virtual int GetHashCode() { }

	public static bool op_Equality(TimingEvent lhs, TimingEvent rhs) { }

	public static bool op_Inequality(TimingEvent lhs, TimingEvent rhs) { }

	public virtual string ToString() { }

}

