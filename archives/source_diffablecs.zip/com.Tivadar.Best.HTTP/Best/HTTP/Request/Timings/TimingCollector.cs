namespace Best.HTTP.Request.Timings;

public sealed class TimingCollector
{
	[CompilerGenerated]
	private readonly HTTPRequest <ParentRequest>k__BackingField; //Field offset: 0x10
	[CompilerGenerated]
	private DateTime <Created>k__BackingField; //Field offset: 0x18
	[CompilerGenerated]
	private DateTime <Finished>k__BackingField; //Field offset: 0x20
	[CompilerGenerated]
	private List<TimingEvent> <Events>k__BackingField; //Field offset: 0x28
	private PartialEvent _partialEvent; //Field offset: 0x30

	public private DateTime Created
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 5
	}

	public private List<TimingEvent> Events
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 13
	}

	public private DateTime Finished
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 5
	}

	public HTTPRequest ParentRequest
	{
		[CompilerGenerated]
		 get { } //Length: 5
	}

	internal TimingCollector(HTTPRequest parentRequest) { }

	internal void AddEvent(TimingEventInfo timingEvent) { }

	internal void AddEvent(string name, DateTime when, TimeSpan duration) { }

	public TimingEvent FindFirst(string name) { }

	public TimingEvent FindLast(string name) { }

	public TimingEvent FindNext(TimingEvent relativeTo, string name) { }

	[CompilerGenerated]
	public DateTime get_Created() { }

	[CompilerGenerated]
	public List<TimingEvent> get_Events() { }

	[CompilerGenerated]
	public DateTime get_Finished() { }

	[CompilerGenerated]
	public HTTPRequest get_ParentRequest() { }

	[CompilerGenerated]
	private void set_Created(DateTime value) { }

	[CompilerGenerated]
	private void set_Events(List<TimingEvent> value) { }

	[CompilerGenerated]
	private void set_Finished(DateTime value) { }

	public void StartNext(string eventName) { }

	public virtual string ToString() { }

}

