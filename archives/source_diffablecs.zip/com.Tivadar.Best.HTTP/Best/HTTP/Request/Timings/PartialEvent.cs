namespace Best.HTTP.Request.Timings;

internal struct PartialEvent
{
	public string EventName; //Field offset: 0x0
	public DateTime StartedAt; //Field offset: 0x8

	public PartialEvent(string eventName, DateTime startedAt) { }

	public bool IsSet() { }

	public virtual string ToString() { }

}

