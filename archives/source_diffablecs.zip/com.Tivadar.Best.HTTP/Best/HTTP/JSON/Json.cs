namespace Best.HTTP.JSON;

public class Json
{
	private const int TOKEN_NONE = 0; //Field offset: 0x0
	private const int TOKEN_CURLY_OPEN = 1; //Field offset: 0x0
	private const int TOKEN_CURLY_CLOSE = 2; //Field offset: 0x0
	private const int TOKEN_SQUARED_OPEN = 3; //Field offset: 0x0
	private const int TOKEN_SQUARED_CLOSE = 4; //Field offset: 0x0
	private const int TOKEN_COLON = 5; //Field offset: 0x0
	private const int TOKEN_COMMA = 6; //Field offset: 0x0
	private const int TOKEN_STRING = 7; //Field offset: 0x0
	private const int TOKEN_NUMBER = 8; //Field offset: 0x0
	private const int TOKEN_TRUE = 9; //Field offset: 0x0
	private const int TOKEN_FALSE = 10; //Field offset: 0x0
	private const int TOKEN_NULL = 11; //Field offset: 0x0
	private const int BUILDER_CAPACITY = 2000; //Field offset: 0x0

	public Json() { }

	public static object Decode(string json) { }

	public static object Decode(string json, ref bool success) { }

	protected static void EatWhitespace(Char[] json, ref int index) { }

	public static string Encode(object json) { }

	protected static int GetLastIndexOfNumber(Char[] json, int index) { }

	protected static int LookAhead(Char[] json, int index) { }

	protected static int NextToken(Char[] json, ref int index) { }

	protected static List<Object> ParseArray(Char[] json, ref int index, ref bool success) { }

	protected static double ParseNumber(Char[] json, ref int index, ref bool success) { }

	protected static Dictionary<String, Object> ParseObject(Char[] json, ref int index, ref bool success) { }

	protected static string ParseString(Char[] json, ref int index, ref bool success) { }

	protected static object ParseValue(Char[] json, ref int index, ref bool success) { }

	protected static bool SerializeArray(IList anArray, StringBuilder builder) { }

	protected static bool SerializeNumber(double number, StringBuilder builder) { }

	protected static bool SerializeObject(IDictionary anObject, StringBuilder builder) { }

	protected static bool SerializeString(string aString, StringBuilder builder) { }

	protected static bool SerializeValue(object value, StringBuilder builder) { }

}

