namespace Best.HTTP.JSON.LitJson;

public interface IFastSetter
{

	public void SetBool(ReadOnlySpan<Char> property, bool value) { }

	public void SetDouble(ReadOnlySpan<Char> property, double value) { }

	public void SetInteger(ReadOnlySpan<Char> property, long value) { }

	public void SetOther(ReadOnlySpan<Char> property, object value) { }

}

