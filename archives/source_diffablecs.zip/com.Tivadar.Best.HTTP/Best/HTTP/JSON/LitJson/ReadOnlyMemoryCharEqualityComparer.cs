namespace Best.HTTP.JSON.LitJson;

internal class ReadOnlyMemoryCharEqualityComparer : IEqualityComparer<ReadOnlyMemory`1<Char>>
{
	public static ReadOnlyMemoryCharEqualityComparer Comparer; //Field offset: 0x0

	private static ReadOnlyMemoryCharEqualityComparer() { }

	public ReadOnlyMemoryCharEqualityComparer() { }

	public override bool Equals(ReadOnlyMemory<Char> x, ReadOnlyMemory<Char> y) { }

	public override int GetHashCode(ReadOnlyMemory<Char> obj) { }

}

