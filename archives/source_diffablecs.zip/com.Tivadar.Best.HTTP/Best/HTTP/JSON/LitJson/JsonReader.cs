namespace Best.HTTP.JSON.LitJson;

public sealed class JsonReader
{
	private static readonly IDictionary<Int32, IDictionary`2<Int32, Int32[]>> parse_table; //Field offset: 0x0
	private Stack<Int32> automaton_stack; //Field offset: 0x10
	private int current_input; //Field offset: 0x18
	private int current_symbol; //Field offset: 0x1C
	private bool end_of_json; //Field offset: 0x20
	private bool end_of_input; //Field offset: 0x21
	private Lexer lexer; //Field offset: 0x28
	private bool parser_in_string; //Field offset: 0x30
	private bool parser_return; //Field offset: 0x31
	private bool read_started; //Field offset: 0x32
	private TextReader reader; //Field offset: 0x38
	private bool reader_is_owned; //Field offset: 0x40
	private bool skip_non_members; //Field offset: 0x41
	private object token_value; //Field offset: 0x48
	private JsonToken token; //Field offset: 0x50
	private bool keep_open; //Field offset: 0x54
	private bool token_bool; //Field offset: 0x55
	private int token_int; //Field offset: 0x58
	private long token_long; //Field offset: 0x60
	private ulong token_ulong; //Field offset: 0x68
	private double token_double; //Field offset: 0x70
	public ReadOnlyMemory<Char> ValueString; //Field offset: 0x78
	private Char[] _charSeq; //Field offset: 0x88

	public bool AllowComments
	{
		 get { } //Length: 27
		 set { } //Length: 26
	}

	public bool AllowSingleQuotedStrings
	{
		 get { } //Length: 27
		 set { } //Length: 26
	}

	public bool EndOfInput
	{
		 get { } //Length: 5
	}

	public bool EndOfJson
	{
		 get { } //Length: 5
	}

	public bool SkipNonMembers
	{
		 get { } //Length: 5
		 set { } //Length: 4
	}

	public JsonToken Token
	{
		 get { } //Length: 4
	}

	public object Value
	{
		 get { } //Length: 5
	}

	public bool ValueBool
	{
		 get { } //Length: 5
	}

	public double ValueDouble
	{
		 get { } //Length: 6
	}

	public int ValueInt
	{
		 get { } //Length: 4
	}

	public long ValueLong
	{
		 get { } //Length: 5
	}

	public ulong ValueULong
	{
		 get { } //Length: 5
	}

	private static JsonReader() { }

	private JsonReader(TextReader reader, bool owned, bool keep_open) { }

	public JsonReader(string json_text, bool keep_open) { }

	public JsonReader(TextReader reader) { }

	public JsonReader(string json_text) { }

	public void Close() { }

	public bool get_AllowComments() { }

	public bool get_AllowSingleQuotedStrings() { }

	public bool get_EndOfInput() { }

	public bool get_EndOfJson() { }

	public bool get_SkipNonMembers() { }

	public JsonToken get_Token() { }

	public object get_Value() { }

	public bool get_ValueBool() { }

	public double get_ValueDouble() { }

	public int get_ValueInt() { }

	public long get_ValueLong() { }

	public ulong get_ValueULong() { }

	private static IDictionary<Int32, IDictionary`2<Int32, Int32[]>> PopulateParseTable() { }

	private void ProcessNumber(ReadOnlySpan<Char> number) { }

	private void ProcessSymbol() { }

	public bool Read() { }

	private bool ReadToken() { }

	public void set_AllowComments(bool value) { }

	public void set_AllowSingleQuotedStrings(bool value) { }

	public void set_SkipNonMembers(bool value) { }

	public void SetJson(string json_text) { }

	private static void TableAddCol(IDictionary<Int32, IDictionary`2<Int32, Int32[]>> parse_table, ParserToken row, int col, Int32[] symbols) { }

	private static void TableAddRow(IDictionary<Int32, IDictionary`2<Int32, Int32[]>> parse_table, ParserToken rule) { }

}

