namespace Best.HTTP.JSON.LitJson;

public sealed class JsonMapper
{
	[CompilerGenerated]
	private sealed class <>c
	{
		public static readonly <>c <>9; //Field offset: 0x0
		public static ExporterFunc <>9__40_0; //Field offset: 0x8
		public static ExporterFunc <>9__40_1; //Field offset: 0x10
		public static ExporterFunc <>9__40_2; //Field offset: 0x18
		public static ExporterFunc <>9__40_3; //Field offset: 0x20
		public static ExporterFunc <>9__40_4; //Field offset: 0x28
		public static ExporterFunc <>9__40_5; //Field offset: 0x30
		public static ExporterFunc <>9__40_6; //Field offset: 0x38
		public static ExporterFunc <>9__40_7; //Field offset: 0x40
		public static ExporterFunc <>9__40_8; //Field offset: 0x48
		public static ExporterFunc <>9__40_9; //Field offset: 0x50
		public static ImporterFunc <>9__41_0; //Field offset: 0x58
		public static ImporterFunc <>9__41_1; //Field offset: 0x60
		public static ImporterFunc <>9__41_2; //Field offset: 0x68
		public static ImporterFunc <>9__41_3; //Field offset: 0x70
		public static ImporterFunc <>9__41_4; //Field offset: 0x78
		public static ImporterFunc <>9__41_5; //Field offset: 0x80
		public static ImporterFunc <>9__41_6; //Field offset: 0x88
		public static ImporterFunc <>9__41_7; //Field offset: 0x90
		public static ImporterFunc <>9__41_8; //Field offset: 0x98
		public static ImporterFunc <>9__41_9; //Field offset: 0xA0
		public static ImporterFunc <>9__41_10; //Field offset: 0xA8
		public static ImporterFunc <>9__41_11; //Field offset: 0xB0
		public static ImporterFunc <>9__41_12; //Field offset: 0xB8
		public static ImporterFunc <>9__41_13; //Field offset: 0xC0
		public static ImporterFunc <>9__41_14; //Field offset: 0xC8
		public static WrapperFactory <>9__46_0; //Field offset: 0xD0
		public static WrapperFactory <>9__48_0; //Field offset: 0xD8
		public static WrapperFactory <>9__49_0; //Field offset: 0xE0

		private static <>c() { }

		public <>c() { }

		internal void <RegisterBaseExporters>b__40_0(object obj, JsonWriter writer) { }

		internal void <RegisterBaseExporters>b__40_1(object obj, JsonWriter writer) { }

		internal void <RegisterBaseExporters>b__40_2(object obj, JsonWriter writer) { }

		internal void <RegisterBaseExporters>b__40_3(object obj, JsonWriter writer) { }

		internal void <RegisterBaseExporters>b__40_4(object obj, JsonWriter writer) { }

		internal void <RegisterBaseExporters>b__40_5(object obj, JsonWriter writer) { }

		internal void <RegisterBaseExporters>b__40_6(object obj, JsonWriter writer) { }

		internal void <RegisterBaseExporters>b__40_7(object obj, JsonWriter writer) { }

		internal void <RegisterBaseExporters>b__40_8(object obj, JsonWriter writer) { }

		internal void <RegisterBaseExporters>b__40_9(object obj, JsonWriter writer) { }

		internal object <RegisterBaseImporters>b__41_0(object input) { }

		internal object <RegisterBaseImporters>b__41_1(object input) { }

		internal object <RegisterBaseImporters>b__41_10(object input) { }

		internal object <RegisterBaseImporters>b__41_11(object input) { }

		internal object <RegisterBaseImporters>b__41_12(object input) { }

		internal object <RegisterBaseImporters>b__41_13(object input) { }

		internal object <RegisterBaseImporters>b__41_14(object input) { }

		internal object <RegisterBaseImporters>b__41_2(object input) { }

		internal object <RegisterBaseImporters>b__41_3(object input) { }

		internal object <RegisterBaseImporters>b__41_4(object input) { }

		internal object <RegisterBaseImporters>b__41_5(object input) { }

		internal object <RegisterBaseImporters>b__41_6(object input) { }

		internal object <RegisterBaseImporters>b__41_7(object input) { }

		internal object <RegisterBaseImporters>b__41_8(object input) { }

		internal object <RegisterBaseImporters>b__41_9(object input) { }

		internal IJsonWrapper <ToObject>b__46_0() { }

		internal IJsonWrapper <ToObject>b__48_0() { }

		internal IJsonWrapper <ToObject>b__49_0() { }

	}

	[CompilerGenerated]
	private sealed class <>c__DisplayClass56_0
	{
		public ExporterFunc<T> exporter; //Field offset: 0x0

		public <>c__DisplayClass56_0`1() { }

		internal void <RegisterExporter>b__0(object obj, JsonWriter writer) { }

	}

	[CompilerGenerated]
	private sealed class <>c__DisplayClass57_0
	{
		public ImporterFunc<TJson, TValue> importer; //Field offset: 0x0

		public <>c__DisplayClass57_0`2() { }

		internal object <RegisterImporter>b__0(object input) { }

	}

	[ThreadStatic]
	private static JsonWriter static_writer; //Field offset: 0x80000000
	[ThreadStatic]
	private static Char[] _tmpProperty; //Field offset: 0x80000008
	private static readonly int max_nesting_depth; //Field offset: 0x0
	private static readonly IFormatProvider datetime_format; //Field offset: 0x8
	private static readonly IDictionary<Type, ExporterFunc> base_exporters_table; //Field offset: 0x10
	private static readonly IDictionary<Type, ExporterFunc> custom_exporters_table; //Field offset: 0x18
	private static readonly IDictionary<Type, IDictionary`2<Type, ImporterFunc>> base_importers_table; //Field offset: 0x20
	private static readonly IDictionary<Type, IDictionary`2<Type, ImporterFunc>> custom_importers_table; //Field offset: 0x28
	private static readonly IDictionary<Type, ArrayMetadata> array_metadata; //Field offset: 0x30
	private static readonly ReaderWriterLockSlim array_metadata_lock; //Field offset: 0x38
	private static readonly IDictionary<Type, Dictionary`2<Type, MethodInfo>> conv_ops; //Field offset: 0x40
	private static readonly ReaderWriterLockSlim conv_ops_lock; //Field offset: 0x48
	private static readonly IDictionary<Type, ObjectMetadata> object_metadata; //Field offset: 0x50
	private static readonly ReaderWriterLockSlim object_metadata_lock; //Field offset: 0x58
	private static readonly IDictionary<Type, List`1<PropertyMetadata>> type_properties; //Field offset: 0x60
	private static readonly ReaderWriterLockSlim type_properties_lock; //Field offset: 0x68
	private static ConcurrentStack<JsonReader> _readerPool; //Field offset: 0x70
	private static ConcurrentDictionary<ReadOnlyMemory`1<Char>, String> _stringInstanceCache; //Field offset: 0x78
	private static Type int_type; //Field offset: 0x80
	private static Type long_type; //Field offset: 0x88
	private static Type ulong_type; //Field offset: 0x90
	private static Type bool_type; //Field offset: 0x98
	private static Type double_type; //Field offset: 0xA0
	private static Type string_type; //Field offset: 0xA8
	private static Type nullable_type; //Field offset: 0xB0
	private static Func<Type, Object> _instanceProvider; //Field offset: 0xB8

	private static JsonMapper() { }

	public JsonMapper() { }

	private static ArrayMetadata AddArrayMetadata(Type type) { }

	private static ObjectMetadata AddObjectMetadata(Type type) { }

	private static List<PropertyMetadata> AddTypeProperties(Type type) { }

	private static MethodInfo GetConvOp(Type t1, Type t2) { }

	public static object GetInstance(Type type) { }

	public static PropertyInfo[] GetPublicInstanceProperties(Type type) { }

	public static string GetStringInstance(ReadOnlyMemory<Char> chars) { }

	private static bool HasInterface(Type type, string name) { }

	private static void ReadSkip(JsonReader reader) { }

	private static object ReadValue(Type inst_type, JsonReader reader, bool skipRead = false) { }

	private static IJsonWrapper ReadValue(WrapperFactory factory, JsonReader reader) { }

	private static void RegisterBaseExporters() { }

	private static void RegisterBaseImporters() { }

	public static void RegisterExporter(ExporterFunc<T> exporter) { }

	public static void RegisterImporter(ImporterFunc<TJson, TValue> importer) { }

	private static void RegisterImporter(IDictionary<Type, IDictionary`2<Type, ImporterFunc>> table, Type json_type, Type value_type, ImporterFunc importer) { }

	public static void RegisterInstanceProvider(Func<Type, Object> provider) { }

	public static void RegisterStringCache(string str) { }

	public static void ToJson(object obj, JsonWriter writer) { }

	public static string ToJson(object obj) { }

	public static object ToObject(Type toType, string json) { }

	public static T ToObject(string json) { }

	public static T ToObject(TextReader reader) { }

	public static JsonData ToObject(JsonReader reader) { }

	public static JsonData ToObject(string json) { }

	public static JsonData ToObject(TextReader reader) { }

	public static object ToObject(Type toType, JsonReader reader) { }

	public static T ToObject(JsonReader reader) { }

	public static IJsonWrapper ToWrapper(WrapperFactory factory, JsonReader reader) { }

	public static IJsonWrapper ToWrapper(WrapperFactory factory, string json) { }

	private static bool TryReadBool(Type inst_type, JsonReader reader, out bool value) { }

	private static bool TryReadDouble(Type inst_type, JsonReader reader, out double value) { }

	private static bool TryReadInt(Type inst_type, JsonReader reader, out int value) { }

	private static bool TryReadLong(Type inst_type, JsonReader reader, out long value) { }

	private static bool TryReadULong(Type inst_type, JsonReader reader, out ulong value) { }

	public static void UnregisterExporters() { }

	public static void UnregisterImporters() { }

	private static void WriteValue(object obj, JsonWriter writer, bool writer_is_private, int depth) { }

}

