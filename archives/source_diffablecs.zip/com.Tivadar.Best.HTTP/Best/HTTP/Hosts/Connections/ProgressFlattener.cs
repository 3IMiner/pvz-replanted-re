namespace Best.HTTP.Hosts.Connections;

internal class ProgressFlattener
{
	private struct FlattenedProgress
	{
		public HTTPRequest request; //Field offset: 0x0
		public OnProgressDelegate onProgress; //Field offset: 0x8
		public long progress; //Field offset: 0x10
		public long length; //Field offset: 0x18

	}

	private FlattenedProgress[] progresses; //Field offset: 0x10
	private bool hasProgress; //Field offset: 0x18

	public ProgressFlattener() { }

	public void DispatchProgressCallbacks() { }

	public void InsertOrUpdate(RequestEventInfo info, OnProgressDelegate onProgress) { }

}

