namespace Best.HTTP.Hosts.Connections;

public static class ConnectionHelper
{

	public static void EnqueueEvents(ConnectionBase connection, HTTPConnectionStates connectionState, HTTPRequest request, HTTPRequestStates requestState, Exception error) { }

	public static Uri GetRedirectUri(HTTPRequest request, string location) { }

	public static Exception HandleResponse(HTTPRequest request, out bool resendRequest, out HTTPConnectionStates proposedConnectionState, ref KeepAliveHeader keepAlive, LoggingContext loggingContext) { }

	public static void ResendRequestAndCloseConnection(ConnectionBase connection, HTTPRequest request) { }

}

