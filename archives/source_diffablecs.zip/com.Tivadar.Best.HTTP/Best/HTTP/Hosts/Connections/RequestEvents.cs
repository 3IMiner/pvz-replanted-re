namespace Best.HTTP.Hosts.Connections;

public enum RequestEvents
{
	Upgraded = 0,
	DownloadProgress = 1,
	UploadProgress = 2,
	StreamingData = 3,
	DownloadStarted = 4,
	StateChange = 5,
	SetState = 6,
	QueuedResend = 7,
	Resend = 8,
	Headers = 9,
	Timing = 10,
}

