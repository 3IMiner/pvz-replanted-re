namespace Best.HTTP.Hosts.Connections;

public interface IDownloadContentBufferAvailable
{

	public void BufferAvailable(DownloadContentStream stream) { }

}

