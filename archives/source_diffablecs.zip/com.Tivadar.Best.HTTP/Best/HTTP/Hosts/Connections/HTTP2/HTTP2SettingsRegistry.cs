namespace Best.HTTP.Hosts.Connections.HTTP2;

[DefaultMember("Item")]
public sealed class HTTP2SettingsRegistry
{
	[CompilerGenerated]
	private bool <IsReadOnly>k__BackingField; //Field offset: 0x10
	public Action<HTTP2SettingsRegistry, HTTP2Settings, UInt32, UInt32> OnSettingChangedEvent; //Field offset: 0x18
	private UInt32[] values; //Field offset: 0x20
	private Boolean[] changeFlags; //Field offset: 0x28
	[CompilerGenerated]
	private bool <IsChanged>k__BackingField; //Field offset: 0x30
	private HTTP2SettingsManager _parent; //Field offset: 0x38

	public private bool IsChanged
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 4
	}

	public private bool IsReadOnly
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 4
	}

	public uint Item
	{
		 get { } //Length: 46
		 set { } //Length: 259
	}

	public HTTP2SettingsRegistry(HTTP2SettingsManager parent, bool readOnly, bool treatItAsAlreadyChanged) { }

	internal HTTP2FrameHeaderAndPayload CreateFrame(LoggingContext context) { }

	[CompilerGenerated]
	public bool get_IsChanged() { }

	[CompilerGenerated]
	public bool get_IsReadOnly() { }

	public uint get_Item(HTTP2Settings setting) { }

	public void Merge(List<KeyValuePair`2<HTTP2Settings, UInt32>> settings) { }

	public void Merge(HTTP2SettingsRegistry from) { }

	[CompilerGenerated]
	private void set_IsChanged(bool value) { }

	[CompilerGenerated]
	private void set_IsReadOnly(bool value) { }

	public void set_Item(HTTP2Settings setting, uint value) { }

}

