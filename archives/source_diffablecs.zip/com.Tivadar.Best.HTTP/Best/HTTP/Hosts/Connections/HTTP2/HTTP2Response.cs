namespace Best.HTTP.Hosts.Connections.HTTP2;

public sealed class HTTP2Response : HTTPResponse
{
	[CompilerGenerated]
	private long <ExpectedContentLength>k__BackingField; //Field offset: 0x80
	private string contentEncoding; //Field offset: 0x88
	private bool isPrepared; //Field offset: 0x90
	private IDecompressor _decompressor; //Field offset: 0x98

	public private long ExpectedContentLength
	{
		[CompilerGenerated]
		 get { } //Length: 8
		[CompilerGenerated]
		private set { } //Length: 8
	}

	public HTTP2Response(HTTPRequest request, bool isFromCache) { }

	internal void AddHeaders(List<KeyValuePair`2<String, String>> headers) { }

	protected virtual void Dispose(bool disposing) { }

	internal void FinishProcessData() { }

	[CompilerGenerated]
	public long get_ExpectedContentLength() { }

	internal void Prepare(IDownloadContentBufferAvailable bufferAvailable) { }

	internal void ProcessData(BufferSegment payload) { }

	[CompilerGenerated]
	private void set_ExpectedContentLength(long value) { }

}

