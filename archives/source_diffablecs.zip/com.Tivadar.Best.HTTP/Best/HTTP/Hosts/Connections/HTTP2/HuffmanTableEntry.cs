namespace Best.HTTP.Hosts.Connections.HTTP2;

[IsReadOnly]
public struct HuffmanTableEntry
{
	public readonly uint Code; //Field offset: 0x0
	public readonly byte Bits; //Field offset: 0x4

	public HuffmanTableEntry(uint code, byte bits) { }

	public byte GetBitAtIdx(byte idx) { }

	public virtual string ToString() { }

}

