namespace Best.HTTP.Hosts.Connections.HTTP2;

public struct HTTP2AltSVCFrame
{
	public readonly HTTP2FrameHeaderAndPayload Header; //Field offset: 0x0
	public string Origin; //Field offset: 0x20
	public string AltSvcFieldValue; //Field offset: 0x28

	public HTTP2AltSVCFrame(HTTP2FrameHeaderAndPayload header) { }

}

