namespace Best.HTTP.Hosts.Connections.HTTP2;

public struct HTTP2SettingsFrame
{
	public readonly HTTP2FrameHeaderAndPayload Header; //Field offset: 0x0
	public List<KeyValuePair`2<HTTP2Settings, UInt32>> Settings; //Field offset: 0x20

	public HTTP2SettingsFlags Flags
	{
		 get { } //Length: 5
	}

	public HTTP2SettingsFrame(HTTP2FrameHeaderAndPayload header) { }

	public HTTP2SettingsFlags get_Flags() { }

	public virtual string ToString() { }

}

