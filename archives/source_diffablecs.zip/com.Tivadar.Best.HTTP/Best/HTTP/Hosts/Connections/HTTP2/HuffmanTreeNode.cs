namespace Best.HTTP.Hosts.Connections.HTTP2;

[IsReadOnly]
public struct HuffmanTreeNode
{
	public readonly ushort Value; //Field offset: 0x0
	public readonly ushort NextZeroIdx; //Field offset: 0x2
	public readonly ushort NextOneIdx; //Field offset: 0x4

	public HuffmanTreeNode(ushort value, ushort nextZeroIdx, ushort nextOneIdx) { }

	public virtual string ToString() { }

}

