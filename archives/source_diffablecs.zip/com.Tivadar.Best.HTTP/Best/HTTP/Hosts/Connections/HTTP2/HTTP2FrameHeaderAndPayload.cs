namespace Best.HTTP.Hosts.Connections.HTTP2;

public struct HTTP2FrameHeaderAndPayload
{
	public HTTP2FrameTypes Type; //Field offset: 0x0
	public byte Flags; //Field offset: 0x1
	public uint StreamId; //Field offset: 0x4
	public BufferSegment Payload; //Field offset: 0x8
	public bool DontUseMemPool; //Field offset: 0x18

	public string PayloadAsHex() { }

	public virtual string ToString() { }

}

