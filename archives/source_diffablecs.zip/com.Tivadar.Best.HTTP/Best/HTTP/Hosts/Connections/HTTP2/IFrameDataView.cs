namespace Best.HTTP.Hosts.Connections.HTTP2;

public interface IFrameDataView : IDisposable
{

	public long Length
	{
		 get { } //Length: 0
	}

	public long Position
	{
		 get { } //Length: 0
	}

	public void AddFrame(HTTP2FrameHeaderAndPayload frame) { }

	public long get_Length() { }

	public long get_Position() { }

	public int Read(Byte[] buffer, int offset, int count) { }

	public int ReadByte() { }

}

