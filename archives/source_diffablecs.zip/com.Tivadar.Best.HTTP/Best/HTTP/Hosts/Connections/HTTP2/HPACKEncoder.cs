namespace Best.HTTP.Hosts.Connections.HTTP2;

public sealed class HPACKEncoder
{
	[CompilerGenerated]
	private sealed class <>c__DisplayClass5_0
	{
		public HPACKEncoder <>4__this; //Field offset: 0x10
		public HTTP2Stream context; //Field offset: 0x18
		public BufferPoolMemoryStream bufferStream; //Field offset: 0x20

		public <>c__DisplayClass5_0() { }

		internal void <Encode>b__0(string header, List<String> values) { }

	}

	private HTTP2SettingsManager settingsRegistry; //Field offset: 0x10
	private HeaderTable requestTable; //Field offset: 0x18
	private HeaderTable responseTable; //Field offset: 0x20
	private LoggingContext _context; //Field offset: 0x28

	public HPACKEncoder(LoggingContext context, HTTP2SettingsManager registry) { }

	private static void AddCodePointToBuffer(HuffmanTableEntry code, Byte[] buffer, ref uint offset, ref byte bufferBitIdx, bool finishOnBoundary = false) { }

	private void CreateHeaderFrames(Queue<HTTP2FrameHeaderAndPayload> to, uint streamId, Byte[] dataToSend, uint payloadLength, bool hasBody) { }

	public void Decode(HTTP2Stream context, Stream stream, List<KeyValuePair`2<String, String>> to) { }

	private static uint DecodeInteger(byte N, Byte[] buffer, ref uint offset) { }

	private static uint DecodeInteger(byte N, byte data, Stream stream) { }

	private string DecodeString(Stream stream) { }

	public void Encode(HTTP2Stream context, HTTPRequest request, Queue<HTTP2FrameHeaderAndPayload> to, uint streamId) { }

	private static void EncodeInteger(uint value, byte N, Byte[] buffer, ref uint offset) { }

	private static void EncodeRawStringTo(string str, Byte[] buffer, ref uint offset) { }

	private static void EncodeString(string str, Byte[] buffer, ref uint offset) { }

	private static void EncodeStringWithHuffman(string str, uint encodedLength, Byte[] buffer, ref uint offset) { }

	private KeyValuePair<String, String> ReadIndexedHeader(byte firstByte, Stream stream) { }

	private KeyValuePair<String, String> ReadLiteralHeaderFieldNeverIndexed_IndexedName(byte firstByte, Stream stream) { }

	private KeyValuePair<String, String> ReadLiteralHeaderFieldNeverIndexed_NewName(byte firstByte, Stream stream) { }

	private KeyValuePair<String, String> ReadLiteralHeaderFieldWithIncrementalIndexing_IndexedName(byte firstByte, Stream stream) { }

	private KeyValuePair<String, String> ReadLiteralHeaderFieldWithIncrementalIndexing_NewName(byte firstByte, Stream stream) { }

	private KeyValuePair<String, String> ReadLiteralHeaderFieldwithoutIndexing_IndexedName(byte firstByte, Stream stream) { }

	private KeyValuePair<String, String> ReadLiteralHeaderFieldwithoutIndexing_NewName(byte firstByte, Stream stream) { }

	private static byte RequiredBytesToEncodeInteger(uint value, byte N) { }

	private static uint RequiredBytesToEncodeRawString(string str) { }

	private static uint RequiredBytesToEncodeString(string str) { }

	private static uint RequiredBytesToEncodeStringWithHuffman(string str) { }

	public virtual string ToString() { }

	private static void WriteDynamicTableSizeUpdate(Stream stream, ushort maxSize) { }

	private void WriteHeader(Stream stream, string header, string value) { }

	private static void WriteIndexedHeaderField(Stream stream, uint index) { }

	private static void WriteLiteralHeaderFieldNeverIndexed_IndexedName(Stream stream, uint index, string value) { }

	private static void WriteLiteralHeaderFieldNeverIndexed_NewName(Stream stream, string header, string value) { }

	private static void WriteLiteralHeaderFieldWithIncrementalIndexing_IndexedName(Stream stream, uint index, string value) { }

	private static void WriteLiteralHeaderFieldWithIncrementalIndexing_NewName(Stream stream, string header, string value) { }

	private static void WriteLiteralHeaderFieldWithoutIndexing_IndexedName(Stream stream, uint index, string value) { }

	private static void WriteLiteralHeaderFieldWithoutIndexing_NewName(Stream stream, string header, string value) { }

}

