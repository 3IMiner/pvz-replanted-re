namespace Best.HTTP.Hosts.Connections.HTTP2;

public struct HTTP2WindowUpdateFrame
{
	public readonly HTTP2FrameHeaderAndPayload Header; //Field offset: 0x0
	public byte ReservedBit; //Field offset: 0x20
	public uint WindowSizeIncrement; //Field offset: 0x24

	public HTTP2WindowUpdateFrame(HTTP2FrameHeaderAndPayload header) { }

	public virtual string ToString() { }

}

