namespace Best.HTTP.Hosts.Connections.HTTP2;

public sealed class HeaderFrameView : CommonFrameView
{

	public HeaderFrameView() { }

	public virtual void AddFrame(HTTP2FrameHeaderAndPayload frame) { }

	protected virtual bool AdvanceFrame() { }

	protected virtual long CalculateDataLengthForFrame(HTTP2FrameHeaderAndPayload frame) { }

}

