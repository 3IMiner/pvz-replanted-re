namespace Best.HTTP.Hosts.Connections.HTTP2;

[Il2CppEagerStaticClassConstruction]
internal static class HuffmanEncoder
{
	public const ushort EOS = 256; //Field offset: 0x0
	private static readonly HuffmanTableEntry[] StaticTable; //Field offset: 0x0
	private static readonly HuffmanTreeNode[] HuffmanTree; //Field offset: 0x8

	private static HuffmanEncoder() { }

	public static HuffmanTableEntry GetEntryForCodePoint(ushort codePoint) { }

	public static HuffmanTreeNode GetNext(HuffmanTreeNode current, byte bit) { }

	public static HuffmanTreeNode GetRoot() { }

}

