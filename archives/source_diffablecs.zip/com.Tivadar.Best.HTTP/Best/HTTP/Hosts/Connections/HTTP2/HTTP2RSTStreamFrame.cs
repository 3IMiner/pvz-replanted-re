namespace Best.HTTP.Hosts.Connections.HTTP2;

public struct HTTP2RSTStreamFrame
{
	public readonly HTTP2FrameHeaderAndPayload Header; //Field offset: 0x0
	public uint ErrorCode; //Field offset: 0x20

	public HTTP2ErrorCodes Error
	{
		 get { } //Length: 4
	}

	public HTTP2RSTStreamFrame(HTTP2FrameHeaderAndPayload header) { }

	public HTTP2ErrorCodes get_Error() { }

	public virtual string ToString() { }

}

