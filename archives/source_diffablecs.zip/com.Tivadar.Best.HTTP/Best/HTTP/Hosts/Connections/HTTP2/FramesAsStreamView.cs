namespace Best.HTTP.Hosts.Connections.HTTP2;

public sealed class FramesAsStreamView : Stream
{
	private IFrameDataView view; //Field offset: 0x28

	public virtual bool CanRead
	{
		 get { } //Length: 3
	}

	public virtual bool CanSeek
	{
		 get { } //Length: 3
	}

	public virtual bool CanWrite
	{
		 get { } //Length: 3
	}

	public virtual long Length
	{
		 get { } //Length: 70
	}

	public virtual long Position
	{
		 get { } //Length: 73
		 set { } //Length: 62
	}

	public FramesAsStreamView(IFrameDataView view) { }

	public void AddFrame(HTTP2FrameHeaderAndPayload frame) { }

	public virtual void Close() { }

	public virtual void Flush() { }

	public virtual bool get_CanRead() { }

	public virtual bool get_CanSeek() { }

	public virtual bool get_CanWrite() { }

	public virtual long get_Length() { }

	public virtual long get_Position() { }

	public virtual int Read(Byte[] buffer, int offset, int count) { }

	public virtual int ReadByte() { }

	public virtual long Seek(long offset, SeekOrigin origin) { }

	public virtual void set_Position(long value) { }

	public virtual void SetLength(long value) { }

	public virtual string ToString() { }

	public virtual void Write(Byte[] buffer, int offset, int count) { }

}

