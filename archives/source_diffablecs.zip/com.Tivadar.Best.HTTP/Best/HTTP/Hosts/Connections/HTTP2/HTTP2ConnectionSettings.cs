namespace Best.HTTP.Hosts.Connections.HTTP2;

public sealed class HTTP2ConnectionSettings
{
	public bool EnableHTTP2Connections; //Field offset: 0x10
	public uint HeaderTableSize; //Field offset: 0x14
	public uint MaxConcurrentStreams; //Field offset: 0x18
	public uint InitialStreamWindowSize; //Field offset: 0x1C
	public uint InitialConnectionWindowSize; //Field offset: 0x20
	public uint MaxFrameSize; //Field offset: 0x24
	public uint MaxHeaderListSize; //Field offset: 0x28
	public TimeSpan MaxIdleTime; //Field offset: 0x30
	public TimeSpan PingFrequency; //Field offset: 0x38
	public TimeSpan Timeout; //Field offset: 0x40
	public bool EnableConnectProtocol; //Field offset: 0x48
	public WebSocketOverHTTP2Settings WebSocketOverHTTP2Settings; //Field offset: 0x50

	public HTTP2ConnectionSettings() { }

}

