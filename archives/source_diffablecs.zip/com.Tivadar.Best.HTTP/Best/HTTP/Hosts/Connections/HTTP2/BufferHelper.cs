namespace Best.HTTP.Hosts.Connections.HTTP2;

public static class BufferHelper
{

	public static byte ReadBit(byte value, byte bitIdx) { }

	public static long ReadLong(BufferSegment buffer, int offset) { }

	public static ushort ReadUInt16(Byte[] buffer, int offset) { }

	public static uint ReadUInt24(Byte[] buffer, int offset) { }

	public static uint ReadUInt31(Byte[] buffer, int offset) { }

	public static uint ReadUInt31(BufferSegment buffer, int offset) { }

	public static uint ReadUInt32(Byte[] buffer, int offset) { }

	public static uint ReadUInt32(BufferSegment buffer, int offset) { }

	public static byte ReadValue(byte value, byte fromBit, byte toBit) { }

	public static byte SetBit(byte value, byte bitIdx, bool bitValue) { }

	public static byte SetBit(byte value, byte bitIdx, byte bitValue) { }

	public static void SetLong(Byte[] buffer, int offset, long value) { }

	public static void SetUInt16(Byte[] buffer, int offset, ushort value) { }

	public static void SetUInt24(Byte[] buffer, int offset, uint value) { }

	public static void SetUInt31(Byte[] buffer, int offset, uint value) { }

	public static void SetUInt32(Byte[] buffer, int offset, uint value) { }

}

