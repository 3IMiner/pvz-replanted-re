namespace Best.HTTP.Hosts.Connections.HTTP2;

public struct HTTP2GoAwayFrame
{
	public readonly HTTP2FrameHeaderAndPayload Header; //Field offset: 0x0
	public byte ReservedBit; //Field offset: 0x20
	public uint LastStreamId; //Field offset: 0x24
	public uint ErrorCode; //Field offset: 0x28
	public BufferSegment AdditionalDebugData; //Field offset: 0x30

	public HTTP2ErrorCodes Error
	{
		 get { } //Length: 4
	}

	public HTTP2GoAwayFrame(HTTP2FrameHeaderAndPayload header) { }

	public HTTP2ErrorCodes get_Error() { }

	public virtual string ToString() { }

}

