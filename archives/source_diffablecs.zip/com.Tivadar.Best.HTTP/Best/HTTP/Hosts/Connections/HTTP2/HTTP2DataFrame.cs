namespace Best.HTTP.Hosts.Connections.HTTP2;

public struct HTTP2DataFrame
{
	public readonly HTTP2FrameHeaderAndPayload Header; //Field offset: 0x0
	public Nullable<Byte> PadLength; //Field offset: 0x20
	public BufferSegment Data; //Field offset: 0x28

	public HTTP2DataFlags Flags
	{
		 get { } //Length: 5
	}

	public HTTP2DataFrame(HTTP2FrameHeaderAndPayload header) { }

	public HTTP2DataFlags get_Flags() { }

	public virtual string ToString() { }

}

