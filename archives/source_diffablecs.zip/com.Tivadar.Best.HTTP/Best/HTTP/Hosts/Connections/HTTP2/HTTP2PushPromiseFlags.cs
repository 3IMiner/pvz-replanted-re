namespace Best.HTTP.Hosts.Connections.HTTP2;

[Flags]
public enum HTTP2PushPromiseFlags
{
	None = 0,
	END_HEADERS = 4,
	PADDED = 8,
}

