namespace Best.HTTP.Hosts.Connections.HTTP2;

public struct HTTP2PriorityFrame
{
	public readonly HTTP2FrameHeaderAndPayload Header; //Field offset: 0x0
	public byte IsExclusive; //Field offset: 0x20
	public uint StreamDependency; //Field offset: 0x24
	public byte Weight; //Field offset: 0x28

	public HTTP2PriorityFrame(HTTP2FrameHeaderAndPayload header) { }

	public virtual string ToString() { }

}

