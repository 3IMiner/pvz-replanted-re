namespace Best.HTTP.Hosts.Connections.HTTP2;

public struct HTTP2PushPromiseFrame
{
	public readonly HTTP2FrameHeaderAndPayload Header; //Field offset: 0x0
	public Nullable<Byte> PadLength; //Field offset: 0x20
	public byte ReservedBit; //Field offset: 0x22
	public uint PromisedStreamId; //Field offset: 0x24
	public BufferSegment HeaderBlockFragment; //Field offset: 0x28

	public HTTP2PushPromiseFlags Flags
	{
		 get { } //Length: 5
	}

	public HTTP2PushPromiseFrame(HTTP2FrameHeaderAndPayload header) { }

	public HTTP2PushPromiseFlags get_Flags() { }

	public virtual string ToString() { }

}

