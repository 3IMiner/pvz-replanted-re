namespace Best.HTTP.Hosts.Connections.HTTP2;

internal sealed class HeaderTable
{
	private static String[] StaticTableValues; //Field offset: 0x0
	private static String[] StaticTable; //Field offset: 0x8
	[CompilerGenerated]
	private uint <DynamicTableSize>k__BackingField; //Field offset: 0x10
	private uint _maxDynamicTableSize; //Field offset: 0x14
	private List<KeyValuePair`2<String, String>> DynamicTable; //Field offset: 0x18
	private HTTP2SettingsRegistry settingsRegistry; //Field offset: 0x20

	public private uint DynamicTableSize
	{
		[CompilerGenerated]
		 get { } //Length: 4
		[CompilerGenerated]
		private set { } //Length: 4
	}

	public uint MaxDynamicTableSize
	{
		 get { } //Length: 4
		 set { } //Length: 13
	}

	private static HeaderTable() { }

	public HeaderTable(HTTP2SettingsRegistry registry) { }

	public void Add(KeyValuePair<String, String> header) { }

	private uint CalculateEntrySize(KeyValuePair<String, String> entry) { }

	private void EvictEntries(uint newHeaderSize) { }

	[CompilerGenerated]
	public uint get_DynamicTableSize() { }

	public uint get_MaxDynamicTableSize() { }

	public KeyValuePair<String, String> GetHeader(uint index) { }

	public KeyValuePair<UInt32, UInt32> GetIndex(string key, string value) { }

	public string GetKey(uint index) { }

	[CompilerGenerated]
	private void set_DynamicTableSize(uint value) { }

	public void set_MaxDynamicTableSize(uint value) { }

	public virtual string ToString() { }

}

