namespace Best.HTTP.Hosts.Connections.HTTP2;

public abstract class CommonFrameView : IFrameDataView, IDisposable
{
	[CompilerGenerated]
	private long <Length>k__BackingField; //Field offset: 0x10
	[CompilerGenerated]
	private long <Position>k__BackingField; //Field offset: 0x18
	protected List<HTTP2FrameHeaderAndPayload> frames; //Field offset: 0x20
	protected int currentFrameIdx; //Field offset: 0x28
	protected Byte[] data; //Field offset: 0x30
	protected int dataOffset; //Field offset: 0x38
	protected int maxOffset; //Field offset: 0x3C

	public override long Length
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		 set { } //Length: 5
	}

	public override long Position
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		 set { } //Length: 5
	}

	protected CommonFrameView() { }

	public abstract void AddFrame(HTTP2FrameHeaderAndPayload frame) { }

	protected abstract bool AdvanceFrame() { }

	protected abstract long CalculateDataLengthForFrame(HTTP2FrameHeaderAndPayload frame) { }

	public override void Dispose() { }

	[CompilerGenerated]
	public override long get_Length() { }

	[CompilerGenerated]
	public override long get_Position() { }

	public override int Read(Byte[] buffer, int offset, int count) { }

	public override int ReadByte() { }

	[CompilerGenerated]
	protected void set_Length(long value) { }

	[CompilerGenerated]
	protected void set_Position(long value) { }

	public virtual string ToString() { }

}

