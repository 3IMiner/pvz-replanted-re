namespace Best.HTTP.Hosts.Connections.HTTP2;

[Flags]
public enum HTTP2PingFlags
{
	None = 0,
	ACK = 1,
}

