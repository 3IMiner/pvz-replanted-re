namespace Best.HTTP.Hosts.Connections.HTTP2;

public sealed class CustomHTTP2StreamFactory : MulticastDelegate
{

	public CustomHTTP2StreamFactory(object object, IntPtr method) { }

	public override IAsyncResult BeginInvoke(HTTPRequest request, uint streamId, HTTP2ContentConsumer parentHandler, HTTP2SettingsManager registry, HPACKEncoder hpackEncoder, AsyncCallback callback, object object) { }

	public override HTTP2Stream EndInvoke(IAsyncResult result) { }

	public override HTTP2Stream Invoke(HTTPRequest request, uint streamId, HTTP2ContentConsumer parentHandler, HTTP2SettingsManager registry, HPACKEncoder hpackEncoder) { }

}

