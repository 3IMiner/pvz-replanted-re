namespace Best.HTTP.Hosts.Connections.HTTP2;

[Flags]
public enum HTTP2DataFlags
{
	None = 0,
	END_STREAM = 1,
	PADDED = 8,
}

