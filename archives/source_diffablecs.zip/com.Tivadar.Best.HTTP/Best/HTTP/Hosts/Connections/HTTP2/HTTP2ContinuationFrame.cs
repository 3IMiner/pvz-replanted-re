namespace Best.HTTP.Hosts.Connections.HTTP2;

public struct HTTP2ContinuationFrame
{
	public readonly HTTP2FrameHeaderAndPayload Header; //Field offset: 0x0
	public BufferSegment HeaderBlockFragment; //Field offset: 0x20

	public HTTP2ContinuationFlags Flags
	{
		 get { } //Length: 5
	}

	public HTTP2ContinuationFrame(HTTP2FrameHeaderAndPayload header) { }

	public HTTP2ContinuationFlags get_Flags() { }

	public virtual string ToString() { }

}

