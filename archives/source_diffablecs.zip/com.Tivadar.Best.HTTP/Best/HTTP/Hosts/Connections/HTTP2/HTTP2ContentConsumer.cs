namespace Best.HTTP.Hosts.Connections.HTTP2;

public sealed class HTTP2ContentConsumer : IHTTPRequestHandler, IDisposable, IContentConsumer, IThreadSignaler
{
	public const uint MaxValueFor31Bits = 2147483647; //Field offset: 0x0
	public static int RTTBufferCapacity; //Field offset: 0x0
	private int _assignedRequest; //Field offset: 0x10
	private int _maxAssignedRequests; //Field offset: 0x14
	[CompilerGenerated]
	private double <Latency>k__BackingField; //Field offset: 0x18
	public HTTP2SettingsManager settings; //Field offset: 0x20
	public HPACKEncoder HPACKEncoder; //Field offset: 0x28
	[CompilerGenerated]
	private LoggingContext <Context>k__BackingField; //Field offset: 0x30
	[CompilerGenerated]
	private PeekableContentProviderStream <ContentProvider>k__BackingField; //Field offset: 0x38
	private DateTime lastPingSent; //Field offset: 0x40
	private int waitingForPingAck; //Field offset: 0x48
	private CircularBuffer<Double> rtts; //Field offset: 0x50
	private bool isRunning; //Field offset: 0x58
	private AutoResetEvent newFrameSignal; //Field offset: 0x60
	private ConcurrentQueue<HTTPRequest> requestQueue; //Field offset: 0x68
	private List<HTTP2Stream> clientInitiatedStreams; //Field offset: 0x70
	private ConcurrentQueue<HTTP2FrameHeaderAndPayload> newFrames; //Field offset: 0x78
	private List<HTTP2FrameHeaderAndPayload> outgoingFrames; //Field offset: 0x80
	private uint remoteWindow; //Field offset: 0x88
	private DateTime lastInteraction; //Field offset: 0x90
	private DateTime goAwaySentAt; //Field offset: 0x98
	private HTTPOverTCPConnection conn; //Field offset: 0xA0
	private long LastStreamId; //Field offset: 0xA8
	private HTTP2ConnectionSettings _connectionSettings; //Field offset: 0xB0
	[CompilerGenerated]
	private ShutdownTypes <ShutdownType>k__BackingField; //Field offset: 0xB8

	public override int AssignedRequests
	{
		 get { } //Length: 4
	}

	public override bool CanProcessMultiple
	{
		 get { } //Length: 149
	}

	public private override PeekableContentProviderStream ContentProvider
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 13
	}

	public private override LoggingContext Context
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 13
	}

	public override KeepAliveHeader KeepAlive
	{
		 get { } //Length: 3
	}

	public private double Latency
	{
		[CompilerGenerated]
		 get { } //Length: 6
		[CompilerGenerated]
		private set { } //Length: 6
	}

	public override int MaxAssignedRequests
	{
		 get { } //Length: 4
	}

	private TimeSpan MaxGoAwayWaitTime
	{
		private get { } //Length: 301
	}

	private bool SentGoAwayFrame
	{
		private get { } //Length: 102
	}

	public private override ShutdownTypes ShutdownType
	{
		[CompilerGenerated]
		 get { } //Length: 7
		[CompilerGenerated]
		private set { } //Length: 7
	}

	private static HTTP2ContentConsumer() { }

	public HTTP2ContentConsumer(HTTPOverTCPConnection conn) { }

	private double CalculateLatency() { }

	public override void Dispose() { }

	private HTTP2Stream FindStreamById(uint streamId) { }

	public override int get_AssignedRequests() { }

	public override bool get_CanProcessMultiple() { }

	[CompilerGenerated]
	public override PeekableContentProviderStream get_ContentProvider() { }

	[CompilerGenerated]
	public override LoggingContext get_Context() { }

	public override KeepAliveHeader get_KeepAlive() { }

	[CompilerGenerated]
	public double get_Latency() { }

	public override int get_MaxAssignedRequests() { }

	private TimeSpan get_MaxGoAwayWaitTime() { }

	private bool get_SentGoAwayFrame() { }

	[CompilerGenerated]
	public override ShutdownTypes get_ShutdownType() { }

	public override void OnConnectionClosed() { }

	public override void OnContent() { }

	public override void OnError(Exception ex) { }

	private void OnRemoteSettingChanged(HTTP2SettingsRegistry registry, HTTP2Settings setting, uint oldValue, uint newValue) { }

	public override void Process(HTTPRequest request) { }

	public override void RunHandler() { }

	[CompilerGenerated]
	private void set_ContentProvider(PeekableContentProviderStream value) { }

	[CompilerGenerated]
	private void set_Context(LoggingContext value) { }

	[CompilerGenerated]
	private void set_Latency(double value) { }

	[CompilerGenerated]
	private void set_ShutdownType(ShutdownTypes value) { }

	public override void SetBinding(PeekableContentProviderStream contentProvider) { }

	public override void Shutdown(ShutdownTypes type) { }

	public override void SignalThread() { }

	public override void UnsetBinding() { }

}

