namespace Best.HTTP.Hosts.Connections.HTTP2;

public struct HTTP2HeadersFrame
{
	public readonly HTTP2FrameHeaderAndPayload Header; //Field offset: 0x0
	public Nullable<Byte> PadLength; //Field offset: 0x20
	public Nullable<Byte> IsExclusive; //Field offset: 0x22
	public Nullable<UInt32> StreamDependency; //Field offset: 0x24
	public Nullable<Byte> Weight; //Field offset: 0x2C
	public BufferSegment HeaderBlockFragment; //Field offset: 0x30

	public HTTP2HeadersFlags Flags
	{
		 get { } //Length: 5
	}

	public HTTP2HeadersFrame(HTTP2FrameHeaderAndPayload header) { }

	public HTTP2HeadersFlags get_Flags() { }

	public virtual string ToString() { }

}

