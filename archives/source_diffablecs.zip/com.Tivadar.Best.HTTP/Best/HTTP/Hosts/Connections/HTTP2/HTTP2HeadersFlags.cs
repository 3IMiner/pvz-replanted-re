namespace Best.HTTP.Hosts.Connections.HTTP2;

[Flags]
public enum HTTP2HeadersFlags
{
	None = 0,
	END_STREAM = 1,
	END_HEADERS = 4,
	PADDED = 8,
	PRIORITY = 32,
}

