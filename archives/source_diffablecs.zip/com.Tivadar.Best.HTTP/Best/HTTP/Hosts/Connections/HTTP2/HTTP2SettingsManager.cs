namespace Best.HTTP.Hosts.Connections.HTTP2;

public sealed class HTTP2SettingsManager
{
	public static readonly int KnownSettingsCount; //Field offset: 0x0
	[CompilerGenerated]
	private HTTP2SettingsRegistry <MySettings>k__BackingField; //Field offset: 0x10
	[CompilerGenerated]
	private HTTP2SettingsRegistry <InitiatedMySettings>k__BackingField; //Field offset: 0x18
	[CompilerGenerated]
	private HTTP2SettingsRegistry <RemoteSettings>k__BackingField; //Field offset: 0x20
	[CompilerGenerated]
	private DateTime <SettingsChangesSentAt>k__BackingField; //Field offset: 0x28
	[CompilerGenerated]
	private LoggingContext <Context>k__BackingField; //Field offset: 0x30
	private HTTP2ConnectionSettings _connectionSettings; //Field offset: 0x38

	public private LoggingContext Context
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 13
	}

	public private HTTP2SettingsRegistry InitiatedMySettings
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 13
	}

	public private HTTP2SettingsRegistry MySettings
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 13
	}

	public private HTTP2SettingsRegistry RemoteSettings
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 13
	}

	public private DateTime SettingsChangesSentAt
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 5
	}

	private static HTTP2SettingsManager() { }

	public HTTP2SettingsManager(LoggingContext context, HTTP2ConnectionSettings connectionSettings) { }

	[CompilerGenerated]
	public LoggingContext get_Context() { }

	[CompilerGenerated]
	public HTTP2SettingsRegistry get_InitiatedMySettings() { }

	[CompilerGenerated]
	public HTTP2SettingsRegistry get_MySettings() { }

	[CompilerGenerated]
	public HTTP2SettingsRegistry get_RemoteSettings() { }

	[CompilerGenerated]
	public DateTime get_SettingsChangesSentAt() { }

	internal void Process(HTTP2FrameHeaderAndPayload frame, List<HTTP2FrameHeaderAndPayload> outgoingFrames) { }

	internal void SendChanges(List<HTTP2FrameHeaderAndPayload> outgoingFrames) { }

	[CompilerGenerated]
	private void set_Context(LoggingContext value) { }

	[CompilerGenerated]
	private void set_InitiatedMySettings(HTTP2SettingsRegistry value) { }

	[CompilerGenerated]
	private void set_MySettings(HTTP2SettingsRegistry value) { }

	[CompilerGenerated]
	private void set_RemoteSettings(HTTP2SettingsRegistry value) { }

	[CompilerGenerated]
	private void set_SettingsChangesSentAt(DateTime value) { }

}

