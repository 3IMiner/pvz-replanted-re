namespace Best.HTTP.Hosts.Connections.HTTP2;

public static class HTTP2FrameHelper
{

	public static bool CanReadFullFrame(PeekableStream stream) { }

	public static HTTP2FrameHeaderAndPayload CreateACKSettingsFrame() { }

	public static HTTP2FrameHeaderAndPayload CreateGoAwayFrame(uint lastStreamId, HTTP2ErrorCodes error, LoggingContext context) { }

	public static HTTP2FrameHeaderAndPayload CreatePingFrame(HTTP2PingFlags flags, LoggingContext context) { }

	public static HTTP2FrameHeaderAndPayload CreateRSTFrame(uint streamId, HTTP2ErrorCodes errorCode, LoggingContext context) { }

	public static HTTP2FrameHeaderAndPayload CreateSettingsFrame(List<KeyValuePair`2<HTTP2Settings, UInt32>> settings, LoggingContext context) { }

	public static HTTP2FrameHeaderAndPayload CreateWindowUpdateFrame(uint streamId, uint windowSizeIncrement, LoggingContext context) { }

	public static AutoReleaseBuffer HeaderAsBinary(HTTP2FrameHeaderAndPayload header) { }

	public static HTTP2AltSVCFrame ReadAltSvcFrame(HTTP2FrameHeaderAndPayload header) { }

	public static HTTP2ContinuationFrame ReadContinuationFrame(HTTP2FrameHeaderAndPayload header) { }

	public static HTTP2DataFrame ReadDataFrame(HTTP2FrameHeaderAndPayload header) { }

	public static HTTP2GoAwayFrame ReadGoAwayFrame(HTTP2FrameHeaderAndPayload header) { }

	public static HTTP2FrameHeaderAndPayload ReadHeader(Stream stream, LoggingContext context) { }

	public static HTTP2HeadersFrame ReadHeadersFrame(HTTP2FrameHeaderAndPayload header) { }

	public static HTTP2PingFrame ReadPingFrame(HTTP2FrameHeaderAndPayload header) { }

	public static HTTP2PriorityFrame ReadPriorityFrame(HTTP2FrameHeaderAndPayload header) { }

	public static HTTP2PushPromiseFrame ReadPush_PromiseFrame(HTTP2FrameHeaderAndPayload header) { }

	public static HTTP2RSTStreamFrame ReadRST_StreamFrame(HTTP2FrameHeaderAndPayload header) { }

	public static HTTP2SettingsFrame ReadSettings(HTTP2FrameHeaderAndPayload header) { }

	public static HTTP2WindowUpdateFrame ReadWindowUpdateFrame(HTTP2FrameHeaderAndPayload header) { }

	public static void StreamRead(Stream stream, BufferSegment buffer) { }

	public static void StreamRead(Stream stream, Byte[] buffer, int offset, uint count) { }

}

