namespace Best.HTTP.Hosts.Connections.HTTP2;

public class HTTP2Stream : IDownloadContentBufferAvailable
{
	[CompilerGenerated]
	private uint <Id>k__BackingField; //Field offset: 0x10
	private HTTP2StreamStates _state; //Field offset: 0x14
	[CompilerGenerated]
	private readonly TimeSpan <NextInteraction>k__BackingField; //Field offset: 0x18
	[CompilerGenerated]
	private HTTPRequest <AssignedRequest>k__BackingField; //Field offset: 0x20
	[CompilerGenerated]
	private LoggingContext <Context>k__BackingField; //Field offset: 0x28
	protected uint downloaded; //Field offset: 0x30
	protected HTTP2SettingsManager settings; //Field offset: 0x38
	protected HPACKEncoder encoder; //Field offset: 0x40
	protected Queue<HTTP2FrameHeaderAndPayload> outgoing; //Field offset: 0x48
	protected Queue<HTTP2FrameHeaderAndPayload> incomingFrames; //Field offset: 0x50
	protected FramesAsStreamView headerView; //Field offset: 0x58
	protected long localWindow; //Field offset: 0x60
	protected long remoteWindow; //Field offset: 0x68
	protected uint windowUpdateThreshold; //Field offset: 0x70
	protected uint assignDataLength; //Field offset: 0x74
	protected long sentData; //Field offset: 0x78
	protected long uploadLength; //Field offset: 0x80
	protected bool isRSTFrameSent; //Field offset: 0x88
	protected bool isEndSTRReceived; //Field offset: 0x89
	protected HTTP2Response response; //Field offset: 0x90
	protected int lastReadCount; //Field offset: 0x98
	protected HTTP2ContentConsumer _parentHandler; //Field offset: 0xA0

	public HTTPRequest AssignedRequest
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		 set { } //Length: 13
	}

	public LoggingContext Context
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		 set { } //Length: 13
	}

	public override bool HasFrameToSend
	{
		 get { } //Length: 102
	}

	public private uint Id
	{
		[CompilerGenerated]
		 get { } //Length: 4
		[CompilerGenerated]
		private set { } //Length: 4
	}

	public override TimeSpan NextInteraction
	{
		[CompilerGenerated]
		 get { } //Length: 5
	}

	public HTTP2StreamStates State
	{
		 get { } //Length: 4
		 set { } //Length: 389
	}

	public HTTP2Stream(uint id, HTTP2ContentConsumer parentHandler, HTTP2SettingsManager registry, HPACKEncoder hpackEncoder) { }

	public void Abort(string msg) { }

	public void AddFrame(HTTP2FrameHeaderAndPayload frame, List<HTTP2FrameHeaderAndPayload> outgoingFrames) { }

	public override void Assign(HTTPRequest request) { }

	private override void Best.HTTP.Hosts.Connections.IDownloadContentBufferAvailable.BufferAvailable(DownloadContentStream stream) { }

	protected void FinishRequest() { }

	[CompilerGenerated]
	public HTTPRequest get_AssignedRequest() { }

	[CompilerGenerated]
	public LoggingContext get_Context() { }

	public override bool get_HasFrameToSend() { }

	[CompilerGenerated]
	public uint get_Id() { }

	[CompilerGenerated]
	public override TimeSpan get_NextInteraction() { }

	public HTTP2StreamStates get_State() { }

	protected void OnRemoteSettingChanged(HTTP2SettingsRegistry registry, HTTP2Settings setting, uint oldValue, uint newValue) { }

	public void Process(List<HTTP2FrameHeaderAndPayload> outgoingFrames) { }

	protected override void ProcessIncomingDATAFrame(ref HTTP2FrameHeaderAndPayload frame) { }

	protected void ProcessIncomingFrames(List<HTTP2FrameHeaderAndPayload> outgoingFrames) { }

	protected override void ProcessOpenState(List<HTTP2FrameHeaderAndPayload> outgoingFrames) { }

	protected void ProcessState(List<HTTP2FrameHeaderAndPayload> outgoingFrames) { }

	public void Removed() { }

	[CompilerGenerated]
	protected void set_AssignedRequest(HTTPRequest value) { }

	[CompilerGenerated]
	protected void set_Context(LoggingContext value) { }

	[CompilerGenerated]
	private void set_Id(uint value) { }

	protected void set_State(HTTP2StreamStates value) { }

}

