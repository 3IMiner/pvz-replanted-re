namespace Best.HTTP.Hosts.Connections.HTTP2;

[Flags]
public enum HTTP2ContinuationFlags
{
	None = 0,
	END_HEADERS = 4,
}

