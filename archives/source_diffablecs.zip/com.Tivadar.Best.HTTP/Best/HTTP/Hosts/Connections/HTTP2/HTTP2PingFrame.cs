namespace Best.HTTP.Hosts.Connections.HTTP2;

public struct HTTP2PingFrame
{
	public readonly HTTP2FrameHeaderAndPayload Header; //Field offset: 0x0
	public readonly BufferSegment OpaqueData; //Field offset: 0x20

	public HTTP2PingFlags Flags
	{
		 get { } //Length: 5
	}

	public HTTP2PingFrame(HTTP2FrameHeaderAndPayload header) { }

	public HTTP2PingFlags get_Flags() { }

	public virtual string ToString() { }

}

