namespace Best.HTTP.Hosts.Connections.HTTP2;

public sealed class WebSocketOverHTTP2Settings
{
	[CompilerGenerated]
	private bool <EnableWebSocketOverHTTP2>k__BackingField; //Field offset: 0x10
	[CompilerGenerated]
	private bool <EnableImplementationFallback>k__BackingField; //Field offset: 0x11

	public bool EnableImplementationFallback
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		 set { } //Length: 4
	}

	public bool EnableWebSocketOverHTTP2
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		 set { } //Length: 4
	}

	public WebSocketOverHTTP2Settings() { }

	[CompilerGenerated]
	public bool get_EnableImplementationFallback() { }

	[CompilerGenerated]
	public bool get_EnableWebSocketOverHTTP2() { }

	[CompilerGenerated]
	public void set_EnableImplementationFallback(bool value) { }

	[CompilerGenerated]
	public void set_EnableWebSocketOverHTTP2(bool value) { }

}

