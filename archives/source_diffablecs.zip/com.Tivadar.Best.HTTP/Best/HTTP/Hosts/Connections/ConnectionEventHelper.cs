namespace Best.HTTP.Hosts.Connections;

public static class ConnectionEventHelper
{
	private static ConcurrentQueue<ConnectionEventInfo> connectionEventQueue; //Field offset: 0x0
	public static Action<ConnectionEventInfo> OnEvent; //Field offset: 0x8

	private static ConnectionEventHelper() { }

	internal static void Clear() { }

	public static void EnqueueConnectionEvent(ConnectionEventInfo event) { }

	private static void HandleConnectionStateChange(ConnectionEventInfo event) { }

	internal static void ProcessQueue() { }

}

