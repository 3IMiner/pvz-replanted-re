namespace Best.HTTP.Hosts.Connections;

public abstract class ConnectionBase : IDisposable
{
	[CompilerGenerated]
	private HostKey <HostKey>k__BackingField; //Field offset: 0x10
	[CompilerGenerated]
	private HTTPConnectionStates <State>k__BackingField; //Field offset: 0x30
	[CompilerGenerated]
	private HTTPRequest <CurrentRequest>k__BackingField; //Field offset: 0x38
	[CompilerGenerated]
	private TimeSpan <KeepAliveTime>k__BackingField; //Field offset: 0x40
	[CompilerGenerated]
	private readonly int <MaxAssignedRequests>k__BackingField; //Field offset: 0x48
	[CompilerGenerated]
	private DateTime <StartTime>k__BackingField; //Field offset: 0x50
	[CompilerGenerated]
	private Uri <LastProcessedUri>k__BackingField; //Field offset: 0x58
	[CompilerGenerated]
	private DateTime <LastProcessTime>k__BackingField; //Field offset: 0x60
	[CompilerGenerated]
	private LoggingContext <Context>k__BackingField; //Field offset: 0x68
	protected bool IsThreaded; //Field offset: 0x70
	[CompilerGenerated]
	private ShutdownTypes <ShutdownType>k__BackingField; //Field offset: 0x74

	public override int AssignedRequests
	{
		 get { } //Length: 15
	}

	public override bool CanProcessMultiple
	{
		 get { } //Length: 3
	}

	public LoggingContext Context
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		 set { } //Length: 13
	}

	public internal HTTPRequest CurrentRequest
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		internal set { } //Length: 13
	}

	public HostKey HostKey
	{
		[CompilerGenerated]
		 get { } //Length: 19
		[CompilerGenerated]
		 set { } //Length: 26
	}

	public override TimeSpan KeepAliveTime
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		 set { } //Length: 5
	}

	public Uri LastProcessedUri
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		 set { } //Length: 13
	}

	public DateTime LastProcessTime
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		 set { } //Length: 5
	}

	public override int MaxAssignedRequests
	{
		[CompilerGenerated]
		 get { } //Length: 4
	}

	public ShutdownTypes ShutdownType
	{
		[CompilerGenerated]
		 get { } //Length: 4
		[CompilerGenerated]
		 set { } //Length: 4
	}

	public DateTime StartTime
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		 set { } //Length: 5
	}

	public internal HTTPConnectionStates State
	{
		[CompilerGenerated]
		 get { } //Length: 4
		[CompilerGenerated]
		internal set { } //Length: 4
	}

	public ConnectionBase(HostKey hostKey) { }

	public ConnectionBase(HostKey hostKey, bool threaded) { }

	protected override void Dispose(bool disposing) { }

	public override void Dispose() { }

	protected virtual void Finalize() { }

	public override int get_AssignedRequests() { }

	public override bool get_CanProcessMultiple() { }

	[CompilerGenerated]
	public LoggingContext get_Context() { }

	[CompilerGenerated]
	public HTTPRequest get_CurrentRequest() { }

	[CompilerGenerated]
	public HostKey get_HostKey() { }

	[CompilerGenerated]
	public override TimeSpan get_KeepAliveTime() { }

	[CompilerGenerated]
	public Uri get_LastProcessedUri() { }

	[CompilerGenerated]
	public DateTime get_LastProcessTime() { }

	[CompilerGenerated]
	public override int get_MaxAssignedRequests() { }

	[CompilerGenerated]
	public ShutdownTypes get_ShutdownType() { }

	[CompilerGenerated]
	public DateTime get_StartTime() { }

	[CompilerGenerated]
	public HTTPConnectionStates get_State() { }

	internal override void Process(HTTPRequest request) { }

	[CompilerGenerated]
	protected void set_Context(LoggingContext value) { }

	[CompilerGenerated]
	internal void set_CurrentRequest(HTTPRequest value) { }

	[CompilerGenerated]
	protected void set_HostKey(HostKey value) { }

	[CompilerGenerated]
	protected override void set_KeepAliveTime(TimeSpan value) { }

	[CompilerGenerated]
	protected void set_LastProcessedUri(Uri value) { }

	[CompilerGenerated]
	protected void set_LastProcessTime(DateTime value) { }

	[CompilerGenerated]
	protected void set_ShutdownType(ShutdownTypes value) { }

	[CompilerGenerated]
	protected void set_StartTime(DateTime value) { }

	[CompilerGenerated]
	internal void set_State(HTTPConnectionStates value) { }

	public override void Shutdown(ShutdownTypes type) { }

	protected override void ThreadFunc() { }

	public virtual string ToString() { }

}

