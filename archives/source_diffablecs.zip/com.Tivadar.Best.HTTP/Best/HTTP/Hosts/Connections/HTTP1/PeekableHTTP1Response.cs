namespace Best.HTTP.Hosts.Connections.HTTP1;

public class PeekableHTTP1Response : HTTPResponse
{
	internal enum ContentDeliveryMode
	{
		Raw = 0,
		RawUnknownLength = 1,
		Chunked = 2,
	}

	internal enum PeekableReadState
	{
		StatusLine = 0,
		Headers = 1,
		WaitForContentSent = 2,
		PrepareForContent = 3,
		ContentSetup = 4,
		Content = 5,
		Finished = 6,
	}

	private enum ReadChunkedStates
	{
		ReadChunkLength = 0,
		ReadChunk = 1,
		ReadTrailingCRLF = 2,
		ReadTrailingHeaders = 3,
	}

	private PeekableReadState _readState; //Field offset: 0x80
	public bool ForceDepleteContent; //Field offset: 0x84
	private ContentDeliveryMode _deliveryMode; //Field offset: 0x88
	private long _expectedLength; //Field offset: 0x90
	private Dictionary<String, List`1<String>> _newHeaders; //Field offset: 0x98
	private long _downloaded; //Field offset: 0xA0
	private IDecompressor _decompressor; //Field offset: 0xA8
	private bool _compressed; //Field offset: 0xB0
	private bool sendProgressChanged; //Field offset: 0xB1
	private int _chunkLength; //Field offset: 0xB4
	private ReadChunkedStates _readChunkedState; //Field offset: 0xB8
	private IDownloadContentBufferAvailable _bufferAvailableHandler; //Field offset: 0xC0
	private int _isProccessing; //Field offset: 0xC8

	public ContentDeliveryMode DeliveryMode
	{
		 get { } //Length: 7
	}

	public private PeekableReadState ReadState
	{
		 get { } //Length: 7
		private set { } //Length: 358
	}

	public PeekableHTTP1Response(HTTPRequest request, bool isFromCache, IDownloadContentBufferAvailable bufferAvailableHandler) { }

	protected virtual void Dispose(bool disposing) { }

	public ContentDeliveryMode get_DeliveryMode() { }

	public PeekableReadState get_ReadState() { }

	private bool IsNewLinePresent(PeekableStream peekable) { }

	private void PostProcessContent() { }

	private void ProcessChunk(BufferSegment chunk) { }

	public void ProcessPeekable(PeekableContentProviderStream peekable) { }

	private void ProcessReadChunked(PeekableStream peekable) { }

	private void ProcessReadHeaders(PeekableStream peekable, PeekableReadState targetState) { }

	private void ProcessReadRaw(PeekableStream peekable) { }

	private void ProcessReadRawUnknownLength(PeekableStream peekable) { }

	private void set_ReadState(PeekableReadState value) { }

	private bool TryReadChunkLength(PeekableStream peekable, out int result) { }

}

