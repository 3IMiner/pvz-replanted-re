namespace Best.HTTP.Hosts.Connections.HTTP1;

public static class Constants
{
	public const byte CR = 13; //Field offset: 0x0
	public const byte LF = 10; //Field offset: 0x0
	public static readonly Byte[] EOL; //Field offset: 0x0
	public static readonly Byte[] HeaderValueSeparator; //Field offset: 0x8

	private static Constants() { }

}

