namespace Best.HTTP.Hosts.Connections.HTTP1;

public sealed class HTTP1ContentConsumer : IHTTPRequestHandler, IDisposable, IContentConsumer, IDownloadContentBufferAvailable, IThreadSignaler
{
	[CompilerGenerated]
	private sealed class <>c__DisplayClass32_0
	{
		public HTTPRequest request; //Field offset: 0x10
		public WriteOnlyBufferedStream bufferStream; //Field offset: 0x18

		public <>c__DisplayClass32_0() { }

		internal void <SendOutTo>b__0(string header, List<String> values) { }

	}

	[CompilerGenerated]
	private ShutdownTypes <ShutdownType>k__BackingField; //Field offset: 0x10
	private KeepAliveHeader _keepAlive; //Field offset: 0x18
	[CompilerGenerated]
	private LoggingContext <Context>k__BackingField; //Field offset: 0x20
	[CompilerGenerated]
	private PeekableContentProviderStream <ContentProvider>k__BackingField; //Field offset: 0x28
	private readonly HTTPOverTCPConnection conn; //Field offset: 0x30
	private PeekableHTTP1Response _response; //Field offset: 0x38
	private int _isAlreadyProcessingContent; //Field offset: 0x40
	private WriteOnlyBufferedStream _upStream; //Field offset: 0x48
	private int _isSendingContent; //Field offset: 0x50
	private int _hasMoreData; //Field offset: 0x54
	private bool _isContentSendingFinished; //Field offset: 0x58
	private int _acceptContentSignals; //Field offset: 0x5C
	private long _uploaded; //Field offset: 0x60

	public override int AssignedRequests
	{
		 get { } //Length: 32
	}

	public override bool CanProcessMultiple
	{
		 get { } //Length: 3
	}

	public private override PeekableContentProviderStream ContentProvider
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 13
	}

	public private override LoggingContext Context
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 13
	}

	public override KeepAliveHeader KeepAlive
	{
		 get { } //Length: 5
	}

	public override int MaxAssignedRequests
	{
		 get { } //Length: 6
	}

	public private override ShutdownTypes ShutdownType
	{
		[CompilerGenerated]
		 get { } //Length: 4
		[CompilerGenerated]
		private set { } //Length: 4
	}

	public HTTP1ContentConsumer(HTTPOverTCPConnection conn) { }

	[CompilerGenerated]
	private void <OnConnectionClosed>b__38_0() { }

	private override void Best.HTTP.Hosts.Connections.IDownloadContentBufferAvailable.BufferAvailable(DownloadContentStream stream) { }

	private override void Best.HTTP.Hosts.Connections.IThreadSignaler.SignalThread() { }

	public override void Dispose() { }

	private void Dispose(bool disposing) { }

	private void FinishedProcessing(Exception ex) { }

	public override int get_AssignedRequests() { }

	public override bool get_CanProcessMultiple() { }

	[CompilerGenerated]
	public override PeekableContentProviderStream get_ContentProvider() { }

	[CompilerGenerated]
	public override LoggingContext get_Context() { }

	public override KeepAliveHeader get_KeepAlive() { }

	public override int get_MaxAssignedRequests() { }

	[CompilerGenerated]
	public override ShutdownTypes get_ShutdownType() { }

	private void OnCancellationRequested(HTTPRequest req) { }

	public override void OnConnectionClosed() { }

	public override void OnContent() { }

	public override void OnError(Exception e) { }

	public override void Process(HTTPRequest request) { }

	public override void RunHandler() { }

	private void SendContent(WriteOnlyBufferedStream streamToSend) { }

	private void SendOutTo(HTTPRequest request, Stream stream) { }

	[CompilerGenerated]
	private void set_ContentProvider(PeekableContentProviderStream value) { }

	[CompilerGenerated]
	private void set_Context(LoggingContext value) { }

	[CompilerGenerated]
	private void set_ShutdownType(ShutdownTypes value) { }

	public override void SetBinding(PeekableContentProviderStream contentProvider) { }

	public override void Shutdown(ShutdownTypes type) { }

	private void SignalThreadHandler() { }

	public override void UnsetBinding() { }

}

