namespace Best.HTTP.Hosts.Connections;

public interface IHTTPRequestHandler : IDisposable
{

	public int AssignedRequests
	{
		 get { } //Length: 0
	}

	public bool CanProcessMultiple
	{
		 get { } //Length: 0
	}

	public LoggingContext Context
	{
		 get { } //Length: 0
	}

	public KeepAliveHeader KeepAlive
	{
		 get { } //Length: 0
	}

	public int MaxAssignedRequests
	{
		 get { } //Length: 0
	}

	public ShutdownTypes ShutdownType
	{
		 get { } //Length: 0
	}

	public int get_AssignedRequests() { }

	public bool get_CanProcessMultiple() { }

	public LoggingContext get_Context() { }

	public KeepAliveHeader get_KeepAlive() { }

	public int get_MaxAssignedRequests() { }

	public ShutdownTypes get_ShutdownType() { }

	public void Process(HTTPRequest request) { }

	public void RunHandler() { }

	public void Shutdown(ShutdownTypes type) { }

}

