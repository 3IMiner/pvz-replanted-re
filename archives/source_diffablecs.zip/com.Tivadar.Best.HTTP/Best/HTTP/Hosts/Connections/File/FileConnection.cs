namespace Best.HTTP.Hosts.Connections.File;

internal sealed class FileConnection : ConnectionBase, IContentConsumer, IDownloadContentBufferAvailable
{
	[CompilerGenerated]
	private PeekableContentProviderStream <ContentProvider>k__BackingField; //Field offset: 0x78
	private PeekableHTTP1Response _response; //Field offset: 0x80
	private NonblockingUnderlyingStream _stream; //Field offset: 0x88
	private Hash128 _cacheHash; //Field offset: 0x90

	public private override PeekableContentProviderStream ContentProvider
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 13
	}

	public FileConnection(HostKey hostKey) { }

	private override void Best.HTTP.Hosts.Connections.IDownloadContentBufferAvailable.BufferAvailable(DownloadContentStream stream) { }

	private void FinishedProcessing(Exception ex) { }

	[CompilerGenerated]
	public override PeekableContentProviderStream get_ContentProvider() { }

	private void OnCancellationRequested(HTTPRequest req) { }

	public override void OnConnectionClosed() { }

	public override void OnContent() { }

	public override void OnError(Exception e) { }

	[CompilerGenerated]
	private void set_ContentProvider(PeekableContentProviderStream value) { }

	public override void SetBinding(PeekableContentProviderStream contentProvider) { }

	protected virtual void ThreadFunc() { }

	public override void UnsetBinding() { }

}

