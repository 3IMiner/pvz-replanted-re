namespace Best.HTTP.Hosts.Connections;

public enum ConnectionEvents
{
	StateChange = 0,
	ProtocolSupport = 1,
}

