namespace Best.HTTP.Hosts.Connections;

public sealed class HTTPOverTCPConnection : ConnectionBase, INegotiationPeer, IContentConsumer
{
	public IHTTPRequestHandler requestHandler; //Field offset: 0x78
	[CompilerGenerated]
	private readonly PeekableContentProviderStream <Best.HTTP.Shared.PlatformSupport.Network.Tcp.IContentConsumer.ContentProvider>k__BackingField; //Field offset: 0x80
	private Negotiator _negotiator; //Field offset: 0x88

	public virtual int AssignedRequests
	{
		 get { } //Length: 101
	}

	private override PeekableContentProviderStream Best.HTTP.Shared.PlatformSupport.Network.Tcp.IContentConsumer.ContentProvider
	{
		[CompilerGenerated]
		private get { } //Length: 8
	}

	public virtual bool CanProcessMultiple
	{
		 get { } //Length: 78
	}

	public virtual TimeSpan KeepAliveTime
	{
		 get { } //Length: 348
		 set { } //Length: 5
	}

	public virtual int MaxAssignedRequests
	{
		 get { } //Length: 79
	}

	public TCPStreamer Streamer
	{
		 get { } //Length: 30
	}

	public PeekableContentProviderStream TopStream
	{
		 get { } //Length: 30
	}

	internal HTTPOverTCPConnection(HostKey hostKey) { }

	[CompilerGenerated]
	private override PeekableContentProviderStream Best.HTTP.Shared.PlatformSupport.Network.Tcp.IContentConsumer.get_ContentProvider() { }

	private override void Best.HTTP.Shared.PlatformSupport.Network.Tcp.IContentConsumer.OnConnectionClosed() { }

	private override void Best.HTTP.Shared.PlatformSupport.Network.Tcp.IContentConsumer.OnContent() { }

	private override void Best.HTTP.Shared.PlatformSupport.Network.Tcp.IContentConsumer.OnError(Exception ex) { }

	private override void Best.HTTP.Shared.PlatformSupport.Network.Tcp.IContentConsumer.SetBinding(PeekableContentProviderStream contentProvider) { }

	private override void Best.HTTP.Shared.PlatformSupport.Network.Tcp.IContentConsumer.UnsetBinding() { }

	private override void Best.HTTP.Shared.PlatformSupport.Network.Tcp.INegotiationPeer.EvaluateProxyNegotiationFailure(Negotiator negotiator, Exception error, bool resendForAuthentication) { }

	private override List<String> Best.HTTP.Shared.PlatformSupport.Network.Tcp.INegotiationPeer.GetSupportedProtocolNames(Negotiator negotiator) { }

	private override bool Best.HTTP.Shared.PlatformSupport.Network.Tcp.INegotiationPeer.MustStopAdvancingToNextStep(Negotiator negotiator, NegotiationSteps finishedStep, NegotiationSteps nextStep, Exception error) { }

	private override void Best.HTTP.Shared.PlatformSupport.Network.Tcp.INegotiationPeer.OnNegotiationFailed(Negotiator negotiator, Exception error) { }

	private override void Best.HTTP.Shared.PlatformSupport.Network.Tcp.INegotiationPeer.OnNegotiationFinished(Negotiator negotiator, PeekableContentProviderStream stream, TCPStreamer streamer, string negotiatedProtocol) { }

	protected virtual void Dispose(bool disposing) { }

	public virtual int get_AssignedRequests() { }

	public virtual bool get_CanProcessMultiple() { }

	public virtual TimeSpan get_KeepAliveTime() { }

	public virtual int get_MaxAssignedRequests() { }

	public TCPStreamer get_Streamer() { }

	public PeekableContentProviderStream get_TopStream() { }

	private void OnCancellationRequested(HTTPRequest req) { }

	private bool PreprocessRequestState(Exception error) { }

	internal virtual void Process(HTTPRequest request) { }

	protected virtual void set_KeepAliveTime(TimeSpan value) { }

	public virtual void Shutdown(ShutdownTypes type) { }

	private void StartWithNegotiatedProtocol(string negotiatedProtocol, PeekableContentProviderStream stream) { }

	protected virtual void ThreadFunc() { }

	private bool TrySetErrorState(HTTPRequest request, Exception ex) { }

}

