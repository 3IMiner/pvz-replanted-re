namespace Best.HTTP.Hosts.Connections;

[IsReadOnly]
public struct ConnectionEventInfo
{
	public readonly ConnectionBase Source; //Field offset: 0x0
	public readonly ConnectionEvents Event; //Field offset: 0x8
	public readonly HTTPConnectionStates State; //Field offset: 0xC
	public readonly HostProtocolSupport ProtocolSupport; //Field offset: 0x10
	public readonly HTTPRequest Request; //Field offset: 0x18
	public readonly HTTPRequestStates RequestState; //Field offset: 0x20

	public ConnectionEventInfo(ConnectionBase sourceConn, ConnectionEvents event) { }

	public ConnectionEventInfo(ConnectionBase sourceConn, HTTPConnectionStates newState) { }

	public ConnectionEventInfo(ConnectionBase sourceConn, HostProtocolSupport protocolSupport) { }

	public ConnectionEventInfo(ConnectionBase sourceConn, HTTPRequest request) { }

	public virtual string ToString() { }

}

