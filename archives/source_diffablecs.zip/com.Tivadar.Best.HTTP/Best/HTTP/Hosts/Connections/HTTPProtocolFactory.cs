namespace Best.HTTP.Hosts.Connections;

public static class HTTPProtocolFactory
{
	public const string W3C_HTTP1 = "http/1.1"; //Field offset: 0x0
	public const string W3C_HTTP2 = "h2"; //Field offset: 0x0

	public static SupportedProtocols GetProtocolFromUri(Uri uri) { }

	public static bool IsSecureProtocol(Uri uri) { }

}

