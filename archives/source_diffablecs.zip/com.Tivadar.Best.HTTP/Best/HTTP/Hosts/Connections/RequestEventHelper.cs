namespace Best.HTTP.Hosts.Connections;

public static class RequestEventHelper
{
	private static ConcurrentQueue<RequestEventInfo> requestEventQueue; //Field offset: 0x0
	public static Action<RequestEventInfo> OnEvent; //Field offset: 0x8
	private static ProgressFlattener downloadProgress; //Field offset: 0x10
	private static ProgressFlattener uploadProgress; //Field offset: 0x18
	private static readonly String[] RequestStateNames; //Field offset: 0x20

	private static RequestEventHelper() { }

	private static bool AbortRequestWhenTimedOut(DateTime now, object context) { }

	internal static void Clear() { }

	public static void EnqueueRequestEvent(RequestEventInfo ev) { }

	private static void HandleQueued(HTTPRequest source) { }

	private static void HandleRequestStateChange(ref RequestEventInfo event) { }

	private static bool OnDelayedDisposeTimer(DateTime time, object request) { }

	internal static void ProcessQueue() { }

}

