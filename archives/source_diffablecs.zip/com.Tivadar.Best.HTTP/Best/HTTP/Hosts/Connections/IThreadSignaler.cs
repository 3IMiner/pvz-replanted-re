namespace Best.HTTP.Hosts.Connections;

public interface IThreadSignaler
{

	public LoggingContext Context
	{
		 get { } //Length: 0
	}

	public LoggingContext get_Context() { }

	public void SignalThread() { }

}

