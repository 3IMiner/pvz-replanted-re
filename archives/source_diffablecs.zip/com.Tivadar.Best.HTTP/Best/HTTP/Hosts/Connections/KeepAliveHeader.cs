namespace Best.HTTP.Hosts.Connections;

public sealed class KeepAliveHeader
{
	[CompilerGenerated]
	private TimeSpan <TimeOut>k__BackingField; //Field offset: 0x10
	[CompilerGenerated]
	private int <MaxRequests>k__BackingField; //Field offset: 0x18

	public private int MaxRequests
	{
		[CompilerGenerated]
		 get { } //Length: 4
		[CompilerGenerated]
		private set { } //Length: 4
	}

	public private TimeSpan TimeOut
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 5
	}

	public KeepAliveHeader() { }

	[CompilerGenerated]
	public int get_MaxRequests() { }

	[CompilerGenerated]
	public TimeSpan get_TimeOut() { }

	public void Parse(List<String> headerValues) { }

	[CompilerGenerated]
	private void set_MaxRequests(int value) { }

	[CompilerGenerated]
	private void set_TimeOut(TimeSpan value) { }

}

