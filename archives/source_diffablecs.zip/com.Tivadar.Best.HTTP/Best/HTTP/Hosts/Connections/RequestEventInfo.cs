namespace Best.HTTP.Hosts.Connections;

[IsReadOnly]
public struct RequestEventInfo
{
	public readonly HTTPRequest SourceRequest; //Field offset: 0x0
	public readonly RequestEvents Event; //Field offset: 0x8
	public readonly HTTPRequestStates State; //Field offset: 0xC
	public readonly Exception Error; //Field offset: 0x10
	public readonly long Progress; //Field offset: 0x18
	public readonly long ProgressLength; //Field offset: 0x20
	public readonly Byte[] Data; //Field offset: 0x28
	public readonly int DataLength; //Field offset: 0x30
	public readonly TimingEventInfo timingEvent; //Field offset: 0x38
	public readonly Dictionary<String, List`1<String>> Headers; //Field offset: 0x58

	public RequestEventInfo(HTTPRequest request, RequestEvents event) { }

	public RequestEventInfo(HTTPRequest request, RequestEvents event, HTTPRequestStates newState) { }

	public RequestEventInfo(HTTPRequest request, HTTPRequestStates newState) { }

	public RequestEventInfo(HTTPRequest request, HTTPRequestStates newState, Exception error) { }

	public RequestEventInfo(HTTPRequest request, RequestEvents event, long progress, long progressLength) { }

	public RequestEventInfo(HTTPRequest request, Byte[] data, int dataLength) { }

	public RequestEventInfo(HTTPRequest request, Dictionary<String, List`1<String>> headers) { }

	public RequestEventInfo(HTTPRequest request, TimingEventInfo timingEvent) { }

	public virtual string ToString() { }

}

