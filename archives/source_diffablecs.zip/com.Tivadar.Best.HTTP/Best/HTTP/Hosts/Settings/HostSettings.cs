namespace Best.HTTP.Hosts.Settings;

public class HostSettings
{
	public LowLevelConnectionSettings LowLevelConnectionSettings; //Field offset: 0x10
	public HTTRequestSettings RequestSettings; //Field offset: 0x18
	public HTTP1ConnectionSettings HTTP1ConnectionSettings; //Field offset: 0x20
	public TCPRingmasterSettings TCPRingmasterSettings; //Field offset: 0x28
	public HTTP2ConnectionSettings HTTP2ConnectionSettings; //Field offset: 0x30
	public TLSSettings TLSSettings; //Field offset: 0x38
	public HostVariantSettings HostVariantSettings; //Field offset: 0x40

	public HostSettings() { }

}

