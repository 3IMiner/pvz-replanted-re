namespace Best.HTTP.Hosts.Settings;

public enum TLSHandlers
{
	BouncyCastle = 0,
	Framework = 1,
}

