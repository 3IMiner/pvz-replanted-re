namespace Best.HTTP.Hosts.Settings;

public class FrameworkTLSSettings
{
	[CompilerGenerated]
	private sealed class <>c
	{
		public static readonly <>c <>9; //Field offset: 0x0

		private static <>c() { }

		public <>c() { }

		internal bool <.cctor>b__6_0(string host, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { }

	}

	public static Func<String, X509Certificate, X509Chain, SslPolicyErrors, Boolean> DefaultCertificationValidator; //Field offset: 0x0
	public SslProtocols TlsVersions; //Field offset: 0x10
	public bool CheckCertificateRevocation; //Field offset: 0x14
	public Func<String, X509Certificate, X509Chain, SslPolicyErrors, Boolean> CertificationValidator; //Field offset: 0x18
	public ClientCertificateSelector ClientCertificationProvider; //Field offset: 0x20

	private static FrameworkTLSSettings() { }

	public FrameworkTLSSettings() { }

}

