namespace Best.HTTP.Hosts.Settings;

public class TLSSettings
{
	public TLSHandlers TLSHandler; //Field offset: 0x10
	public BouncyCastleSettings BouncyCastleSettings; //Field offset: 0x18
	public FrameworkTLSSettings FrameworkTLSSettings; //Field offset: 0x20

	public TLSSettings() { }

}

