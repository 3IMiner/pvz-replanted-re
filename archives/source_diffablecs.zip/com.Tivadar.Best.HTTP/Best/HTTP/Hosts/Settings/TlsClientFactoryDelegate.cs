namespace Best.HTTP.Hosts.Settings;

public sealed class TlsClientFactoryDelegate : MulticastDelegate
{

	public TlsClientFactoryDelegate(object object, IntPtr method) { }

	public override IAsyncResult BeginInvoke(Uri uri, List<ProtocolName> protocols, LoggingContext context, AsyncCallback callback, object object) { }

	public override AbstractTls13Client EndInvoke(IAsyncResult result) { }

	public override AbstractTls13Client Invoke(Uri uri, List<ProtocolName> protocols, LoggingContext context) { }

}

