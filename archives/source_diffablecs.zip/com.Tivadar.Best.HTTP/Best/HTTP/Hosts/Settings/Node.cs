namespace Best.HTTP.Hosts.Settings;

internal sealed class Node
{
	public string key; //Field offset: 0x10
	public SortedList<String, Node> childNodes; //Field offset: 0x18
	public HostSettings hostSettings; //Field offset: 0x20

	public Node(string key) { }

	public Node(string key, HostSettings settings) { }

	public void Add(string subKey, Node subNode) { }

	public void Add(List<String> segments, HostSettings settings) { }

	public void AddSetting(HostSettings settings) { }

	public HostSettings Find(List<String> segments) { }

}

