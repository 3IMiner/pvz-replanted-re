namespace Best.HTTP.Hosts.Settings;

[Il2CppEagerStaticClassConstruction]
internal sealed class AsteriskStringComparer : IComparer<String>
{
	public static readonly AsteriskStringComparer Instance; //Field offset: 0x0

	private static AsteriskStringComparer() { }

	public AsteriskStringComparer() { }

	public override int Compare(string x, string y) { }

}

