namespace Best.HTTP.Hosts.Settings;

public class BouncyCastleSettings
{
	public TlsClientFactoryDelegate TlsClientFactory; //Field offset: 0x10

	public BouncyCastleSettings() { }

	public static AbstractTls13Client DefaultTlsClientFactory(Uri uri, List<ProtocolName> protocols, LoggingContext context) { }

}

