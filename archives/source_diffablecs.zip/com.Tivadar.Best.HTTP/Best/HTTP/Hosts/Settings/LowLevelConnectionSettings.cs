namespace Best.HTTP.Hosts.Settings;

public class LowLevelConnectionSettings
{
	public uint TCPWriteBufferSize; //Field offset: 0x10
	public uint ReadBufferSize; //Field offset: 0x14

	public LowLevelConnectionSettings() { }

}

