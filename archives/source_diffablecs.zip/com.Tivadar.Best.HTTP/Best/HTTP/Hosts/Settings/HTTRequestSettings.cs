namespace Best.HTTP.Hosts.Settings;

public class HTTRequestSettings
{
	public TimeSpan ConnectTimeout; //Field offset: 0x10
	public TimeSpan RequestTimeout; //Field offset: 0x18

	public HTTRequestSettings() { }

}

