namespace Best.HTTP.Hosts.Settings;

public sealed class HostSettingsManager
{
	[CompilerGenerated]
	private sealed class <>c__DisplayClass12_0
	{
		public HostSettings foundSettings; //Field offset: 0x10

		public <>c__DisplayClass12_0() { }

		internal HostSettings <Get>b__0(string key, HostSettings settings) { }

	}

	private const char SPLITTER = '\u2E'; //Field offset: 0x0
	private SortedList<String, Node> _rootNodes; //Field offset: 0x10
	private List<String> _segments; //Field offset: 0x18
	private ConcurrentDictionary<String, HostSettings> _cache; //Field offset: 0x20

	public HostSettingsManager() { }

	public HostSettings Add(Uri uri, HostSettings settings) { }

	public HostSettings Add(string hostname, HostSettings settings) { }

	public HostSettings AddDefault(Uri uri) { }

	public HostSettings AddDefault(string hostname) { }

	public void Clear() { }

	public HostSettings Get(HostVariant variant, bool fallbackToWildcard = true) { }

	public HostSettings Get(HostKey hostKey, bool fallbackToWildcard = true) { }

	public HostSettings Get(Uri uri, bool fallbackToWildcard = true) { }

	public HostSettings Get(string hostname, bool fallbackToWildcard = true) { }

}

