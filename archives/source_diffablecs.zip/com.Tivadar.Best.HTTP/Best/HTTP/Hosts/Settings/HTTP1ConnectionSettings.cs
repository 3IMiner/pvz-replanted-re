namespace Best.HTTP.Hosts.Settings;

public class HTTP1ConnectionSettings
{
	public bool TryToReuseConnections; //Field offset: 0x10
	public TimeSpan MaxConnectionIdleTime; //Field offset: 0x18
	public bool ForceUseThreadPool; //Field offset: 0x20

	public HTTP1ConnectionSettings() { }

}

