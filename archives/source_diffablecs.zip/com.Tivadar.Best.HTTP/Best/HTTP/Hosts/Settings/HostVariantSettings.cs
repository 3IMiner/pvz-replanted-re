namespace Best.HTTP.Hosts.Settings;

public class HostVariantSettings
{
	[CompilerGenerated]
	private sealed class <>c
	{
		public static readonly <>c <>9; //Field offset: 0x0
		public static Func<HostVariantSettings, HostKey, HostVariant> <>9__4_0; //Field offset: 0x8

		private static <>c() { }

		public <>c() { }

		internal HostVariant <.ctor>b__4_0(HostVariantSettings settings, HostKey key) { }

	}

	public int MaxConnectionPerVariant; //Field offset: 0x10
	public float MaxAssignedRequestsFactor; //Field offset: 0x14
	public Func<HostVariantSettings, HostKey, HostVariant> VariantFactory; //Field offset: 0x18
	public Func<HostVariantSettings, HostVariant, ConnectionBase> ConnectionFactory; //Field offset: 0x20

	public HostVariantSettings() { }

}

