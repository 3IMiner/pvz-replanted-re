namespace Best.HTTP.Profiler.Memory;

public sealed class MemoryStats
{
	public const string CategoryName = "Best - Memory"; //Field offset: 0x0
	public static readonly ProfilerCategory Category; //Field offset: 0x0
	public const string BorrowedName = "Borrowed"; //Field offset: 0x0
	public const string PooledName = "Pooled"; //Field offset: 0x0
	public const string CacheHitsName = "Cache Hits"; //Field offset: 0x0
	public const string ArrayAllocationsName = "Array Allocations (Cache Misses)"; //Field offset: 0x0
	public static readonly ProfilerCounterValue<Int64> Borrowed; //Field offset: 0x2
	public static readonly ProfilerCounterValue<Int64> Pooled; //Field offset: 0x3
	public static readonly ProfilerCounterValue<Int64> CacheHits; //Field offset: 0x4
	public static readonly ProfilerCounterValue<Int64> ArrayAllocations; //Field offset: 0x5

	private static MemoryStats() { }

	public MemoryStats() { }

}

