namespace Best.HTTP.Profiler.Network;

public sealed class NetworkStats
{
	public const string CategoryName = "Best - Network"; //Field offset: 0x0
	public const string TotalDNSCacheHits = "DNS Cache Hits"; //Field offset: 0x0
	public const string TotalConnectionsName = "Total Connections"; //Field offset: 0x0
	public const string OpenConnectionsName = "Open Connections"; //Field offset: 0x0
	public const string ReceivedTotalName = "Received Total"; //Field offset: 0x0
	public const string TotalDNSCacheMiss = "DNS Cache Miss"; //Field offset: 0x0
	public const string ReceivedSinceLastFrameName = "Received (Since Last Frame)"; //Field offset: 0x0
	public const string ReceivedAndUnprocessedName = "Received and Unprocessed"; //Field offset: 0x0
	public const string SentTotalName = "Sent Total"; //Field offset: 0x0
	public const string SentSinceLastFrameName = "Sent (Since Last Frame)"; //Field offset: 0x0
	public const string BufferedToSendName = "Buffered to Send"; //Field offset: 0x0
	public static readonly ProfilerCategory Category; //Field offset: 0x0
	public static readonly ProfilerCounterValue<Int64> BufferedToSend; //Field offset: 0x2
	public static readonly ProfilerCounterValue<Int64> SentSinceLastFrame; //Field offset: 0x3
	public static readonly ProfilerCounterValue<Int64> SentTotal; //Field offset: 0x4
	public static readonly ProfilerCounterValue<Int64> ReceivedSinceLastFrame; //Field offset: 0x5
	public static readonly ProfilerCounterValue<Int64> ReceivedAndUnprocessed; //Field offset: 0x6
	public static readonly ProfilerCounterValue<Int64> ReceivedTotal; //Field offset: 0x7
	public static readonly ProfilerCounterValue<Int32> OpenConnectionsCounter; //Field offset: 0x8
	public static readonly ProfilerCounterValue<Int32> TotalConnectionsCounter; //Field offset: 0x9
	public static readonly ProfilerCounterValue<Int32> TotalDNSCacheHitsCounter; //Field offset: 0xA
	public static readonly ProfilerCounterValue<Int32> TotalDNSCacheMissCounter; //Field offset: 0xB

	private static NetworkStats() { }

	public NetworkStats() { }

}

