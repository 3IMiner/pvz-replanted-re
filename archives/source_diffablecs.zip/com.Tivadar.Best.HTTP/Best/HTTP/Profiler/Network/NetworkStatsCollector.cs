namespace Best.HTTP.Profiler.Network;

public static class NetworkStatsCollector
{
	private static long _totalNetworkBytesReceived; //Field offset: 0x0
	private static long _totalNetworkBytesSent; //Field offset: 0x8
	private static int _totalConnections; //Field offset: 0x10
	private static int _openConnections; //Field offset: 0x14
	private static int _bufferedToSend; //Field offset: 0x18
	private static int _receivedAndUnprocessed; //Field offset: 0x1C

	public static int BufferedToSend
	{
		 get { } //Length: 54
	}

	public static int OpenConnections
	{
		 get { } //Length: 54
	}

	public static int ReceivedAndUnprocessed
	{
		 get { } //Length: 54
	}

	public static int TotalConnections
	{
		 get { } //Length: 54
	}

	public static long TotalNetworkBytesReceived
	{
		 get { } //Length: 54
	}

	public static long TotalNetworkBytesSent
	{
		 get { } //Length: 55
	}

	internal static void DecrementCurrentConnections() { }

	public static int get_BufferedToSend() { }

	public static int get_OpenConnections() { }

	public static int get_ReceivedAndUnprocessed() { }

	public static int get_TotalConnections() { }

	public static long get_TotalNetworkBytesReceived() { }

	public static long get_TotalNetworkBytesSent() { }

	internal static void IncrementBufferedToSend(int amount) { }

	internal static void IncrementCurrentConnections() { }

	internal static void IncrementReceivedAndUnprocessed(int amount) { }

	internal static void IncrementTotalNetworkBytesReceived(int amount) { }

	internal static void IncrementTotalNetworkBytesSent(int amount) { }

	internal static void ResetNetworkStats() { }

}

