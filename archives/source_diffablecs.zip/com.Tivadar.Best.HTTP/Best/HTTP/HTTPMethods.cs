namespace Best.HTTP;

public enum HTTPMethods
{
	Get = 0,
	Head = 1,
	Post = 2,
	Put = 3,
	Delete = 4,
	Patch = 5,
	Trace = 6,
	Merge = 7,
	Options = 8,
	Connect = 9,
	Query = 10,
}

