namespace Best.HTTP;

public class HTTPResponse : IDisposable
{
	[CompilerGenerated]
	private Version <HTTPVersion>k__BackingField; //Field offset: 0x10
	[CompilerGenerated]
	private int <StatusCode>k__BackingField; //Field offset: 0x18
	[CompilerGenerated]
	private string <Message>k__BackingField; //Field offset: 0x20
	[CompilerGenerated]
	private bool <IsFromCache>k__BackingField; //Field offset: 0x28
	[CompilerGenerated]
	private Dictionary<String, List`1<String>> <Headers>k__BackingField; //Field offset: 0x30
	private Byte[] _data; //Field offset: 0x38
	[CompilerGenerated]
	private bool <IsUpgraded>k__BackingField; //Field offset: 0x40
	protected string dataAsText; //Field offset: 0x48
	protected Texture2D texture; //Field offset: 0x50
	[CompilerGenerated]
	private DownloadContentStream <DownStream>k__BackingField; //Field offset: 0x58
	[CompilerGenerated]
	private LoggingContext <Context>k__BackingField; //Field offset: 0x60
	[CompilerGenerated]
	private HTTPRequest <Request>k__BackingField; //Field offset: 0x68
	protected HTTPCacheContentWriter _cacheWriter; //Field offset: 0x70
	private bool _isDisposed; //Field offset: 0x78

	public private LoggingContext Context
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 13
	}

	public Byte[] Data
	{
		 get { } //Length: 657
	}

	public string DataAsText
	{
		 get { } //Length: 221
	}

	public Texture2D DataAsTexture2D
	{
		 get { } //Length: 244
	}

	public internal DownloadContentStream DownStream
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		internal set { } //Length: 13
	}

	public Dictionary<String, List`1<String>> Headers
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		 set { } //Length: 13
	}

	public Version HTTPVersion
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		 set { } //Length: 13
	}

	public internal bool IsFromCache
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		internal set { } //Length: 4
	}

	public bool IsSuccess
	{
		 get { } //Length: 32
	}

	public internal bool IsUpgraded
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		internal set { } //Length: 4
	}

	public string Message
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		 set { } //Length: 13
	}

	public private HTTPRequest Request
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 13
	}

	public int StatusCode
	{
		[CompilerGenerated]
		 get { } //Length: 4
		[CompilerGenerated]
		 set { } //Length: 4
	}

	internal HTTPResponse(HTTPRequest request, bool isFromCache) { }

	public void AddHeader(string name, string value) { }

	protected void BeginReceiveContent() { }

	protected void CheckDisposed() { }

	protected void CreateDownloadStream(IDownloadContentBufferAvailable bufferAvailable) { }

	protected override void Dispose(bool disposing) { }

	public override void Dispose() { }

	protected void FeedDownloadedContentChunk(BufferSegment segment) { }

	protected void FinishedContentReceiving() { }

	[CompilerGenerated]
	public LoggingContext get_Context() { }

	public Byte[] get_Data() { }

	public string get_DataAsText() { }

	public Texture2D get_DataAsTexture2D() { }

	[CompilerGenerated]
	public DownloadContentStream get_DownStream() { }

	[CompilerGenerated]
	public Dictionary<String, List`1<String>> get_Headers() { }

	[CompilerGenerated]
	public Version get_HTTPVersion() { }

	[CompilerGenerated]
	public bool get_IsFromCache() { }

	public bool get_IsSuccess() { }

	[CompilerGenerated]
	public bool get_IsUpgraded() { }

	[CompilerGenerated]
	public string get_Message() { }

	[CompilerGenerated]
	public HTTPRequest get_Request() { }

	[CompilerGenerated]
	public int get_StatusCode() { }

	public string GetFirstHeaderValue(string name) { }

	public List<String> GetHeaderValues(string name) { }

	public HTTPRange GetRange() { }

	public bool HasHeader(string headerName) { }

	public bool HasHeaderWithValue(string headerName, string value) { }

	internal static string NoTrimReadTo(Stream stream, byte blocker1, byte blocker2) { }

	internal static string ReadTo(Stream stream, byte blocker) { }

	internal static string ReadTo(Stream stream, byte blocker1, byte blocker2) { }

	internal static BufferSegment ReadToAsByte(Stream stream, byte blocker) { }

	[CompilerGenerated]
	private void set_Context(LoggingContext value) { }

	[CompilerGenerated]
	internal void set_DownStream(DownloadContentStream value) { }

	[CompilerGenerated]
	protected void set_Headers(Dictionary<String, List`1<String>> value) { }

	[CompilerGenerated]
	protected void set_HTTPVersion(Version value) { }

	[CompilerGenerated]
	internal void set_IsFromCache(bool value) { }

	[CompilerGenerated]
	internal void set_IsUpgraded(bool value) { }

	[CompilerGenerated]
	protected void set_Message(string value) { }

	[CompilerGenerated]
	private void set_Request(HTTPRequest value) { }

	[CompilerGenerated]
	protected void set_StatusCode(int value) { }

}

