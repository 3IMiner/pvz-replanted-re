namespace Best.HTTP.Caching;

public sealed class HTTPCacheOptions
{
	[CompilerGenerated]
	private TimeSpan <DeleteOlder>k__BackingField; //Field offset: 0x10
	[CompilerGenerated]
	private ulong <MaxCacheSize>k__BackingField; //Field offset: 0x18

	public internal TimeSpan DeleteOlder
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		internal set { } //Length: 5
	}

	public internal ulong MaxCacheSize
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		internal set { } //Length: 5
	}

	public HTTPCacheOptions() { }

	public HTTPCacheOptions(TimeSpan deleteOlder, ulong maxCacheSize) { }

	[CompilerGenerated]
	public TimeSpan get_DeleteOlder() { }

	[CompilerGenerated]
	public ulong get_MaxCacheSize() { }

	[CompilerGenerated]
	internal void set_DeleteOlder(TimeSpan value) { }

	[CompilerGenerated]
	internal void set_MaxCacheSize(ulong value) { }

}

