namespace Best.HTTP.Caching;

internal class CacheMetadata : Metadata
{
	[CompilerGenerated]
	private Hash128 <Hash>k__BackingField; //Field offset: 0x20
	[CompilerGenerated]
	private ulong <ContentLength>k__BackingField; //Field offset: 0x30
	[CompilerGenerated]
	private DateTime <LastAccessTime>k__BackingField; //Field offset: 0x38
	[CompilerGenerated]
	private LockTypes <Lock>k__BackingField; //Field offset: 0x40
	[CompilerGenerated]
	private int <ReadLockCount>k__BackingField; //Field offset: 0x44

	public ulong ContentLength
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		 set { } //Length: 5
	}

	public Hash128 Hash
	{
		[CompilerGenerated]
		 get { } //Length: 11
		[CompilerGenerated]
		 set { } //Length: 8
	}

	public DateTime LastAccessTime
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		 set { } //Length: 5
	}

	public LockTypes Lock
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		 set { } //Length: 4
	}

	public int ReadLockCount
	{
		[CompilerGenerated]
		 get { } //Length: 4
		[CompilerGenerated]
		 set { } //Length: 4
	}

	public CacheMetadata() { }

	[CompilerGenerated]
	public ulong get_ContentLength() { }

	[CompilerGenerated]
	public Hash128 get_Hash() { }

	[CompilerGenerated]
	public DateTime get_LastAccessTime() { }

	[CompilerGenerated]
	public LockTypes get_Lock() { }

	[CompilerGenerated]
	public int get_ReadLockCount() { }

	public virtual void LoadFrom(Stream stream) { }

	public virtual void SaveTo(Stream stream) { }

	[CompilerGenerated]
	public void set_ContentLength(ulong value) { }

	[CompilerGenerated]
	public void set_Hash(Hash128 value) { }

	[CompilerGenerated]
	public void set_LastAccessTime(DateTime value) { }

	[CompilerGenerated]
	public void set_Lock(LockTypes value) { }

	[CompilerGenerated]
	public void set_ReadLockCount(int value) { }

	public virtual string ToString() { }

}

