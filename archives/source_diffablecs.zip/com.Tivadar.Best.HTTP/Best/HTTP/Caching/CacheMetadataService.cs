namespace Best.HTTP.Caching;

internal sealed class CacheMetadataService : MetadataService<CacheMetadata, CacheMetadataContent>
{
	[CompilerGenerated]
	private sealed class <>c__DisplayClass2_0
	{
		public Hash128 hash; //Field offset: 0x10

		public <>c__DisplayClass2_0() { }

		internal void <Create>b__0(CacheMetadataContent content, CacheMetadata metadata) { }

	}


	public CacheMetadataService(IndexingService<CacheMetadataContent, CacheMetadata> indexingService, IEmptyMetadataIndexFinder<CacheMetadata> emptyMetadataIndexFinder) { }

	public CacheMetadata Create(Hash128 hash, CacheMetadataContent value, int filePos, int length) { }

	public virtual CacheMetadata CreateFrom(Stream stream) { }

}

