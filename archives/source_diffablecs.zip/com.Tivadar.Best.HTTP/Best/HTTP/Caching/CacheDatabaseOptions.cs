namespace Best.HTTP.Caching;

internal sealed class CacheDatabaseOptions : DatabaseOptions
{

	public CacheDatabaseOptions() { }

}

