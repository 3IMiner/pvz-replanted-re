namespace Best.HTTP.Caching;

public enum LockTypes
{
	Unlocked = 0,
	Write = 1,
	Read = 2,
}

