namespace Best.HTTP.Caching;

internal sealed class HTTPCacheAcquireLockException : Exception
{

	public HTTPCacheAcquireLockException(string message) { }

}

