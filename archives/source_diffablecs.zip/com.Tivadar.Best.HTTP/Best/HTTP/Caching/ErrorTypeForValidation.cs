namespace Best.HTTP.Caching;

public enum ErrorTypeForValidation
{
	None = 0,
	ServerError = 1,
	ConnectionError = 2,
}

