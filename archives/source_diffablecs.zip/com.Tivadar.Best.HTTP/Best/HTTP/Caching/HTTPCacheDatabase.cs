namespace Best.HTTP.Caching;

internal sealed class HTTPCacheDatabase : Database<CacheMetadataContent, CacheMetadata, CacheMetadataIndexingService, CacheMetadataService>
{

	public HTTPCacheDatabase(string directory) { }

	private HTTPCacheDatabase(string directory, DatabaseOptions options, CacheMetadataIndexingService indexingService) { }

	internal ulong Delete(Hash128 hash, LoggingContext context) { }

	public void EnterWriteLock(LoggingContext context) { }

	public void ExitWriteLock(LoggingContext context) { }

	public CacheMetadataContent FindByHashAndUpdateRequestTime(Hash128 hash, LoggingContext context) { }

	private ValueTuple<CacheMetadataContent, CacheMetadata> FindContentAndMetadata(Hash128 hash) { }

	public ValueTuple<CacheMetadataContent, CacheMetadata> FindContentAndMetadataLocked(Hash128 hash) { }

	private CacheMetadata FindMetadata(Hash128 hash) { }

	public void ReleaseReadLock(Hash128 hash, LoggingContext context) { }

	public void ReleaseWriteLock(Hash128 hash, ulong length, LoggingContext context) { }

	public bool TryAcquireReadLock(Hash128 hash, LoggingContext context) { }

	public bool TryAcquireWriteLock(Hash128 hash, Dictionary<String, List`1<String>> headers, LoggingContext context) { }

	public bool Update(Hash128 hash, Dictionary<String, List`1<String>> headers, LoggingContext context) { }

	public void UpdateLastAccessTime(Hash128 hash, LoggingContext context) { }

	private void UpdateMetadataAndContent(Metadata metadata, CacheMetadataContent content) { }

}

