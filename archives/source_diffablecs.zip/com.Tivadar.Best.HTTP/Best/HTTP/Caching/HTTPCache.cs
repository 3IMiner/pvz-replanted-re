namespace Best.HTTP.Caching;

[Il2CppEagerStaticClassConstruction]
public class HTTPCache : IDisposable, IHeartbeat
{
	[CompilerGenerated]
	private sealed class <>c
	{
		public static readonly <>c <>9; //Field offset: 0x0
		public static Comparison<CacheMetadata> <>9__41_0; //Field offset: 0x8

		private static <>c() { }

		public <>c() { }

		internal int <MaintainImplementation>b__41_0(CacheMetadata x, CacheMetadata y) { }

	}

	[CompilerGenerated]
	private sealed class <>c__DisplayClass33_0
	{
		public bool hasValidMaxAge; //Field offset: 0x10

		public <>c__DisplayClass33_0() { }

		internal bool <IsCacheble>g__CheckHeader|0(string headerValue) { }

	}

	private const string RootFolderName = "LocalCache"; //Field offset: 0x0
	private const string DatabaseFolderName = "Database"; //Field offset: 0x0
	private const string ContentFolderName = "Content"; //Field offset: 0x0
	private const string HeaderFileName = "headers.txt"; //Field offset: 0x0
	private const string ContentFileName = "content.bin"; //Field offset: 0x0
	public const string CacheHostName = "com.Tivadar.Best.HTTP.Local.Cache"; //Field offset: 0x0
	public OnCacheSizeChangedDelegate OnCacheSizeChanged; //Field offset: 0x10
	[CompilerGenerated]
	private HTTPCacheOptions <Options>k__BackingField; //Field offset: 0x18
	private long _cacheSize; //Field offset: 0x20
	public OnBeforeBeginCacheDelegate OnBeforeBeginCache; //Field offset: 0x28
	private int _subscribed; //Field offset: 0x30
	private bool _isSupported; //Field offset: 0x34
	private HTTPCacheDatabase _database; //Field offset: 0x38
	private string _baseDirectory; //Field offset: 0x40

	public long CacheSize
	{
		 get { } //Length: 5
	}

	public private HTTPCacheOptions Options
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 13
	}

	public HTTPCache(HTTPCacheOptions options) { }

	public bool AreCacheFilesExists(Hash128 hash) { }

	public HTTPCacheContentWriter BeginCache(HTTPMethods method, Uri uri, int statusCode, Dictionary<String, List`1<String>> headers, LoggingContext context) { }

	public Stream BeginReadContent(Hash128 hash, LoggingContext context) { }

	private override void Best.HTTP.Shared.Extensions.IHeartbeat.OnHeartbeatUpdate(DateTime now, TimeSpan dif) { }

	public static Hash128 CalculateHash(HTTPMethods method, Uri uri) { }

	public bool CanServeWithoutValidation(Hash128 hash, ErrorTypeForValidation errorType, LoggingContext context) { }

	public void Clear() { }

	private void DecrementCacheSize(ulong withSize) { }

	public void Delete(Hash128 hash, LoggingContext context) { }

	public override void Dispose() { }

	public void EndCache(HTTPCacheContentWriter cacheResult, bool completedWithoutIssue, LoggingContext context) { }

	public void EndReadContent(Hash128 hash, LoggingContext context) { }

	public long get_CacheSize() { }

	[CompilerGenerated]
	public HTTPCacheOptions get_Options() { }

	public string GetContentPathFromHash(Hash128 hash) { }

	public string GetHashDirectory(Hash128 hash) { }

	public string GetHeaderPathFromHash(Hash128 hash) { }

	private void IncrementCacheSize(ulong withSize) { }

	private bool IsCacheble(Dictionary<String, List`1<String>> headers) { }

	private bool IsCacheble(HTTPMethods method, Uri uri, int statusCode) { }

	internal bool IsThereEnoughSpaceAfterMaintain(ulong spaceNeeded, LoggingContext context) { }

	private static Dictionary<String, List`1<String>> LoadHeaders(Stream headersStream) { }

	private static void LogCachingHeaders(Dictionary<String, List`1<String>> headers, LoggingContext context) { }

	internal void Maintain(ulong contentLength, bool deleteLockedEntries, LoggingContext context) { }

	private void MaintainImplementation(ulong contentLength, bool deleteLockedEntries, DateTime now, LoggingContext context) { }

	public void Redirect(HTTPRequest request, Hash128 hash) { }

	public bool RefreshHeaders(Hash128 hash, Dictionary<String, List`1<String>> newHeaders, LoggingContext context) { }

	[CompilerGenerated]
	private void set_Options(HTTPCacheOptions value) { }

	public void SetupValidationHeaders(HTTPRequest request) { }

	private static void WriteHeaders(Stream headerStream, Dictionary<String, List`1<String>> headers) { }

	private void ZeroOutCacheSize() { }

}

