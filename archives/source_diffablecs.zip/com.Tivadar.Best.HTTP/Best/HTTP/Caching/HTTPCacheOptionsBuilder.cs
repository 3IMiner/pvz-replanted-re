namespace Best.HTTP.Caching;

public struct HTTPCacheOptionsBuilder
{
	private HTTPCacheOptions _options; //Field offset: 0x0

	public HTTPCacheOptions Build() { }

	public HTTPCacheOptionsBuilder WithDeleteOlderThen(TimeSpan olderThan) { }

	public HTTPCacheOptionsBuilder WithMaxCacheSize(ulong maxCacheSize) { }

}

