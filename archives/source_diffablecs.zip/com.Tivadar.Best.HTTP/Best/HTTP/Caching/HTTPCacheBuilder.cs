namespace Best.HTTP.Caching;

public struct HTTPCacheBuilder
{
	private HTTPCacheOptions _options; //Field offset: 0x0
	private OnBeforeBeginCacheDelegate _callback; //Field offset: 0x8

	public HTTPCache Build() { }

	public HTTPCacheBuilder WithBeforeBeginCacheCallback(OnBeforeBeginCacheDelegate callback) { }

	public HTTPCacheBuilder WithOptions(HTTPCacheOptions options) { }

	public HTTPCacheBuilder WithOptions(HTTPCacheOptionsBuilder optionsBuilder) { }

}

