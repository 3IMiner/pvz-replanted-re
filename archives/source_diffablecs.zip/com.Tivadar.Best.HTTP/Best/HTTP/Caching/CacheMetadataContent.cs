namespace Best.HTTP.Caching;

internal sealed class CacheMetadataContent
{
	public string ETag; //Field offset: 0x10
	public DateTime LastModified; //Field offset: 0x18
	public DateTime Expires; //Field offset: 0x20
	public uint Age; //Field offset: 0x28
	public uint MaxAge; //Field offset: 0x2C
	public DateTime Date; //Field offset: 0x30
	public uint StaleWhileRevalidate; //Field offset: 0x38
	public uint StaleIfError; //Field offset: 0x3C
	public CacheFlags Flags; //Field offset: 0x40
	public DateTime RequestTime; //Field offset: 0x48
	public DateTime ResponseTime; //Field offset: 0x50

	public CacheMetadataContent() { }

	internal void From(Dictionary<String, List`1<String>> headers) { }

}

