namespace Best.HTTP.Caching;

internal sealed class CacheMetadataIndexingService : IndexingService<CacheMetadataContent, CacheMetadata>
{
	private AVLTree<Hash128, Int32> index_Hash; //Field offset: 0x10

	public CacheMetadataIndexingService() { }

	public virtual void Clear() { }

	public bool ContainsHash(Hash128 hash) { }

	public List<Int32> FindByHash(Hash128 hash) { }

	public virtual IEnumerable<Int32> GetOptimizedIndexes() { }

	public virtual void Index(CacheMetadata metadata) { }

	public virtual void Remove(CacheMetadata metadata) { }

}

