namespace Best.HTTP.Caching;

internal struct v128View
{
	public ulong low; //Field offset: 0x0
	public ulong high; //Field offset: 0x8

}

