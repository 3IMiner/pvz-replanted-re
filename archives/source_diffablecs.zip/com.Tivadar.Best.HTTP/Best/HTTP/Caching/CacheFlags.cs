namespace Best.HTTP.Caching;

[Flags]
public enum CacheFlags
{
	None = 0,
	MustRevalidate = 1,
	NoCache = 2,
}

