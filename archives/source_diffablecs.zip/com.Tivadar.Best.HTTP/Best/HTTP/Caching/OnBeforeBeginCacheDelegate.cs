namespace Best.HTTP.Caching;

public sealed class OnBeforeBeginCacheDelegate : MulticastDelegate
{

	public OnBeforeBeginCacheDelegate(object object, IntPtr method) { }

	public override IAsyncResult BeginInvoke(HTTPMethods method, Uri uri, int statusCode, Dictionary<String, List`1<String>> headers, LoggingContext context, AsyncCallback callback, object object) { }

	public override void EndInvoke(IAsyncResult result) { }

	public override void Invoke(HTTPMethods method, Uri uri, int statusCode, Dictionary<String, List`1<String>> headers, LoggingContext context = null) { }

}

