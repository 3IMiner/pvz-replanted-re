namespace Best.HTTP.Caching;

public class HTTPCacheContentWriter
{
	[CompilerGenerated]
	private HTTPCache <Cache>k__BackingField; //Field offset: 0x10
	[CompilerGenerated]
	private Hash128 <Hash>k__BackingField; //Field offset: 0x18
	[CompilerGenerated]
	private ulong <ExpectedLength>k__BackingField; //Field offset: 0x28
	[CompilerGenerated]
	private ulong <ProcessedLength>k__BackingField; //Field offset: 0x30
	[CompilerGenerated]
	private LoggingContext <Context>k__BackingField; //Field offset: 0x38
	private Stream _contentStream; //Field offset: 0x40

	public private HTTPCache Cache
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 13
	}

	public private LoggingContext Context
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 13
	}

	public private ulong ExpectedLength
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 5
	}

	public private Hash128 Hash
	{
		[CompilerGenerated]
		 get { } //Length: 11
		[CompilerGenerated]
		private set { } //Length: 8
	}

	public private ulong ProcessedLength
	{
		[CompilerGenerated]
		 get { } //Length: 5
		[CompilerGenerated]
		private set { } //Length: 5
	}

	internal HTTPCacheContentWriter(HTTPCache cache, Hash128 hash, Stream contentStream, ulong expectedLength, LoggingContext loggingContext) { }

	internal void Close() { }

	[CompilerGenerated]
	public HTTPCache get_Cache() { }

	[CompilerGenerated]
	public LoggingContext get_Context() { }

	[CompilerGenerated]
	public ulong get_ExpectedLength() { }

	[CompilerGenerated]
	public Hash128 get_Hash() { }

	[CompilerGenerated]
	public ulong get_ProcessedLength() { }

	[CompilerGenerated]
	private void set_Cache(HTTPCache value) { }

	[CompilerGenerated]
	private void set_Context(LoggingContext value) { }

	[CompilerGenerated]
	private void set_ExpectedLength(ulong value) { }

	[CompilerGenerated]
	private void set_Hash(Hash128 value) { }

	[CompilerGenerated]
	private void set_ProcessedLength(ulong value) { }

	public virtual string ToString() { }

	public void Write(BufferSegment segment) { }

}

