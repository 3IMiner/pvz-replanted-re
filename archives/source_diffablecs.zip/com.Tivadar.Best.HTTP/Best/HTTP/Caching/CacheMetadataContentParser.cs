namespace Best.HTTP.Caching;

internal sealed class CacheMetadataContentParser : IDiskContentParser<CacheMetadataContent>
{
	public const int PrecisionShift = 24; //Field offset: 0x0

	public CacheMetadataContentParser() { }

	public override void Encode(Stream stream, CacheMetadataContent content) { }

	public override CacheMetadataContent Parse(Stream stream, int length) { }

}

