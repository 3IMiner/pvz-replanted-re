namespace Best.HTTP.Caching;

public sealed class OnCacheSizeChangedDelegate : MulticastDelegate
{

	public OnCacheSizeChangedDelegate(object object, IntPtr method) { }

	public override IAsyncResult BeginInvoke(AsyncCallback callback, object object) { }

	public override void EndInvoke(IAsyncResult result) { }

	public override void Invoke() { }

}

