namespace Best.HTTP.Futures;

public sealed class FutureValueCallback : MulticastDelegate
{

	public FutureValueCallback`1(object object, IntPtr method) { }

	public override IAsyncResult BeginInvoke(T value, AsyncCallback callback, object object) { }

	public override void EndInvoke(IAsyncResult result) { }

	public override void Invoke(T value) { }

}

