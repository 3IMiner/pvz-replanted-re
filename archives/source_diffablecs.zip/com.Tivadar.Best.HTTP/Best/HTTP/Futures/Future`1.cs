namespace Best.HTTP.Futures;

public class Future : IFuture<T>
{
	private FutureState _state; //Field offset: 0x0
	private T _value; //Field offset: 0x0
	private Exception _error; //Field offset: 0x0
	private Func<T> _processFunc; //Field offset: 0x0
	private readonly List<FutureValueCallback`1<T>> _itemCallbacks; //Field offset: 0x0
	private readonly List<FutureValueCallback`1<T>> _successCallbacks; //Field offset: 0x0
	private readonly List<FutureErrorCallback> _errorCallbacks; //Field offset: 0x0
	private readonly List<FutureCallback`1<T>> _complationCallbacks; //Field offset: 0x0

	public override Exception error
	{
		 get { } //Length: 171
	}

	public override FutureState state
	{
		 get { } //Length: 47
	}

	public override T value
	{
		 get { } //Length: 325
	}

	public Future`1() { }

	public void Assign(T value) { }

	private void AssignImpl(T value) { }

	public void AssignItem(T value) { }

	public void BeginProcess(T initialItem = null) { }

	private void ClearCallbacks() { }

	public void Fail(Exception error) { }

	private void FailImpl(Exception error) { }

	public void Finish() { }

	private void FlushComplationCallbacks() { }

	private void FlushErrorCallbacks() { }

	private void FlushSuccessCallbacks() { }

	public override Exception get_error() { }

	public override FutureState get_state() { }

	public override T get_value() { }

	public override IFuture<T> OnComplete(FutureCallback<T> callback) { }

	public override IFuture<T> OnError(FutureErrorCallback callback) { }

	public override IFuture<T> OnItem(FutureValueCallback<T> callback) { }

	public override IFuture<T> OnSuccess(FutureValueCallback<T> callback) { }

	public IFuture<T> Process(Func<T> func) { }

	private void ThreadFunc(object param) { }

}

