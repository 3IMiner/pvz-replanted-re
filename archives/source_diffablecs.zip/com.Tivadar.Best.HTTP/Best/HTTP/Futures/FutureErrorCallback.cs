namespace Best.HTTP.Futures;

public sealed class FutureErrorCallback : MulticastDelegate
{

	public FutureErrorCallback(object object, IntPtr method) { }

	public override IAsyncResult BeginInvoke(Exception error, AsyncCallback callback, object object) { }

	public override void EndInvoke(IAsyncResult result) { }

	public override void Invoke(Exception error) { }

}

