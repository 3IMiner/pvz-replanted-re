namespace Best.HTTP.Futures;

public interface IFuture
{

	public Exception error
	{
		 get { } //Length: 0
	}

	public FutureState state
	{
		 get { } //Length: 0
	}

	public T value
	{
		 get { } //Length: 0
	}

	public Exception get_error() { }

	public FutureState get_state() { }

	public T get_value() { }

	public IFuture<T> OnComplete(FutureCallback<T> callback) { }

	public IFuture<T> OnError(FutureErrorCallback callback) { }

	public IFuture<T> OnItem(FutureValueCallback<T> callback) { }

	public IFuture<T> OnSuccess(FutureValueCallback<T> callback) { }

}

