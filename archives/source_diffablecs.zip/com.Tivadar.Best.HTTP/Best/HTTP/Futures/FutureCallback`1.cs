namespace Best.HTTP.Futures;

public sealed class FutureCallback : MulticastDelegate
{

	public FutureCallback`1(object object, IntPtr method) { }

	public override IAsyncResult BeginInvoke(IFuture<T> future, AsyncCallback callback, object object) { }

	public override void EndInvoke(IAsyncResult result) { }

	public override void Invoke(IFuture<T> future) { }

}

