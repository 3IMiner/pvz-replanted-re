namespace Best.HTTP;

public sealed class OnHeaderEnumerationDelegate : MulticastDelegate
{

	public OnHeaderEnumerationDelegate(object object, IntPtr method) { }

	public override IAsyncResult BeginInvoke(string header, List<String> values, AsyncCallback callback, object object) { }

	public override void EndInvoke(IAsyncResult result) { }

	public override void Invoke(string header, List<String> values) { }

}

